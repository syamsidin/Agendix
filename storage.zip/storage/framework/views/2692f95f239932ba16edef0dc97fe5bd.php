<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e($title ?? 'Agendix BPSDM Jabar'); ?></title>
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('agendix.png')); ?>">

    <!-- Fonts & Icons -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" />
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- FullCalendar JS (dimuat di head agar siap) -->
    <script src='https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/index.global.min.js'>
        document.addEventListener("DOMContentLoaded", function() {
        var carousels = document.querySelectorAll('.carousel');
        carousels.forEach(function(carousel) {
            new bootstrap.Carousel(carousel);
        });
    });
    </script>

    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>


    <!-- Style Global Publik -->
    <style>
        html, body {
    height: 100%; /* Penting: pastikan html dan body bisa mengisi seluruh tinggi */
    }
        :root { --primary-color: #435ebe; --bg-light: #f4f6f9; --text-dark: #25396f; }
        body {
            font-family: 'Poppins', sans-serif;
            background-color: var(--bg-light);
            display: flex; /* Jadikan body sebagai flex container */
            flex-direction: column; /* Arahkan item ke bawah */
        }
        .footer {
        flex-shrink: 0; /* Pastikan footer tidak menyusut */
        }

        .footer-primary {
            background-color: var(--primary-color);
            color: rgba(255, 255, 255, 0.8); /* Sedikit lebih terang dari text-white-50 */
        }
        .footer-primary p {
            margin-bottom: 0;
        }

        .header { position: sticky; top: 0; width: 100%; background-color: #fff; z-index: 1030; box-shadow: 0 2px 10px rgba(0,0,0,0.05); }
        .navbar-brand { font-weight: 700; color: var(--primary-color); }
        .nav-link { color: var(--text-dark); font-weight: 500; position: relative; padding-bottom: 0.5rem; margin: 0 1rem; }
        .nav-link::after { content: ''; position: absolute; width: 0; height: 2px; bottom: 0; left: 50%; transform: translateX(-50%); background-color: var(--primary-color); transition: width 0.3s ease; }
        .nav-link:hover::after, .nav-link.active::after { width: 100%; }
        .nav-link:hover, .nav-link.active { color: var(--primary-color); }
        .btn-login { background-color: var(--primary-color); color: #fff; padding: 8px 24px; border-radius: 50px; text-decoration: none; transition: all 0.3s ease; }
        .btn-login:hover { transform: translateY(-2px); box-shadow: 0 4px 15px rgba(67, 94, 190, 0.3); }
        /* Style tambahan dari halaman-halaman Anda bisa diletakkan di sini atau di <?php echo $__env->yieldPushContent('styles'); ?> */
    </style>
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body>
    
    <?php echo $__env->make('layouts.partials.public-navigation', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main class="container my-5">
        
        <?php echo e($slot); ?>

    </main>

<footer class="footer footer-primary py-4 text-center">
    <p> Copyright ©sem 2025 Agendix BPSDM Jabar . All Rights Reserved.</p>
</footer>

    
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
    
    
    
    
    
    <?php echo $__env->yieldPushContent('scripts'); ?>

</body>
</html><?php /**PATH F:\agenda-bpsdm\resources\views/layouts/public.blade.php ENDPATH**/ ?>
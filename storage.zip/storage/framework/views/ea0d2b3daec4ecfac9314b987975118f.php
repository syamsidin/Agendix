<div>
    
    
    
    <div class="card mb-4">
        <div class="card-header">
            <h3 class="card-title"><i class="fas fa-filter mr-2"></i> Filter Kalender</h3>
        </div>
        <div class="card-body">
            <div class="row align-items-end">
                <div class="col-md-4">
                    <div class="form-group">
                        <label>Dari Tanggal:</label>
                        <input type="date" wire:model.live="startDateFilter" class="form-control">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label>Sampai Tanggal:</label>
                        <input type="date" wire:model.live="endDateFilter" class="form-control">
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label>Bidang Penyelenggara:</label>
                        <select wire:model.live="departmentFilter" class="form-control">
                            <option value="">-- Semua Bidang --</option>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($dept); ?>"><?php echo e($dept); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </select>
                    </div>
                </div>
                <div class="col-md-1">
                    <div class="form-group">
                        <button wire:click="resetFilters" class="btn btn-secondary w-100" title="Hapus Filter">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

 
    
    
    <!--[if BLOCK]><![endif]--><?php if($filteredAgendas): ?>
        <div class="card mb-4">
            <div class="card-header">
                <h3 class="card-title">Hasil Filter (<?php echo e($filteredAgendas->total()); ?> Kegiatan Ditemukan)</h3>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Nama Kegiatan</th>
                                <th>Penyelenggara</th>
                                <th>Jadwal & Lokasi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $filteredAgendas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agenda): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($agenda->title); ?></td>
                                    <td><?php echo e($agenda->user->name ?? 'N/A'); ?> <br><small>(<?php echo e($agenda->user->department_name); ?>)</small></td>
                                    <td>
                                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $agenda->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="mb-1 <?php echo e(!$loop->last ? 'pb-1 border-bottom' : ''); ?>">
                                                <i class="fas fa-calendar-alt fa-fw"></i> <?php echo e(\Carbon\Carbon::parse($detail->start_date)->isoFormat('D MMM Y')); ?>

                                                <br>
                                                <i class="fas fa-map-marker-alt fa-fw"></i> <?php echo e($detail->room->name ?? $detail->manual_location ?? 'N/A'); ?>

                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr><td colspan="3" class="text-center">Tidak ada kegiatan yang cocok dengan filter Anda.</td></tr>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </tbody>
                    </table>
                </div>
                <div class="mt-3">
                    <?php echo e($filteredAgendas->links()); ?>

                </div>
            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->


<div>
    
      <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('shared.recent-activities');

$__html = app('livewire')->mount($__name, $__params, 'lw-2946381155-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    <div wire:ignore id='calendar'></div>

    
    
    
    <div wire:ignore.self class="modal fade" id="agendaDetailModal" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-lg" role="document"> 
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                    Detail Agenda 
                    <!--[if BLOCK]><![endif]--><?php if($selectedAgenda): ?>
                        <!--[if BLOCK]><![endif]--><?php if($selectedAgenda->type == 'internal'): ?>
                            <span class="badge badge-info">Internal</span>
                        <?php else: ?>
                            <span class="badge badge-success">Eksternal</span>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    <!--[if BLOCK]><![endif]--><?php if($selectedAgenda): ?>
                        
                        <h5 class="font-weight-bold"><?php echo e($selectedAgenda->title); ?></h5>
                        <p><strong>Penyelenggara:</strong> <?php echo e($selectedAgenda->user->name ?? 'N/A'); ?></p>
                        <!--[if BLOCK]><![endif]--><?php if($selectedAgenda->konseptor_name): ?>
                        <p><strong>Konseptor:</strong> <?php echo e($selectedAgenda->konseptor_name); ?></p>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <p><strong>Deskripsi:</strong><br><?php echo nl2br(e($selectedAgenda->description)); ?></p>
                        <hr>
                        
                        
                        <h6><strong>Detail Jadwal dan Lokasi:</strong></h6>
                        <!--[if BLOCK]><![endif]--><?php if($selectedAgenda->details->isNotEmpty()): ?>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $selectedAgenda->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="card card-outline card-secondary mb-2">
                                    <div class="card-body p-2" style="font-size: 0.9rem;">
                                        <div><i class="fas fa-calendar-alt fa-fw text-muted"></i> <?php echo e(\Carbon\Carbon::parse($detail->start_date)->isoFormat('dddd, D MMM Y')); ?> s/d <?php echo e(\Carbon\Carbon::parse($detail->end_date)->isoFormat('dddd, D MMM Y')); ?></div>
                                        <div><i class="fas fa-clock fa-fw text-muted"></i> <?php echo e(\Carbon\Carbon::parse($detail->start_time)->format('H:i')); ?> - <?php echo e(\Carbon\Carbon::parse($detail->end_time)->format('H:i')); ?></div>
                                        <div><i class="fas fa-map-marker-alt fa-fw text-muted"></i> 
                                            <!--[if BLOCK]><![endif]--><?php if($selectedAgenda->type == 'internal'): ?>
                                                <strong><?php echo e($detail->room->name ?? 'N/A'); ?></strong>
                                            <?php else: ?>
                                                <strong><?php echo e($detail->manual_location); ?></strong>
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        <?php else: ?>
                            <p class="text-muted">Tidak ada detail jadwal untuk agenda ini.</p>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </div>
            </div>
        </div>
    </div>

    
    
    
    <div wire:ignore.self class="modal fade" id="dayActivitiesModal" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        Daftar Kegiatan untuk <?php echo e($selectedDateForModal ? \Carbon\Carbon::parse($selectedDateForModal)->isoFormat('dddd, D MMMM YYYY') : ''); ?>

                    </h5>
                    <button type="button" wire:click="$dispatch('hide-modals')" class="close" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </button>
                </div>
               <div class="modal-body">
                <!--[if BLOCK]><![endif]--><?php if(!empty($dayActivities)): ?>
                    <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $dayActivities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        
                        
                        
                        <div class="card mb-3 shadow-sm">
                            <div class="card-body">
                                
                                <h5 class="card-title font-weight-bold d-flex justify-content-between">
                                    <span><?php echo e($detail->agenda->title ?? 'N/A'); ?></span>
                                    <!--[if BLOCK]><![endif]--><?php if(optional($detail->agenda)->type == 'internal'): ?>
                                        <span class="badge badge-info">Internal</span>
                                    <?php else: ?>
                                        <span class="badge badge-success">Eksternal</span>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </h5>
                                <hr class="mt-2 mb-3">
                                
                                
                                <p class="mb-1"><i class="fas fa-clock fa-fw text-muted"></i> <strong>Waktu:</strong> <?php echo e(\Carbon\Carbon::parse($detail->start_time)->format('H:i')); ?> - <?php echo e(\Carbon\Carbon::parse($detail->end_time)->format('H:i')); ?></p>
                                <p class="mb-1"><i class="fas fa-map-marker-alt fa-fw text-muted"></i> <strong>Tempat:</strong> <?php echo e($detail->agenda->type == 'internal' ? (optional($detail->room)->name ?? 'N/A') : $detail->manual_location); ?></p>
                                <p class="mb-2"><i class="fas fa-file-alt fa-fw text-muted"></i> <strong>Deskripsi:</strong> <?php echo e(Str::limit(optional($detail->agenda)->description, 100)); ?></p>

                                
                                <p class="mb-2">
                                    <i class="fas fa-chalkboard-teacher fa-fw text-muted"></i> <strong>Pengajar:</strong><br>
                                    <!--[if BLOCK]><![endif]--><?php $__empty_2 = true; $__currentLoopData = $detail->assignments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                        <span class="d-block ml-4">- <?php echo e($asg->widyaiswara->name ?? 'N/A'); ?> (<?php echo e($asg->material); ?>)</span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                        <span class="d-block ml-4 text-muted font-italic">Belum ada pengajar ditugaskan.</span>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </p>
                                
                                 
                                <p class="mb-3">
                                    <i class="fas fa-user-tie fa-fw text-muted"></i> <strong>Disposisi Pimpinan:</strong><br>
                                    <!--[if BLOCK]><![endif]--><?php $__empty_2 = true; $__currentLoopData = $detail->dispositions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dispo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                        <span class="d-block ml-4">- <?php echo e($dispo->struktural->name ?? 'N/A'); ?> (<?php echo e($dispo->purpose); ?>)</span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                        <span class="d-block ml-4 text-muted font-italic">Belum ada disposisi untuk jadwal ini.</span>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </p>

                                
                                <div class="border-top pt-2 text-muted small">
                                    Penyelenggara: <strong><?php echo e($detail->agenda->user->name ?? 'N/A'); ?></strong>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="text-center text-muted p-4">
                            <i class="fas fa-calendar-times fa-3x mb-3"></i>
                            <p>Tidak ada kegiatan yang dijadwalkan pada tanggal ini.</p>
                        </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </div>
            </div>
        </div>
    </div>
    
    <?php $__env->startPush('scripts'); ?>
    <script>
        document.addEventListener('livewire:initialized', function () {
            var calendarEl = document.getElementById('calendar');
            var calendar = new FullCalendar.Calendar(calendarEl, {
                initialView: 'dayGridMonth',
                headerToolbar: {
                    left: 'prev,next today',
                    center: 'title',
                    right: 'dayGridMonth,timeGridWeek,listWeek'
                },
                events: <?php echo json_encode($events, 15, 512) ?>,
                
                // Event saat event/bubble di-klik (SUDAH ADA)
                eventClick: function(info) {
                    info.jsEvent.preventDefault();
                    window.Livewire.find('<?php echo e($_instance->getId()); ?>').call('showAgendaDetails', info.event.id);
                },

                // Event BARU saat tanggal di-klik
                dateClick: function(info) {
                    // Panggil method di backend Livewire dan kirim tanggalnya
                    window.Livewire.find('<?php echo e($_instance->getId()); ?>').call('showActivitiesForDate', info.dateStr);
                }
            });
            calendar.render();

            window.Livewire.find('<?php echo e($_instance->getId()); ?>').on('events-updated', (newEvents) => {
                calendar.removeAllEvents();
                calendar.addEventSource(newEvents[0]); // Ambil array events dari data yang dikirim
            });
            
            // Listener untuk modal detail agenda (SUDAH ADA)
            window.Livewire.find('<?php echo e($_instance->getId()); ?>').on('open-agenda-modal', () => {
                $('#agendaDetailModal').modal('show');
            });
            
            // Listener BARU untuk modal daftar kegiatan per hari
            window.Livewire.find('<?php echo e($_instance->getId()); ?>').on('open-day-activities-modal', () => {
                $('#dayActivitiesModal').modal('show');
            });
        });
    </script>
    <?php $__env->stopPush(); ?>
</div><?php /**PATH F:\agenda-bpsdm\resources\views/livewire/shared/calendar.blade.php ENDPATH**/ ?>
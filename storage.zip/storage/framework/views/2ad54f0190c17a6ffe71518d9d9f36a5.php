<li class="nav-item dropdown" wire:poll.30s="loadNotifications">
    <a class="nav-link" data-toggle="dropdown" href="#">
        <i class="far fa-bell"></i>
        <!--[if BLOCK]><![endif]--><?php if($unreadCount > 0): ?>
            <span class="badge badge-warning navbar-badge"><?php echo e($unreadCount); ?></span>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </a>
    <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
        <span class="dropdown-item dropdown-header"><?php echo e($unreadCount); ?> Notifikasi Belum Dibaca</span>
        <div class="dropdown-divider"></div>

        <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $unreadNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <a href="<?php echo e($notification->data['url'] ?? '#'); ?>" wire:click.prevent="markAsRead('<?php echo e($notification->id); ?>')" class="dropdown-item">
                <i class="fas fa-file mr-2"></i> 
                <span class="text-wrap"><?php echo e($notification->data['message']); ?></span>
                <span class="float-right text-muted text-sm"><?php echo e($notification->created_at->diffForHumans(null, true)); ?></span>
            </a>
            <div class="dropdown-divider"></div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <a href="#" class="dropdown-item text-center text-muted">Tidak ada notifikasi baru</a>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

        <!--[if BLOCK]><![endif]--><?php if($unreadCount > 0): ?>
            <a href="#" wire:click.prevent="markAllAsRead" class="dropdown-item dropdown-footer">Tandai semua sudah dibaca</a>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </div>
</li><?php /**PATH F:\agenda-bpsdm\resources\views/livewire/shared/notifications.blade.php ENDPATH**/ ?>
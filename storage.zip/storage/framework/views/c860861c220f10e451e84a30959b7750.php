<header class="header">
    <nav class="navbar navbar-expand-lg">
        <div class="container">
            <a class="navbar-brand" href="<?php echo e(route('welcome')); ?>">
                <img src="<?php echo e(asset('agendix.png')); ?>" alt="Logo Agendix" style="height: 40px;" class="d-inline-block align-text-top me-2">
                Agendix
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto align-items-center">
                    
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('welcome') ? 'active' : ''); ?>" href="<?php echo e(route('welcome')); ?>">Beranda</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('public.rooms.gallery') || request()->routeIs('public.rooms.detail') ? 'active' : ''); ?>" href="<?php echo e(route('public.rooms.gallery')); ?>">Ruangan</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('public.calendar') ? 'active' : ''); ?>" href="<?php echo e(route('public.calendar')); ?>">Kalender</a>
                    </li>
                    <li class="nav-item ms-lg-3 mt-2 mt-lg-0">
                        <?php if(auth()->guard()->check()): ?>
                            <a href="<?php echo e(url('/dashboard')); ?>" class="btn btn-login">Dashboard</a>
                        <?php else: ?>
                            <a href="<?php echo e(route('login')); ?>" class="btn btn-login">Login</a>
                        <?php endif; ?>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
</header><?php /**PATH F:\agenda-bpsdm\resources\views/layouts/partials/public-navigation.blade.php ENDPATH**/ ?>
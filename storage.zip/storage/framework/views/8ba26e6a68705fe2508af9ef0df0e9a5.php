<div class="card">
    <div class="card-header">
        <h3 class="card-title">
            <i class="fas fa-inbox mr-2"></i>
            Agenda Pending
        </h3>
    </div>
    <div class="card-body p-0">
        <!--[if BLOCK]><![endif]--><?php if($recentAgendas->isNotEmpty()): ?>
            <ul class="list-group list-group-flush">
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $recentAgendas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agenda): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item">
                        <div class="d-flex w-100 justify-content-between">
                            <h6 class="mb-1 font-weight-bold"><?php echo e($agenda->title); ?></h6>
                            
                            <span class="badge badge-warning">Pending</span>
                        </div>
                        <p class="mb-1 text-muted">
                            <i class="fas fa-user fa-fw"></i> 
                            Diajukan oleh: <strong><?php echo e($agenda->user->name); ?></strong>
                        </p>
                        
                        <!--[if BLOCK]><![endif]--><?php if($agenda->details->isNotEmpty()): ?>
                            <?php $firstDetail = $agenda->details->first(); ?>
                            <small class="d-block">
                                <i class="fas fa-calendar-alt fa-fw"></i>
                                <?php echo e(\Carbon\Carbon::parse($firstDetail->start_date)->isoFormat('D MMM Y')); ?>

                            </small>
                            <small class="d-block">
                                 <i class="fas fa-clock fa-fw"></i>
                                 <?php echo e(\Carbon\Carbon::parse($firstDetail->start_time)->format('H:i')); ?> - <?php echo e(\Carbon\Carbon::parse($firstDetail->end_time)->format('H:i')); ?>

                            </small>
                            <small class="d-block">
                                <i class="fas fa-map-marker-alt fa-fw"></i>
                                 <!--[if BLOCK]><![endif]--><?php if($agenda->type == 'internal'): ?>
                                    <?php echo e($firstDetail->room->name ?? 'N/A'); ?>

                                 <?php else: ?>
                                    <?php echo e($firstDetail->manual_location ?? 'N/A'); ?>

                                 <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </small>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </ul>
        <?php else: ?>
            <div class="text-center text-muted p-4">
                <i class="fas fa-check-circle fa-2x text-success mb-2"></i>
                <p>Tidak ada agenda yang menunggu persetujuan saat ini.</p>
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </div>
</div><?php /**PATH F:\agenda-bpsdm\resources\views/livewire/shared/recent-activities.blade.php ENDPATH**/ ?>
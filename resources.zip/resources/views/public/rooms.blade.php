<x-public-layout>
    <x-slot name="title">
        Galeri Fasilitas Ruangan
    </x-slot>

    <style>
        .page-header {
            background: var(--bg-light, #f4f6f9);
            padding: 3rem 0;
            text-align: center;
        }
        .page-header h1 {
            color: var(--text-dark, #25396f);
            font-weight: 800;
        }
        .gallery-card {
            border-radius: 1rem;
            overflow: hidden;
            position: relative;
            display: block;
            text-decoration: none;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            transition: all 0.3s ease-in-out;
        }
        .gallery-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 15px 30px rgba(67, 94, 190, 0.15);
        }
        .gallery-card .card-img-container {
            height: 350px;
            position: relative;
        }
        .gallery-card .card-img-container::after {
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0; bottom: 0;
            background: linear-gradient(to top, rgba(0,0,0,0.8) 0%, rgba(0,0,0,0.4) 40%, transparent 100%);
            transition: opacity 0.3s ease;
        }
        .gallery-card:hover .card-img-container::after {
            opacity: 0.8;
        }
        .gallery-card img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        .gallery-card .card-title-overlay {
            position: absolute;
            bottom: 1.5rem;
            left: 1.5rem;
            right: 1.5rem;
            color: white;
            z-index: 2;
        }
        .gallery-card .card-title-overlay h4 {
            font-weight: 700;
            color: white;
            margin-bottom: 0.25rem;
        }
        .gallery-card .card-title-overlay p {
            margin: 0;
            font-size: 0.9rem;
            opacity: 0.8;
        }
        .gallery-card .card-info-footer {
            background-color: #fff;
            padding: 1rem 1.5rem;
            border-top: 1px solid #e9ecef;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 0.9rem;
            color: #6c757d;
        }
        .gallery-card .card-info-footer .btn-detail {
            background-color: var(--primary-color, #435ebe);
            color: white;
            font-size: 0.8rem;
            padding: 0.4rem 1rem;
            border-radius: 50px;
            text-transform: uppercase;
            font-weight: 600;
        }
    </style>

    <div class="page-header">
        <div class="container">
            <h1 class="display-5 fw-bold">Galeri Ruangan</h1>
            <p class="lead text-muted">Jelajahi semua fasilitas ruangan yang kami sediakan. Klik untuk melihat detail.</p>
        </div>
    </div>

    <div class="container py-6">
        <div class="row">
            @forelse($rooms as $room)
                <div class="col-lg-4 col-md-6 mb-4">
                    <a href="{{ route('public.rooms.detail', $room->id) }}" class="gallery-card">
                        <div class="card-img-container">
                            <img src="{{ $room->images->first() ? asset('storage/' . $room->images->first()->path) : 'https://via.placeholder.com/400x350.png/E9ECEF/6C757D?text=No+Image' }}" alt="{{ $room->name }}">
                            <div class="card-title-overlay">
                                <h4>{{ $room->name }}</h4>
                                <p><i class="fas fa-map-marker-alt fa-sm"></i> {{ $room->location }}</p>
                            </div>
                        </div>
                        <div class="card-info-footer">
                            <span><i class="fas fa-users me-2"></i><strong>{{ $room->capacity }}</strong> orang</span>
                            <span class="btn-detail">Lihat Detail <i class="fas fa-arrow-right fa-xs ms-1"></i></span>
                        </div>
                    </a>
                </div>
            @empty
                <div class="col-12 text-center">
                    <p class="text-muted">Informasi ruangan akan segera tersedia.</p>
                </div>
            @endforelse
        </div>
    </div>
</x-public-layout>
<x-public-layout>
    <x-slot name="title">
        Kalender Kegiatan Publik
    </x-slot>

    <div class="card">
        <div class="card-header">
            <h3>Kalender Semua Kegiatan</h3>
        </div>
        <div class="card-body">
            {{-- Panggil komponen kalender yang sudah ada! --}}
            @livewire('shared.calendar')
        </div>
    </div>
</x-public-layout>
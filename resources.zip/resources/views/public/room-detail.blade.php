<x-public-layout>
    <x-slot name="title">
        Detail Ruangan: {{ $room->name }}
    </x-slot>
    
    <style>
        .room-detail-header {
            background: linear-gradient(to right, #435ebe, #7186e0);
            color: white;
            padding: 3rem 0;
            border-bottom-left-radius: 50% 20%;
            border-bottom-right-radius: 50% 20%;
        }
        .carousel-item img {
            max-height: 70vh; /* Sedikit lebih rendah agar tidak terlalu dominan */
            object-fit: cover;
            border-radius: 1rem;
        }
        .carousel-indicators [data-bs-target] {
            width: 80px; /* Lebar thumbnail */
            height: 60px; /* Tinggi thumbnail */
            opacity: 0.6;
            text-indent: 0; /* Hapus indentasi teks default */
            margin: 0 5px;
            border: none;
            overflow: hidden;
            border-radius: 0.5rem;
        }
        .carousel-indicators [data-bs-target] img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        .carousel-indicators .active {
            opacity: 1;
            border: 3px solid #fff;
            box-shadow: 0 0 10px rgba(0, 98, 255, 0.7);
        }
        .detail-card {
            border: none;
            box-shadow: 0 10px 30px rgba(0,0,0,0.08);
            border-radius: 1rem;
        }
        .detail-card h3 {
            color: var(--text-dark, #25396f);
            font-weight: 700;
        }
        .detail-card .info-item {
            display: flex;
            align-items: flex-start;
            margin-bottom: 1.25rem;
            font-size: 1.1rem;
        }
        .detail-card .info-item i {
            font-size: 1.5rem;
            color: var(--primary-color, #435ebe);
            margin-right: 15px;
            margin-top: 5px;
            width: 30px;
        }
    </style>

    <div class="room-detail-header">
        <div class="container text-center">
            <h1 class="display-4 fw-bold">{{ $room->name }}</h1>
            <p class="lead">{{ $room->location }}</p>
        </div>
    </div>

    <div class="container" style="margin-top: -60px; position: relative; z-index: 10;">
        {{-- Carousel Galeri Foto --}}
        @if($room->images->isNotEmpty())
            <div id="roomCarousel" class="carousel slide shadow-lg" data-bs-ride="carousel" style="border-radius: 1rem;">
                <div class="carousel-inner">
                    @foreach($room->images as $image)
                        <div class="carousel-item {{ $loop->first ? 'active' : '' }}">
                            <img src="{{ asset('storage/' . $image->path) }}" class="d-block w-100" alt="Foto {{ $room->name }}">
                        </div>
                    @endforeach
                </div>

                {{-- Tombol Navigasi Kiri/Kanan --}}
                @if($room->images->count() > 1)
                    <button class="carousel-control-prev" type="button" data-bs-target="#roomCarousel" data-bs-slide="prev"><span class="carousel-control-prev-icon"></span></button>
                    <button class="carousel-control-next" type="button" data-bs-target="#roomCarousel" data-bs-slide="next"><span class="carousel-control-next-icon"></span></button>
                @endif
                
                {{-- Indikator Thumbnail --}}
                <div class="carousel-indicators" style="position: static; margin-top: 1rem;">
                    @foreach($room->images as $image)
                        <button type="button" data-bs-target="#roomCarousel" data-bs-slide-to="{{ $loop->index }}" class="{{ $loop->first ? 'active' : '' }}" aria-current="{{ $loop->first ? 'true' : 'false' }}" aria-label="Slide {{ $loop->iteration }}">
                            <img src="{{ asset('storage/' . $image->path) }}" class="d-block w-100" alt="Thumbnail {{ $loop->iteration }}">
                        </button>
                    @endforeach
                </div>
            </div>
        @endif

        {{-- Detail Teks dalam Dua Kolom --}}
        <div class="card detail-card mt-5">
            <div class="card-body p-5">
                <div class="row">
                    <div class="col-lg-6">
                        <h3><i class="fas fa-info-circle me-2"></i>Informasi Umum</h3>
                        <hr>
                        <div class="info-item">
                            <i class="fas fa-users fa-fw"></i>
                            <div>
                                <strong>Kapasitas</strong><br>
                                <span>{{ $room->capacity }} orang</span>
                            </div>
                        </div>
                        <div class="info-item">
                            <i class="fas fa-map-marker-alt fa-fw"></i>
                            <div>
                                <strong>Lokasi Detail</strong><br>
                                <span>{{ $room->location }}</span>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <h3><i class="fas fa-couch me-2"></i>Fasilitas</h3>
                        <hr>
                        <div class="info-item">
                            <i class="fas fa-list-ul fa-fw"></i>
                            {{-- Gunakan white-space untuk menjaga format paragraf --}}
                            <div style="white-space: pre-wrap;">{{ $room->facilities }}</div>
                        </div>
                    </div>
                </div>
                 <div class="text-center mt-4">
                    <a href="{{ route('public.rooms.gallery') }}" class="btn btn-outline-primary"><i class="fas fa-arrow-left me-2"></i>Kembali ke Galeri Semua Ruangan</a>
                </div>
            </div>
        </div>
    </div>
</x-public-layout>
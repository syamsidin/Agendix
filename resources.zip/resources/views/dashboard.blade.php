<x-app-layout>
    <x-slot name="header">
        Dashboard
    </x-slot>

     @if(auth()->user()->role == 'admin')
            @livewire('dashboard.admin-dashboard')
        @elseif(auth()->user()->role == 'user')
            @livewire('dashboard.user-dashboard')
        @elseif(auth()->user()->role == 'pic_wi')
            @livewire('dashboard.pic-dashboard')
        @elseif(auth()->user()->role == 'pimpinan')
            @livewire('dashboard.pimpinan-dashboard')
        
        {{-- TAMBAHKAN KONDISI BARU DI SINI --}}
        @elseif(auth()->user()->role == 'pengelola_aset')
            {{-- Untuk saat ini, kita panggil dashboard admin --}}
            @livewire('dashboard.admin-dashboard')

        @elseif(auth()->user()->role == 'tu_pimpinan')
        @livewire('dashboard.tu-pimpinan-dashboard')
    @endif

     
        

</x-app-layout>
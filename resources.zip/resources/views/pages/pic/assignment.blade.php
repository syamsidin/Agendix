<x-app-layout>
    <x-slot name="header">
        Penugasan Widyaiswara
    </x-slot>

    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Daftar Kegiatan Internal yang Telah Disetujui</h3>
        </div>
        <div class="card-body">
            @livewire('pic.assignment')
        </div>
    </div>
</x-app-layout>
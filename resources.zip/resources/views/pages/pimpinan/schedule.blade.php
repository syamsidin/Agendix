<x-app-layout>
    <x-slot name="header">
        Jadwal Mengajar Widyaiswara
    </x-slot>

    @livewire('pimpinan.schedule')

</x-app-layout>
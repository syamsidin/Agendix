<x-app-layout>
    <x-slot name="header">
        Rekapitulasi Kinerja Widyaiswara
    </x-slot>

    @livewire('pimpinan.performance-recap')

</x-app-layout>
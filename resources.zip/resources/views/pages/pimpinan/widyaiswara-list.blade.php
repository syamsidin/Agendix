<x-app-layout>
    <x-slot name="header">
        Data Widyaiswara
    </x-slot>

    {{-- Panggil komponen Livewire di sini --}}
    @livewire('pimpinan.widyaiswara-list')

</x-app-layout>
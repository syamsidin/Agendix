<x-app-layout>
    <x-slot name="header">
        Buat Agenda Baru
    </x-slot>

    {{-- KODE INI BENAR ADA DI SINI --}}
    @livewire('agenda.submit-form')

</x-app-layout>
<x-app-layout>
    <x-slot name="header">
        Riwayat Pengajuan Agenda Saya
    </x-slot>

    <div class="card">
        <div class="card-body">
            @livewire('agenda.history')
        </div>
    </div>
</x-app-layout>
<x-app-layout>
    <x-slot name="header">Disposisi Acara Pimpinan</x-slot>
    @livewire('tu-pimpinan.dispositions')
</x-app-layout>
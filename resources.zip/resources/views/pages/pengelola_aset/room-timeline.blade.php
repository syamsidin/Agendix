<x-app-layout>
    <x-slot name="header">
        Jadwal Ruangan (Tampilan Timeline)
    </x-slot>

    @livewire('pengelola-aset.room-timeline')
</x-app-layout>
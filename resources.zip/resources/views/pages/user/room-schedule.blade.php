<x-app-layout>
    <x-slot name="header">
        Jadwal Penggunaan Ruangan
    </x-slot>

    {{-- Panggil komponen Livewire di sini --}}
    @livewire('user.room-schedule')

</x-app-layout>
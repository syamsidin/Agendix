<x-app-layout>
    <x-slot name="header">
        Manajemen Pengajuan Agenda
    </x-slot>

    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Daftar Agenda Internal yang Memerlukan Persetujuan</h3>
        </div>
        <div class="card-body">
            {{-- Panggil komponen Livewire di sini --}}
            @livewire('admin.agenda-management')
        </div>
    </div>
</x-app-layout>
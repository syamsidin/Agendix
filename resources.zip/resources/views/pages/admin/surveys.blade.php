<x-app-layout>
    <x-slot name="header">Respons Survey Pengguna</x-slot>
    @livewire('admin.survey-responses')
</x-app-layout>
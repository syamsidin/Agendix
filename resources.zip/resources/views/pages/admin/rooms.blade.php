<x-app-layout>
    <x-slot name="header">
        Manajemen Ruangan
    </x-slot>

    <div class="card">
        <div class="card-body">
            {{-- Komponen Livewire akan dipanggil di sini --}}
            @livewire('admin.room-management')
        </div>
    </div>
</x-app-layout>
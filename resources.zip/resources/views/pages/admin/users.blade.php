<x-app-layout>
    <x-slot name="header">Manajemen Pengguna</x-slot>
    @livewire('admin.user-management')
</x-app-layout>
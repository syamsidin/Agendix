<x-app-layout>
    <x-slot name="header">
        Manajemen Data Pejabat Struktural
    </x-slot>

    @livewire('admin.struktural-management')
</x-app-layout>
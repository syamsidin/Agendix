<x-app-layout>
    {{-- 1. Perbaiki Header --}}
    <x-slot name="header">
        Manajemen Widyaiswara
    </x-slot>

    <div class="card">
        <div class="card-body">
            {{-- 2. Panggil komponen Livewire yang benar --}}
            @livewire('admin.widyaiswara-management')
        </div>
    </div>
</x-app-layout>
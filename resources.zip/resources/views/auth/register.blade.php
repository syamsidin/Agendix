<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>Register - Agendix BPSDM Jabar</title>

    <!-- Fonts & Icons -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/boxicons/2.1.4/css/boxicons.min.css" />

    <!-- Styles (gunakan style yang sama persis dengan login.blade.php) -->
    <style>
        :root { --primary-color: #0062ff; --secondary-color: #f7b733; --bg-color: #f0f4f8; --text-color: #555; --heading-color: #222; --white-color: #fff; --light-gray-color: #eee; }
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: 'Poppins', sans-serif; background: var(--bg-color); display: flex; justify-content: center; align-items: center; min-height: 100vh; }
        .auth-container { display: flex; width: 900px; max-width: 100%; min-height: 550px; background: var(--white-color); border-radius: 15px; box-shadow: 0 5px 25px rgba(0, 0, 0, 0.1); overflow: hidden; }
        .auth-panel { flex: 1; padding: 3rem; }
        .auth-panel.illustration-panel { display: flex; flex-direction: column; justify-content: center; align-items: center; background-color: #f8faff; }
        .illustration-panel img { max-width: 90%; height: auto; }
        .auth-panel.form-panel { background-color: var(--primary-color); color: var(--white-color); display: flex; flex-direction: column; justify-content: center; }
        .form-panel h1 { font-weight: 700; margin-bottom: 2rem; }
        .input-group { position: relative; margin-bottom: 1.5rem; }
        .input-group i { position: absolute; left: 15px; top: 50%; transform: translateY(-50%); color: var(--text-color); }
        .input-group input { width: 100%; padding: 12px 15px 12px 45px; border-radius: 30px; border: none; background: var(--white-color); font-family: 'Poppins', sans-serif; }
        .input-group input:focus { outline: none; box-shadow: 0 0 0 2px var(--secondary-color); }
        .form-panel .error { color: #ffdddd; font-size: 0.8em; margin-top: -1rem; margin-bottom: 1rem; text-align: left; width: 100%; }
        .button-group { display: flex; gap: 1rem; margin-top: 1.5rem; }
        .button-group button, .button-group a { flex: 1; padding: 12px; border-radius: 30px; border: 1px solid var(--white-color); font-weight: 600; text-transform: uppercase; cursor: pointer; transition: all 0.3s ease; text-align: center; text-decoration: none; }
        .btn-primary { background-color: var(--secondary-color); border-color: var(--secondary-color); color: var(--heading-color); }
        .btn-primary:hover { background-color: #fcc24a; }
        .btn-secondary { background-color: transparent; color: var(--white-color); }
        .btn-secondary:hover { background-color: var(--white-color); color: var(--primary-color); }
        @media (max-width: 900px) {
            .auth-container { flex-direction: column; width: 95%; }
            .auth-panel.illustration-panel { display: none; }
        }
    </style>
</head>
<body>
    <div class="auth-container">
        <div class="auth-panel illustration-panel">
            <img src="{{ asset('images/auth-illustration.svg') }}" alt="Authentication Illustration">
        </div>
        <div class="auth-panel form-panel">
            <h1>Welcome!</h1>
            <p style="margin-bottom: 2rem;">Buat akun baru untuk mulai mengelola agenda kegiatan Anda.</p>
            
            <form method="POST" action="{{ route('register') }}">
                @csrf
                <!-- Name -->
                <div class="input-group">
                    <i class='bx bx-user'></i>
                    <input id="name" type="text" name="name" :value="old('name')" required autofocus autocomplete="name" placeholder="Your name" />
                </div>
                @error('name')<div class="error">{{ $message }}</div>@enderror
                
                <!-- Email Address -->
                <div class="input-group">
                    <i class='bx bx-envelope'></i>
                    <input id="email" type="email" name="email" :value="old('email')" required autocomplete="username" placeholder="Your e-mail" />
                </div>
                @error('email')<div class="error">{{ $message }}</div>@enderror

                <!-- Password -->
                <div class="input-group">
                    <i class='bx bx-lock-alt'></i>
                    <input id="password" type="password" name="password" required autocomplete="new-password" placeholder="Create password" />
                </div>
                 @error('password')<div class="error">{{ $message }}</div>@enderror
                
                <!-- Confirm Password -->
                <div class="input-group">
                    <i class='bx bx-lock-alt'></i>
                    <input id="password_confirmation" type="password" name="password_confirmation" required autocomplete="new-password" placeholder="Confirm password" />
                </div>

                <div class="button-group">
                    <a href="{{ route('login') }}" class="btn-secondary">Sign In</a>
                    <button type="submit" class="btn-primary">Create Account</button>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
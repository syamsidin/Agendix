<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>Agendix BPSDM</title>
    <link rel="icon" type="image/x-icon" href="{{ asset('favicon.ico') }}">

    <!-- AdminLTE 3 -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <!-- Google Font: Poppins -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <!-- FullCalendar -->
    <script src='https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/index.global.min.js'></script>
    <!-- ChartJS -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>


    @livewireStyles
    <style>
        .logo-container {
            display: flex;
            align-items: center;
            text-decoration: none;
            padding: 15px;
        }

        .logo-img {
            height: 35px; /* Sesuaikan tinggi logo Anda */
            width: auto;
            margin-right: 10px;
        }

        .logo-text {
            font-size: 2.0rem;
            font-weight: 700;
            color: white;
        }

        .modal-dialog-scrollable .modal-body {
            /* Tentukan tinggi maksimal, misal: 65% dari tinggi viewport */
            max-height: 65vh; 
            overflow-y: auto; /* Tampilkan scrollbar jika konten melebihi max-height */
        }
         /* 1. FONDASI: FONT & PALET WARNA */
        :root {
            --primary-color: #435EBE; /* Biru Indigo yang Elegan */
            --secondary-color: #5DD2B3; /* Hijau Mint Segar */
            --background-color: #F4F6F9; /* Abu-abu sangat terang */
            --text-color: #555;
            --heading-color: #25396f;
            --card-shadow: 0 4px 24px 0 rgba(34, 41, 47, .1);
            --card-border-radius: 0.5rem;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-color: var(--background-color);
            color: var(--text-color);
        }

        h1, h2, h3, h4, h5, h6 {
            color: var(--heading-color);
            font-weight: 600;
        }

        /* 2. OVERRIDE WARNA UTAMA ADMIN LTE */
        .main-sidebar {
            background-color: #191C2D !important; /* Warna sidebar gelap modern */
        }

        .nav-pills .nav-link.active, .nav-pills .show>.nav-link {
            background-color: var(--primary-color);
            box-shadow: var(--card-shadow);
        }

        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }

        .btn-primary:hover {
            background-color: #3850a2;
            border-color: #3850a2;
        }
        
        .badge-info {
             background-color: #a1d9ed !important;
             color: #1a4e63 !important;
        }
        
        .badge-success {
             background-color: var(--secondary-color) !important;
             color: #0c3e2e !important;
        }
        
        /* 3. PENYEMPURNAAN KOMPONEN */

        /* Card yang lebih modern */
        .card {
            border: none;
            border-radius: var(--card-border-radius);
            box-shadow: var(--card-shadow);
            transition: all 0.3s ease;
        }
        .card:hover {
            box-shadow: 0 8px 30px 0 rgba(34, 41, 47, .15);
        }

        /* Tabel yang lebih bersih */
        .table {
            border-collapse: separate;
            border-spacing: 0 10px; /* Jarak antar baris */
        }
        .table thead th {
            border-bottom: 2px solid #dee2e6 !important;
            border-top: none !important;
            font-weight: 600;
        }
        .table tbody td {
            vertical-align: middle;
            border-top: 1px solid #dee2e6 !important;
        }
        .table-bordered td, .table-bordered th {
             border: 1px solid #dee2e6 !important; /* Atur ulang border jika perlu */
        }
        
        /* Tombol yang lebih lembut */
        .btn {
            border-radius: 0.4rem;
            padding: 0.5rem 1rem;
            font-weight: 500;
        }
        .wrapper {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        
        /* Modal dengan sudut membulat */
        .modal-content {
            border-radius: var(--card-border-radius);
            border: none;
        }
        .modal-header {
            border-bottom: 1px solid #e9ecef;
        }
        .modal-footer {
            border-top: 1px solid #e9ecef;
        }
    </style>
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">

    <!-- Navbar -->
    <nav class="main-header navbar navbar-expand navbar-white navbar-light">
        <!-- Left navbar links -->
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
            </li>
        </ul>
        <!-- Right navbar links -->
        <ul class="navbar-nav ml-auto">
             @livewire('shared.notifications')
             <li class="nav-item dropdown">
                <a class="nav-link" data-toggle="dropdown" href="#">
                    <i class="far fa-user"></i> {{ Auth::user()->name }}
                </a>
                <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
                    <a href="{{ route('profile.edit') }}" class="dropdown-item">
                        <i class="fas fa-user-edit mr-2"></i> Profile
                    </a>
                    <div class="dropdown-divider"></div>
                    <!-- Authentication -->
                    <form method="POST" action="{{ route('logout') }}">
                        @csrf
                        <a href="{{ route('logout') }}" class="dropdown-item"
                           onclick="event.preventDefault(); this.closest('form').submit();">
                           <i class="fas fa-sign-out-alt mr-2"></i> {{ __('Log Out') }}
                        </a>
                    </form>
                </div>
            </li>
        </ul>
    </nav>
    <!-- /.navbar -->

    <!-- Main Sidebar Container -->
    <aside class="main-sidebar sidebar-dark-primary elevation-4">
        <!-- Brand Logo -->

        <a href="#hero" class="logo-container">
            <img src="{{ asset('agendix.png') }}" alt="Logo Agendix" class="logo-img">
            <span class="logo-text">Agendix</span>
        </a>


        <!-- Sidebar -->
        <div class="sidebar">

            <!-- Sidebar Menu -->
            <nav class="mt-2">
                <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                    <li class="nav-item">
                        <a href="{{ route('dashboard') }}" class="nav-link {{ request()->routeIs('dashboard') ? 'active' : '' }}">
                            <i class="nav-icon fas fa-tachometer-alt"></i>
                            <p>Dashboard</p>
                        </a>
                    </li>

                    @if(auth()->user()->role == 'user')
                        <li class="nav-item">
                           <a href="{{ route('agenda.submit') }}" class="nav-link {{ request()->routeIs('agenda.submit') ? 'active' : '' }}">
                                <i class="nav-icon fas fa-plus-square"></i>
                                <p>Buat Agenda</p>
                            </a>
                        </li>
                        <li class="nav-item">
                           <a href="{{ route('agenda.history') }}" class="nav-link {{ request()->routeIs('agenda.history') ? 'active' : '' }}">
                                <i class="nav-icon fas fa-history"></i>
                                <p>Riwayat Agenda</p>
                            </a>
                        </li>
                         <li class="nav-item">
                           <a href="{{ route('user.room-schedule') }}" class="nav-link {{ request()->routeIs('user.room-schedule') ? 'active' : '' }}">
                                <i class="nav-icon fas fa-calendar-day"></i>
                                <p>Jadwal Ruangan</p>
                            </a>
                        </li>
                    @endif

                    @if(in_array(auth()->user()->role, ['pengelola_aset']))
                        <li class="nav-header">PENGELOLA ASET</li>                           
                    {{-- Menu Manajemen Agenda --}}
                    <li class="nav-item">
                        <a href="{{ route('admin.agenda.management') }}" class="nav-link {{ request()->routeIs('admin.agenda.management') ? 'active' : '' }}">
                            <i class="nav-icon fas fa-calendar-check"></i>
                            <p>Manajemen Agenda</p>
                        </a>
                    </li>
                    
                    {{-- Menu Manajemen Ruangan --}}
                    <li class="nav-item">
                        <a href="{{ route('admin.rooms') }}" class="nav-link {{ request()->routeIs('admin.rooms') ? 'active' : '' }}">
                            <i class="nav-icon fas fa-door-open"></i>
                            <p>Manajemen Ruangan</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ route('admin.room-timeline') }}" class="nav-link {{ request()->routeIs('admin.room-timeline') ? 'active' : '' }}">
                            <i class="nav-icon fas fa-th"></i>
                            <p>Timeline Ruangan</p>
                        </a>
                    </li>
                     @endif

                    @if(auth()->user()->role == 'admin')
                        <li class="nav-header">ADMINISTRATOR</li>
                        <li class="nav-item">
                            <a href="{{ route('admin.agenda.management') }}" class="nav-link {{ request()->routeIs('admin.agenda.management') ? 'active' : '' }}">
                                <i class="nav-icon fas fa-calendar-check"></i>
                                <p>Manajemen Agenda</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ route('admin.users') }}" class="nav-link {{ request()->routeIs('admin.users') ? 'active' : '' }}">
                                <i class="nav-icon fas fa-users"></i>
                                <p>Manajemen Pengguna</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ route('admin.struktural') }}" class="nav-link {{ request()->routeIs('admin.struktural') ? 'active' : '' }}">
                                <i class="nav-icon fas fa-sitemap"></i>
                                <p>Manajemen Struktural</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ route('admin.rooms') }}" class="nav-link {{ request()->routeIs('admin.rooms') ? 'active' : '' }}">
                                <i class="nav-icon fas fa-door-open"></i>
                                <p>Manajemen Ruangan</p>
                            </a>
                        </li>
                         <li class="nav-item">
                            <a href="{{ route('admin.widyaiswara') }}" class="nav-link {{ request()->routeIs('admin.widyaiswara') ? 'active' : '' }}">
                                <i class="nav-icon fas fa-chalkboard-teacher"></i>
                                <p>Manajemen Widyaiswara</p>
                            </a>
                        </li>
                        <li class="nav-item">
                                <a href="{{ route('admin.surveys') }}" class="nav-link {{ request()->routeIs('admin.surveys') ? 'active' : '' }}">
                                    <i class="nav-icon fas fa-poll"></i>
                                    <p>Respons Survey</p>
                                </a>
                            </li>
                    @endif

                     @if(in_array(auth()->user()->role, ['pic_wi', 'pimpinan']))
                        <li class="nav-header">WIDYAISWARA</li>
                     @endif
                     @if(auth()->user()->role == 'pic_wi')
                        <li class="nav-item">
                            <a href="{{ route('pic.assignment') }}" class="nav-link {{ request()->routeIs('pic.assignment') ? 'active' : '' }}">
                                <i class="nav-icon fas fa-tasks"></i>
                                <p>Penugasan WI</p>
                            </a>
                        </li>
                     @endif
                     @if(auth()->user()->role == 'pimpinan')
                        <li class="nav-item">
                            <a href="{{ route('pimpinan.schedule') }}" class="nav-link {{ request()->routeIs('pimpinan.schedule') ? 'active' : '' }}">
                                <i class="nav-icon fas fa-calendar-alt"></i>
                                <p>Jadwal WI Realtime</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ route('pimpinan.performance.recap') }}" class="nav-link {{ request()->routeIs('pimpinan.performance.recap') ? 'active' : '' }}">
                                <i class="nav-icon fas fa-chart-line"></i>
                                <p>Rekap Kinerja WI</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ route('pimpinan.widyaiswara.list') }}" class="nav-link {{ request()->routeIs('pimpinan.widyaiswara.list') ? 'active' : '' }}">
                                <i class="nav-icon fas fa-users"></i>
                                <p>Data Widyaiswara</p>
                            </a>
                        </li>
                     @endif

                     @if(auth()->user()->role == 'tu_pimpinan')
                        <li class="nav-header">TU PIMPINAN </li>

                        <li class="nav-item">
                            <a href="{{ route('tu.dispositions') }}" 
                            class="nav-link {{ request()->routeIs('tu.dispositions') ? 'active' : '' }}">
                                <i class="fas fa-file-signature"></i><p>Disposisi Acara</p></a>
                        </li>
                        <li class="nav-item">
                           <a href="{{ route('agenda.submit') }}" class="nav-link {{ request()->routeIs('agenda.submit') ? 'active' : '' }}">
                                <i class="nav-icon fas fa-plus-square"></i>
                                <p>Buat Agenda</p>
                            </a>
                        </li>
                        <li class="nav-item">
                           <a href="{{ route('agenda.history') }}" class="nav-link {{ request()->routeIs('agenda.history') ? 'active' : '' }}">
                                <i class="nav-icon fas fa-history"></i>
                                <p>Riwayat Agenda</p>
                            </a>
                        </li>
                         <li class="nav-item">
                           <a href="{{ route('user.room-schedule') }}" class="nav-link {{ request()->routeIs('user.room-schedule') ? 'active' : '' }}">
                                <i class="nav-icon fas fa-calendar-day"></i>
                                <p>Jadwal Ruangan</p>
                            </a>
                        </li>
                    @endif  
                </ul>
            </nav>
            <!-- /.sidebar-menu -->
        </div>
        <!-- /.sidebar -->
    </aside>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">{{ $header ?? 'Page' }}</h1>
                    </div>
                </div>
            </div>
        </div>
        <!-- /.content-header -->

        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                {{ $slot }}
            </div>
        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->

 <footer class="py-3 text-center" style="background-color: #121421; color: #6c757d; font-size: 0.9rem;">
        Copyright ©sem 2025 Agendix BPSDM Jabar . All Rights Reserved.
    </footer>
</div>
<!-- ./wrapper -->

<!-- REQUIRED SCRIPTS -->
<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<!-- Bootstrap 4 -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/js/adminlte.min.js"></script>

@livewireScripts
@stack('scripts')
@livewire('shared.survey-form')
 @if(session('show_survey'))
        <script>
            document.addEventListener('livewire:initialized', () => {
                Livewire.dispatch('showSurvey', { 
                    referenceId: "{{ session('show_survey')['id'] }}", 
                    referenceType: "{{ session('show_survey')['type'] }}" 
                });
                Livewire.on('closeModal', () => {
                    $('.modal').modal('hide');
                });
            });
        </script>
    @endif

</body>
</html>
<header class="header">
    <nav class="navbar navbar-expand-lg">
        <div class="container">
            <a class="navbar-brand" href="{{ route('welcome') }}">
                <img src="{{ asset('agendix.png') }}" alt="Logo Agendix" style="height: 40px;" class="d-inline-block align-text-top me-2">
                Agendix
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto align-items-center">
                    {{-- TAMBAHKAN LOGIKA 'active' DI SINI --}}
                    <li class="nav-item">
                        <a class="nav-link {{ request()->routeIs('welcome') ? 'active' : '' }}" href="{{ route('welcome') }}">Beranda</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link {{ request()->routeIs('public.rooms.gallery') || request()->routeIs('public.rooms.detail') ? 'active' : '' }}" href="{{ route('public.rooms.gallery') }}">Ruangan</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link {{ request()->routeIs('public.calendar') ? 'active' : '' }}" href="{{ route('public.calendar') }}">Kalender</a>
                    </li>
                    <li class="nav-item ms-lg-3 mt-2 mt-lg-0">
                        @auth
                            <a href="{{ url('/dashboard') }}" class="btn btn-login">Dashboard</a>
                        @else
                            <a href="{{ route('login') }}" class="btn btn-login">Login</a>
                        @endauth
                    </li>
                </ul>
            </div>
        </div>
    </nav>
</header>
<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Agendix Bpsdm Jabar</title>
    <link rel="icon" type="image/x-icon" href="{{ asset('agendix.png') }}">

    <!-- Aset CSS Wajib -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">


    @livewireStyles

    <!-- Styles Kustom -->
    <style>
        :root {
            --primary-color: #435ebe;
            --secondary-color: #198754; /* Warna hijau untuk fitur */
            --bg-light: #f4f6f9;
            --text-dark: #25396f;
            --text-light: #6c757d;
        }
        html { scroll-behavior: smooth; }
        body { font-family: 'Poppins', sans-serif; background-color: #fff; }
        .section { padding: 80px 0; }
        .section-title { text-align: center; margin-bottom: 50px; }
        .section-title h2 { font-size: 2.5rem; font-weight: 700; color: var(--text-dark); }
        .section-title p { max-width: 600px; margin: 10px auto 0; color: var(--text-light); }
        
        /* Header */
        .header { position: sticky; top: 0; width: 100%; background-color: #fff; z-index: 1030; box-shadow: 0 2px 10px rgba(0,0,0,0.05); }
        .navbar-brand { font-weight: 700; color: var(--primary-color); }
        .nav-link { color: var(--text-dark); font-weight: 500; position: relative; padding-bottom: 0.5rem; margin: 0 1rem; }
        .nav-link::after { content: ''; position: absolute; width: 0; height: 2px; bottom: 0; left: 50%; transform: translateX(-50%); background-color: var(--primary-color); transition: width 0.3s ease; }
        .nav-link:hover::after, .nav-link.active::after { width: 100%; }
        .nav-link:hover, .nav-link.active { color: var(--primary-color); }
        .btn-login { background-color: var(--primary-color); color: #fff; padding: 8px 24px; border-radius: 50px; text-decoration: none; transition: all 0.3s ease; }
        .btn-login:hover { transform: translateY(-2px); box-shadow: 0 4px 15px rgba(67, 94, 190, 0.3); }
        /* Hero Section */
        #hero { background-color: var(--bg-light); padding: 6rem 0; display: flex; align-items: center; min-height: 90vh;}
        #hero h1 { font-size: 3.5rem; font-weight: 800; line-height: 1.2; }
        



        /* Features Section */
        .feature-box {
            padding: 30px;
            background: #fff;
            border-radius: 1rem;
            text-align: center;
            box-shadow: 0 10px 30px rgba(0,0,0,0.07);
            transition: all 0.3s ease;
            height: 100%;
        }
        .feature-box:hover { transform: translateY(-10px); }
        .feature-icon {
            font-size: 3rem;
            width: 80px;
            height: 80px;
            line-height: 80px;
            border-radius: 50%;
            background-color: var(--secondary-color);
            color: #fff;
            margin: 0 auto 20px;
        }
        .feature-box h5 { font-weight: 600; color: var(--text-dark); margin-bottom: 15px; }
        .feature-box p { font-size: 0.95rem; }

        /* Featured Gallery Section */
        #gallery { background-color: var(--bg-light); }
        .gallery-item {
            position: relative;
            overflow: hidden;
            border-radius: 1rem;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }
        .gallery-item img {
            width: 100%;
            height: 400px;
            object-fit: cover;
            transition: transform 0.4s ease;
        }
        .gallery-item:hover img { transform: scale(1.1); }
        
        /* Contact Section */
        .contact-info { display: flex; align-items: flex-start; margin-bottom: 1.5rem; }
        .contact-info .icon { font-size: 1.5rem; color: var(--primary-color); margin-right: 20px; width: 40px; }
        .social-links a { font-size: 1.5rem; color: #fff; margin: 0 10px; transition: color 0.3s ease; }
        .social-links a:hover { color: var(--primary-color); }
        
        .footer { background-color: var(--text-dark); }
    </style>
    @stack('styles')
</head>
<body>
    <header class="header">
         @include('layouts.partials.public-navigation')
    </header>

    <main>
        <section id="hero">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-6">
                        <h1 class="text-dark">Agendix BPSDM</h1>
                        <p class="lead my-4">Platform terintegrasi untuk manajemen agenda, ruangan, dan penugasan widyaiswara di lingkungan BPSDM.</p>
                        <a href="{{ route('login') }}" class="btn btn-primary btn-lg rounded-pill px-4">Mulai Gunakan</a>
                        <div style="height: 30px;"></div>
                    </div>
                    <div class="col-lg-6 text-center">
                        <img src="{{ asset('images/landing-illustration.svg') }}" alt="Ilustrasi" class="img-fluid">
                    </div>
                </div>
            </div>
        </section>

        <!-- ================= FEATURES SECTION ================= -->
        <section id="features" class="section">
            <div class="container">
                <div class="section-title">
                    <h2>Ekosistem Terintegrasi</h2>
                    <p>Agendix dirancang untuk menyederhanakan alur kerja Anda melalui beberapa aplikasi inti yang saling terhubung.</p>
                </div>
                <div class="row">
                    <div class="col-lg-3 col-md-6 mb-4">
                        <div class="feature-box">
                            <div class="feature-icon"><i class="fas fa-calendar-alt"></i></div>
                            <h5>Agenda BPSDM</h5>
                            <p>Ini adalah aplikasi utama untuk mencatat semua kegiatan resmi di BPSDM. Mulai dari rapat, pelatihan, hingga kunjungan kerja. Semua kegiatan yang dibuat di sini akan otomatis tersambung ke aplikasi lain.</p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 mb-4">
                        <div class="feature-box">
                            <div class="feature-icon"><i class="fas fa-door-open"></i></div>
                            <h5>Booking Tempat</h5>
                            <p>Begitu kegiatan dibuat di Agenda BPSDM dan memilih tempat, sistem langsung akan memesan ruangan secara otomatis. Jadi, tidak perlu booking manual lagi dan ruangan bisa dipastikan tersedia.</p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 mb-4">
                        <div class="feature-box">
                            <div class="feature-icon"><i class="fas fa-chalkboard-teacher"></i></div>
                            <h5>Penugasan Widyaiswara</h5>
                            <p>Jika kegiatan tersebut butuh widyaiswara (misalnya pelatihan), maka sistem akan otomatis menyiapkan daftar penugasan untuk widyaiswara yang sesuai, lengkap dengan jadwal dan detail tugasnya.</p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 mb-4">
                        <div class="feature-box">
                            <div class="feature-icon"><i class="fas fa-user-tie"></i></div>
                            <h5>Penugasan Pimpinan</h5>
                            <p>Kalau kegiatan mengundang pimpinan atau perlu kehadiran pejabat tertentu, maka informasinya langsung muncul di aplikasi penugasan pimpinan. Jadi pimpinan tahu agenda apa saja yang perlu diikuti.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- ================= CONTACT SECTION ================= -->
        <section id="contact" class="footer">
            <div class="container text-white">
                 <div class="section-title">
                    <div style="height: 50px;"></div>
                    <h2 class="text-white">Hubungi Kami</h2>
                </div>
                <div class="row justify-content-center">
                    <div class="col-lg-10">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="contact-info">
                                    <div class="icon"><i class="fas fa-map-marker-alt"></i></div>
                                    <div><strong>Alamat</strong><br><small>Jl. Kolonel Masturi No.11, KM 3,5, Cipageran, Cimahi</small></div>
                                </div>
                            </div>
                             <div class="col-md-4">
                                <div class="contact-info">
                                    <div class="icon"><i class="fas fa-phone"></i></div>
                                    <div><strong>Telepon</strong><br><small>022-6649471</small></div>
                                </div>
                            </div>
                             <div class="col-md-4">
                                <div class="contact-info">
                                    <div class="icon"><i class="fas fa-envelope"></i></div>
                                    <div><strong>Email</strong><br><small>bpsdm@jabarprov.go.id</small></div>
                                </div>
                            </div>
                        </div>
                        <div class="text-center social-links">
                            <a href="https://www.instagram.com/bpsdmjabar" aria-label="Instagram"><i class="fab fa-instagram"></i></a>
                            <a href="https://x.com/bpsdmjabar" aria-label="X"><i class="fab fa-x"></i></a>
                            <a href="https://www.facebook.com/bpsdmjabar1" aria-label="Facebook"><i class="fab fa-facebook-f"></i></a>
                            <a href="https://www.youtube.com/@BpsdmJabar" aria-label="Youtube"><i class="fab fa-youtube"></i></a>
                            <a href="https://www.tiktok.com/@bpsdm_jabar?_t=ZS-8xWuMkCbJxQ&_r=1" aria-label="Tiktok"><i class="fab fa-tiktok"></i></a>
                        </div>
                         <div style="height: 30px;"></div>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <footer class="py-3 text-center" style="background-color: #121421; color: #6c757d; font-size: 0.9rem;">
         Copyright ©sem 2025 Agendix BPSDM Jabar . All Rights Reserved.
    </footer>
     {{-- SCRIPT PENTING --}}
    @livewireScripts
    
    {{-- Aset JavaScript yang diperlukan oleh komponen --}}
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    
    {{-- ======================================================= --}}
    {{--          BAGIAN KUNCI YANG HILANG ADA DI SINI           --}}
    {{-- ======================================================= --}}
    {{-- Ini akan "menarik" dan merender semua script yang di-push dari komponen anak --}}
    @stack('scripts')

    @livewireScripts
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
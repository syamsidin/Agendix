<div>
    {{-- Card untuk Filter --}}
    <div class="card mb-4">
        <div class="card-body">
            <div class="row align-items-center">
                <div class="col-md-4">
                    <h5 class="mb-md-0 mb-2">Filter Rekapitulasi</h5>
                </div>
                <div class="col-md-8">
                    <div class="d-flex justify-content-end align-items-center">
                        <div class="input-group mr-3" style="width: 250px;">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fas fa-search"></i></span>
                            </div>
                            <input type="text" wire:model.live.debounce.300ms="search" class="form-control" placeholder="Cari WI...">
                        </div>
                        <div class="input-group" style="width: 350px;">
                            <input type="date" wire:model.live="startDate" class="form-control">
                            <span class="input-group-text">s/d</span>
                            <input type="date" wire:model.live="endDate" class="form-control">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    {{-- Hasil Rekapitulasi --}}
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Menampilkan data untuk periode: <strong>{{ \Carbon\Carbon::parse($startDate)->isoFormat('D MMMM YYYY') }} - {{ \Carbon\Carbon::parse($endDate)->isoFormat('D MMMM YYYY') }}</strong></h3>
        </div>
        <div class="card-body">
            {{-- Header untuk List --}}
            <div class="d-none d-md-flex row text-muted mb-2 font-weight-bold">
                <div class="col-md-1">No.</div>
                <div class="col-md-6">Nama Widyaiswara</div>
                <div class="col-md-3 text-center">Jumlah Mengajar</div>
                <div class="col-md-2 text-center">Total JP</div>
            </div>

            {{-- List Data --}}
            @forelse($widyaiswaras as $index => $widyaiswara)
                <div class="card mb-2 shadow-sm">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col-12 col-md-1 text-center">
                                <span class="h5">{{ $widyaiswaras->firstItem() + $index }}</span>
                            </div>
                            <div class="col-12 col-md-6">
                                <strong class="d-block">{{ $widyaiswara->name }}</strong>
                                <small class="text-muted">NIP: {{ $widyaiswara->nip }}</small>
                            </div>
                            <div class="col-6 col-md-3 text-center mt-2 mt-md-0">
                                <span class="badge badge-primary px-3 py-2" style="font-size: 1rem;">
                                    {{ $widyaiswara->assignments_count }}
                                </span>
                            </div>
                            <div class="col-6 col-md-2 text-center mt-2 mt-md-0">
                                <span class="badge badge-success px-3 py-2" style="font-size: 1rem;">
                                    {{ $widyaiswara->total_jp ?? 0 }} JP
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            @empty
                <div class="text-center p-5">
                    <p class="text-muted">
                        @if(empty($search))
                            Tidak ada data kinerja untuk periode yang dipilih.
                        @else
                            Tidak ada Widyaiswara yang cocok dengan pencarian "{{ $search }}".
                        @endif
                    </p>
                </div>
            @endforelse
            
            {{-- Paginasi --}}
            <div class="mt-4 d-flex justify-content-center">
                {{ $widyaiswaras->links() }}
            </div>
        </div>
    </div>
</div>
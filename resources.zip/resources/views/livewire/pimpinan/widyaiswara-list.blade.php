<div class="card">
    <div class="card-header d-flex justify-content-between">
        <h3 class="card-title mb-0">Daftar Widyaiswara BPSDM</h3>
        <div style="width: 300px;">
            <input type="text" wire:model.live.debounce.300ms="search" class="form-control" placeholder="Cari nama atau NIP...">
        </div>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered table-hover">
                <thead class="thead-light">
                    <tr>
                        <th>No.</th>
                        <th>Nama</th>
                        <th>NIP</th>
                        <th>Jabatan</th>
                        <th>Pangkat/Gol.</th>
                        <th>Kontak WhatsApp</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($widyaiswaras as $index => $widyaiswara)
                    <tr>
                        <td>{{ $widyaiswaras->firstItem() + $index }}</td>
                        <td>{{ $widyaiswara->name }}</td>
                        <td>{{ $widyaiswara->nip }}</td>
                        <td>{{ $widyaiswara->position }}</td>
                        <td>{{ $widyaiswara->rank }}</td>
                        <td>{{ $widyaiswara->whatsapp }}</td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="6" class="text-center">Tidak ada data Widyaiswara yang ditemukan.</td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        <div class="mt-3">
            {{ $widyaiswaras->links() }}
        </div>
    </div>
</div>
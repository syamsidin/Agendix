<div>
    <div class="card">
        <div class="card-header">
            <div class="d-flex justify-content-between align-items-center">
                <h3 class="card-title">Jadwal untuk tanggal: <strong>{{ \Carbon\Carbon::parse($selectedDate)->isoFormat('dddd, D MMMM YYYY') }}</strong></h3>
                <div class="card-tools">
                    <div class="btn-group">
                        <button wire:click="previousDay" class="btn btn-default btn-sm" title="Hari Sebelumnya"><i class="fas fa-chevron-left"></i></button>
                        <button wire:click="goToToday" class="btn btn-default btn-sm" title="Hari Ini">Hari Ini</button>
                        <button wire:click="nextDay" class="btn btn-default btn-sm" title="Hari Berikutnya"><i class="fas fa-chevron-right"></i></button>
                    </div>
                </div>
            </div>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th style="width: 25%;">Widyaiswara</th>
                            <th style="width: 25%;">Kegiatan</th>
                            <th style="width: 20%;">Tempat</th>
                            <th style="width: 30%;">Waktu & Materi</th>
                            <th style="width: 10%;" class="text-center">Bukti Dukung</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse ($assignments as $assignment)
                            <tr>
                                <td>{{ optional($assignment->widyaiswara)->name ?? 'N/A' }}</td>
                                {{-- Ganti ke path baru --}}
                                <td>{{ optional($assignment->agendaDetail->agenda)->title ?? 'N/A' }}</td>
                                <td>
                                    {{-- Ganti ke path baru --}}
                                    @if(optional($assignment->agendaDetail->agenda)->type == 'internal')
                                        {{ optional($assignment->agendaDetail->room)->name ?? 'N/A' }}
                                    @else
                                        {{ optional($assignment->agendaDetail)->manual_location ?? 'N/A' }}
                                    @endif
                                </td>
                                <td>
                                    {{-- Kolom ini sudah benar karena mengambil dari $assignment --}}
                                    <span class="badge badge-primary">{{ \Carbon\Carbon::parse($assignment->start_time)->format('H:i') }}</span>
                                    {{ $assignment->material }} ({{ $assignment->jp }} JP)
                                </td>
                                <td class="text-center">
                                    @if ($assignment->attachment_path)
                                        <a href="{{ asset('storage/' . $assignment->attachment_path) }}" target="_blank" class="btn btn-sm btn-outline-primary" title="Lihat/Download Bukti Dukung">
                                            <i class="fas fa-download"></i>
                                        </a>
                                    @else
                                        <span class="text-muted">-</span>
                                    @endif
                                </td>
                            </tr>
                        @empty
                            {{-- ... --}}
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
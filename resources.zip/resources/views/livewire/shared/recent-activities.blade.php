<div class="card">
    <div class="card-header">
        <h3 class="card-title">
            <i class="fas fa-inbox mr-2"></i>
            Agenda Pending
        </h3>
    </div>
    <div class="card-body p-0">
        @if($recentAgendas->isNotEmpty())
            <ul class="list-group list-group-flush">
                @foreach($recentAgendas as $agenda)
                    <li class="list-group-item">
                        <div class="d-flex w-100 justify-content-between">
                            <h6 class="mb-1 font-weight-bold">{{ $agenda->title }}</h6>
                            {{-- Badge status tidak terlalu perlu karena semua pasti pending, tapi bisa dipertahankan --}}
                            <span class="badge badge-warning">Pending</span>
                        </div>
                        <p class="mb-1 text-muted">
                            <i class="fas fa-user fa-fw"></i> 
                            Diajukan oleh: <strong>{{ $agenda->user->name }}</strong>
                        </p>
                        
                        @if($agenda->details->isNotEmpty())
                            @php $firstDetail = $agenda->details->first(); @endphp
                            <small class="d-block">
                                <i class="fas fa-calendar-alt fa-fw"></i>
                                {{ \Carbon\Carbon::parse($firstDetail->start_date)->isoFormat('D MMM Y') }}
                            </small>
                            <small class="d-block">
                                 <i class="fas fa-clock fa-fw"></i>
                                 {{ \Carbon\Carbon::parse($firstDetail->start_time)->format('H:i') }} - {{ \Carbon\Carbon::parse($firstDetail->end_time)->format('H:i') }}
                            </small>
                            <small class="d-block">
                                <i class="fas fa-map-marker-alt fa-fw"></i>
                                 @if($agenda->type == 'internal')
                                    {{ $firstDetail->room->name ?? 'N/A' }}
                                 @else
                                    {{ $firstDetail->manual_location ?? 'N/A' }}
                                 @endif
                            </small>
                        @endif
                    </li>
                @endforeach
            </ul>
        @else
            <div class="text-center text-muted p-4">
                <i class="fas fa-check-circle fa-2x text-success mb-2"></i>
                <p>Tidak ada agenda yang menunggu persetujuan saat ini.</p>
            </div>
        @endif
    </div>
</div>
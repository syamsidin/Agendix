<div>
    {{-- ======================================================= --}}
    {{--          FORM FILTER BARU                             --}}
    {{-- ======================================================= --}}
    <div class="card mb-4">
        <div class="card-header">
            <h3 class="card-title"><i class="fas fa-filter mr-2"></i> Filter Kalender</h3>
        </div>
        <div class="card-body">
            <div class="row align-items-end">
                <div class="col-md-4">
                    <div class="form-group">
                        <label>Dari Tanggal:</label>
                        <input type="date" wire:model.live="startDateFilter" class="form-control">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label>Sampai Tanggal:</label>
                        <input type="date" wire:model.live="endDateFilter" class="form-control">
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label>Bidang Penyelenggara:</label>
                        <select wire:model.live="departmentFilter" class="form-control">
                            <option value="">-- Semua Bidang --</option>
                            @foreach($departments as $dept)
                                <option value="{{ $dept }}">{{ $dept }}</option>
                            @endforeach
                        </select>
                    </div>
                </div>
                <div class="col-md-1">
                    <div class="form-group">
                        <button wire:click="resetFilters" class="btn btn-secondary w-100" title="Hapus Filter">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

 {{-- ======================================================= --}}
    {{--          LIST HASIL FILTER (BAGIAN BARU)                --}}
    {{-- ======================================================= --}}
    @if($filteredAgendas)
        <div class="card mb-4">
            <div class="card-header">
                <h3 class="card-title">Hasil Filter ({{ $filteredAgendas->total() }} Kegiatan Ditemukan)</h3>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Nama Kegiatan</th>
                                <th>Penyelenggara</th>
                                <th>Jadwal & Lokasi</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($filteredAgendas as $agenda)
                                <tr>
                                    <td>{{ $agenda->title }}</td>
                                    <td>{{ $agenda->user->name ?? 'N/A' }} <br><small>({{ $agenda->user->department_name }})</small></td>
                                    <td>
                                        @foreach($agenda->details as $detail)
                                            <div class="mb-1 {{ !$loop->last ? 'pb-1 border-bottom' : '' }}">
                                                <i class="fas fa-calendar-alt fa-fw"></i> {{ \Carbon\Carbon::parse($detail->start_date)->isoFormat('D MMM Y') }}
                                                <br>
                                                <i class="fas fa-map-marker-alt fa-fw"></i> {{ $detail->room->name ?? $detail->manual_location ?? 'N/A' }}
                                            </div>
                                        @endforeach
                                    </td>
                                </tr>
                            @empty
                                <tr><td colspan="3" class="text-center">Tidak ada kegiatan yang cocok dengan filter Anda.</td></tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
                <div class="mt-3">
                    {{ $filteredAgendas->links() }}
                </div>
            </div>
        </div>
    @endif


<div>
    {{-- Kalender akan dirender di sini --}}
      @livewire('shared.recent-activities')
    <div wire:ignore id='calendar'></div>

    {{-- ====================================================================== --}}
    {{-- MODAL 1: Untuk Detail Agenda (Saat event/bubble di-klik) - DIPERBAIKI --}}
    {{-- ====================================================================== --}}
    <div wire:ignore.self class="modal fade" id="agendaDetailModal" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-lg" role="document"> {{-- Dibuat lebih besar (lg) --}}
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                    Detail Agenda 
                    @if($selectedAgenda)
                        @if($selectedAgenda->type == 'internal')
                            <span class="badge badge-info">Internal</span>
                        @else
                            <span class="badge badge-success">Eksternal</span>
                        @endif
                    @endif
                </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    @if($selectedAgenda)
                        {{-- Informasi Induk Agenda --}}
                        <h5 class="font-weight-bold">{{ $selectedAgenda->title }}</h5>
                        <p><strong>Penyelenggara:</strong> {{ $selectedAgenda->user->name ?? 'N/A' }}</p>
                        @if($selectedAgenda->konseptor_name)
                        <p><strong>Konseptor:</strong> {{ $selectedAgenda->konseptor_name }}</p>
                        @endif
                        <p><strong>Deskripsi:</strong><br>{!! nl2br(e($selectedAgenda->description)) !!}</p>
                        <hr>
                        
                        {{-- Detail Jadwal (dengan perulangan) --}}
                        <h6><strong>Detail Jadwal dan Lokasi:</strong></h6>
                        @if($selectedAgenda->details->isNotEmpty())
                            @foreach($selectedAgenda->details as $detail)
                                <div class="card card-outline card-secondary mb-2">
                                    <div class="card-body p-2" style="font-size: 0.9rem;">
                                        <div><i class="fas fa-calendar-alt fa-fw text-muted"></i> {{ \Carbon\Carbon::parse($detail->start_date)->isoFormat('dddd, D MMM Y') }} s/d {{ \Carbon\Carbon::parse($detail->end_date)->isoFormat('dddd, D MMM Y') }}</div>
                                        <div><i class="fas fa-clock fa-fw text-muted"></i> {{ \Carbon\Carbon::parse($detail->start_time)->format('H:i') }} - {{ \Carbon\Carbon::parse($detail->end_time)->format('H:i') }}</div>
                                        <div><i class="fas fa-map-marker-alt fa-fw text-muted"></i> 
                                            @if($selectedAgenda->type == 'internal')
                                                <strong>{{ $detail->room->name ?? 'N/A' }}</strong>
                                            @else
                                                <strong>{{ $detail->manual_location }}</strong>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                            @endforeach
                        @else
                            <p class="text-muted">Tidak ada detail jadwal untuk agenda ini.</p>
                        @endif

                    @endif
                </div>
            </div>
        </div>
    </div>

    {{-- -------------------------------------------------------------------- --}}
    {{-- MODAL 2: Untuk Daftar Kegiatan per Hari (Saat tanggal di-klik) - TIDAK BERUBAH --}}
    {{-- -------------------------------------------------------------------- --}}
    <div wire:ignore.self class="modal fade" id="dayActivitiesModal" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        Daftar Kegiatan untuk {{ $selectedDateForModal ? \Carbon\Carbon::parse($selectedDateForModal)->isoFormat('dddd, D MMMM YYYY') : '' }}
                    </h5>
                    <button type="button" wire:click="$dispatch('hide-modals')" class="close" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </button>
                </div>
               <div class="modal-body">
                @if(!empty($dayActivities))
                    @forelse($dayActivities as $detail)
                        {{-- =============================================== --}}
                        {{--           PERUBAHAN STRUKTUR DI SINI            --}}
                        {{-- =============================================== --}}
                        <div class="card mb-3 shadow-sm">
                            <div class="card-body">
                                {{-- Judul dan Tipe --}}
                                <h5 class="card-title font-weight-bold d-flex justify-content-between">
                                    <span>{{ $detail->agenda->title ?? 'N/A' }}</span>
                                    @if(optional($detail->agenda)->type == 'internal')
                                        <span class="badge badge-info">Internal</span>
                                    @else
                                        <span class="badge badge-success">Eksternal</span>
                                    @endif
                                </h5>
                                <hr class="mt-2 mb-3">
                                
                                {{-- Detail Jadwal --}}
                                <p class="mb-1"><i class="fas fa-clock fa-fw text-muted"></i> <strong>Waktu:</strong> {{ \Carbon\Carbon::parse($detail->start_time)->format('H:i') }} - {{ \Carbon\Carbon::parse($detail->end_time)->format('H:i') }}</p>
                                <p class="mb-1"><i class="fas fa-map-marker-alt fa-fw text-muted"></i> <strong>Tempat:</strong> {{ $detail->agenda->type == 'internal' ? (optional($detail->room)->name ?? 'N/A') : $detail->manual_location }}</p>
                                <p class="mb-2"><i class="fas fa-file-alt fa-fw text-muted"></i> <strong>Deskripsi:</strong> {{ Str::limit(optional($detail->agenda)->description, 100) }}</p>

                                {{-- Detail Pengajar (Widyaiswara) --}}
                                <p class="mb-2">
                                    <i class="fas fa-chalkboard-teacher fa-fw text-muted"></i> <strong>Pengajar:</strong><br>
                                    @forelse($detail->assignments as $asg)
                                        <span class="d-block ml-4">- {{ $asg->widyaiswara->name ?? 'N/A' }} ({{ $asg->material }})</span>
                                    @empty
                                        <span class="d-block ml-4 text-muted font-italic">Belum ada pengajar ditugaskan.</span>
                                    @endforelse
                                </p>
                                
                                 {{-- Detail Disposisi Pimpinan --}}
                                <p class="mb-3">
                                    <i class="fas fa-user-tie fa-fw text-muted"></i> <strong>Disposisi Pimpinan:</strong><br>
                                    @forelse($detail->dispositions as $dispo)
                                        <span class="d-block ml-4">- {{ $dispo->struktural->name ?? 'N/A' }} ({{ $dispo->purpose }})</span>
                                    @empty
                                        <span class="d-block ml-4 text-muted font-italic">Belum ada disposisi untuk jadwal ini.</span>
                                    @endforelse
                                </p>

                                {{-- Info Penyelenggara --}}
                                <div class="border-top pt-2 text-muted small">
                                    Penyelenggara: <strong>{{ $detail->agenda->user->name ?? 'N/A' }}</strong>
                                </div>
                            </div>
                        </div>
                    @empty
                        <div class="text-center text-muted p-4">
                            <i class="fas fa-calendar-times fa-3x mb-3"></i>
                            <p>Tidak ada kegiatan yang dijadwalkan pada tanggal ini.</p>
                        </div>
                    @endforelse
                @endif
                </div>
            </div>
        </div>
    </div>
    
    @push('scripts')
    <script>
        document.addEventListener('livewire:initialized', function () {
            var calendarEl = document.getElementById('calendar');
            var calendar = new FullCalendar.Calendar(calendarEl, {
                initialView: 'dayGridMonth',
                headerToolbar: {
                    left: 'prev,next today',
                    center: 'title',
                    right: 'dayGridMonth,timeGridWeek,listWeek'
                },
                events: @json($events),
                
                // Event saat event/bubble di-klik (SUDAH ADA)
                eventClick: function(info) {
                    info.jsEvent.preventDefault();
                    @this.call('showAgendaDetails', info.event.id);
                },

                // Event BARU saat tanggal di-klik
                dateClick: function(info) {
                    // Panggil method di backend Livewire dan kirim tanggalnya
                    @this.call('showActivitiesForDate', info.dateStr);
                }
            });
            calendar.render();

            @this.on('events-updated', (newEvents) => {
                calendar.removeAllEvents();
                calendar.addEventSource(newEvents[0]); // Ambil array events dari data yang dikirim
            });
            
            // Listener untuk modal detail agenda (SUDAH ADA)
            @this.on('open-agenda-modal', () => {
                $('#agendaDetailModal').modal('show');
            });
            
            // Listener BARU untuk modal daftar kegiatan per hari
            @this.on('open-day-activities-modal', () => {
                $('#dayActivitiesModal').modal('show');
            });
        });
    </script>
    @endpush
</div>
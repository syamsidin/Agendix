<li class="nav-item dropdown" wire:poll.30s="loadNotifications">
    <a class="nav-link" data-toggle="dropdown" href="#">
        <i class="far fa-bell"></i>
        @if($unreadCount > 0)
            <span class="badge badge-warning navbar-badge">{{ $unreadCount }}</span>
        @endif
    </a>
    <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
        <span class="dropdown-item dropdown-header">{{ $unreadCount }} Notifikasi Belum Dibaca</span>
        <div class="dropdown-divider"></div>

        @forelse($unreadNotifications as $notification)
            <a href="{{ $notification->data['url'] ?? '#' }}" wire:click.prevent="markAsRead('{{ $notification->id }}')" class="dropdown-item">
                <i class="fas fa-file mr-2"></i> 
                <span class="text-wrap">{{ $notification->data['message'] }}</span>
                <span class="float-right text-muted text-sm">{{ $notification->created_at->diffForHumans(null, true) }}</span>
            </a>
            <div class="dropdown-divider"></div>
        @empty
            <a href="#" class="dropdown-item text-center text-muted">Tidak ada notifikasi baru</a>
        @endforelse

        @if($unreadCount > 0)
            <a href="#" wire:click.prevent="markAllAsRead" class="dropdown-item dropdown-footer">Tandai semua sudah dibaca</a>
        @endif
    </div>
</li>
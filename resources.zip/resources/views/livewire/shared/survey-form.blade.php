<div>
    @if($isModalOpen)
        <div class="modal fade show" style="display: block;" tabindex="-1">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Survey Kepuasan Pengguna</h5>
                        <button type="button" wire:click="closeModal" class="close"><span>×</span></button>
                    </div>
                    <div class="modal-body">
                        <p>Kami sangat menghargai masukan Anda untuk pengembangan aplikasi ini.</p>
                        <div class="form-group">
                            <label>1. Apa yang membuat anda tidak nyaman saat menggunakan aplikasi ini?</label>
                            <textarea wire:model.defer="answer1" class="form-control @error('answer1') is-invalid @enderror" rows="3"></textarea>
                            @error('answer1') <span class="invalid-feedback">{{ $message }}</span> @enderror
                        </div>
                         <div class="form-group">
                            <label>2. Berikan masukan untuk kami terkait aplikasi ini.</label>
                            <textarea wire:model.defer="answer2" class="form-control @error('answer2') is-invalid @enderror" rows="3"></textarea>
                            @error('answer2') <span class="invalid-feedback">{{ $message }}</span> @enderror
                        </div>
                    </div>
                    <div class="modal-footer justify-content-between">
                        <button type="button" wire:click="closeModal" class="btn btn-secondary">Isi Nanti</button>
                        <button type="button" wire:click="submitSurvey" class="btn btn-primary">Kirim Survey</button>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal-backdrop fade show"></div>
    @endif
</div>
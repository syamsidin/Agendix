<div>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header"><h3 class="card-title">Kalender Agenda</h3></div>
                <div class="card-body">
                    @livewire('shared.calendar')
                </div>
            </div>
        </div>
<!--         <div class="col-md-4">
             <div class="card">
                <div class="card-header"><h3 class="card-title">Status Widyaiswara</h3></div>
                <div class="card-body">
                    {{-- Canvas untuk chart. Tambahkan style cursor pointer agar terlihat bisa diklik --}}
                    <canvas id="wiChart" style="cursor: pointer;"></canvas>
                </div>
            </div>
        </div>
    </div> -->
    

    {{-- MODAL UNTUK MENAMPILKAN DAFTAR NAMA --}}
    @if($isModalOpen)
        <div class="modal fade show" style="display: block;" tabindex="-1">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">{{ $modalTitle }}</h5>
                        <button type="button" wire:click="closeModal" class="close"><span>×</span></button>
                    </div>
                    <div class="modal-body">
                        @if(count($widyaiswaraList) > 0)
                            <ol>
                                @foreach($widyaiswaraList as $wi)
                                    <li>{{ $wi->name }} (NIP: {{ $wi->nip }})</li>
                                @endforeach
                            </ol>
                        @else
                            <p class="text-muted">Tidak ada data untuk ditampilkan.</p>
                        @endif
                    </div>
                    <div class="modal-footer">
                        <button type="button" wire:click="closeModal" class="btn btn-secondary">Tutup</button>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal-backdrop fade show"></div>
    @endif


    @push('scripts')
    <script>
        document.addEventListener('livewire:initialized', function () {
            const ctx = document.getElementById('wiChart');
            const chartData = @json($chartData);
            
            const wiChart = new Chart(ctx, {
                type: 'pie',
                data: {
                    labels: ['Aktif', 'Tidak Aktif'],
                    datasets: [{
                        label: 'Status WI',
                        data: [chartData.active, chartData.inactive],
                        backgroundColor: [
                            'rgb(54, 162, 235)', // Biru untuk Aktif
                            'rgb(255, 99, 132)'  // Merah untuk Tidak Aktif
                        ],
                        hoverOffset: 4
                    }]
                },
                // Tambahkan options untuk event onClick
                options: {
                    onClick: (event, elements) => {
                        if (elements.length > 0) {
                            const chartElement = elements[0];
                            const index = chartElement.index;
                            const label = wiChart.data.labels[index];

                            if (label === 'Aktif') {
                                // Panggil method di komponen Livewire
                                @this.call('showWidyaiswaraList', 'active');
                            } else if (label === 'Tidak Aktif') {
                                // Panggil method di komponen Livewire
                                @this.call('showWidyaiswaraList', 'inactive');
                            }
                        }
                    }
                }
            });

            // Listener untuk merefresh chart jika data berubah (opsional)
            Livewire.on('chartDataUpdated', (newData) => {
                wiChart.data.datasets[0].data = [newData.active, newData.inactive];
                wiChart.update();
            });
        });
    </script>
    @endpush
</div>
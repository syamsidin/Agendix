<div>
	<div class="card mt-4">
        <div class="card-body">
            <h5 class="card-title"><i class="fas fa-info-circle text-primary"></i> Selamat Datang, PIC Widyaiswara</h5>
            <p class="card-text mt-2">
                Gunakan kalender di bawah untuk melihat semua jadwal kegiatan yang telah disetujui. Tugas utama Anda adalah menugaskan widyaiswara pada kegiatan yang telah diminta oleh penyelenggara. Silakan akses menu <strong>"Penugasan WI"</strong> di sidebar untuk mulai menugaskan Widyaiswara.
            </p>
            <a href="{{ route('pic.assignment') }}" class="btn btn-primary">Buka Halaman Penugasan</a>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header"><h3 class="card-title">Kalender Agenda</h3></div>
                <div class="card-body">
                    @livewire('shared.calendar')
                </div>
            </div>
        </div>

    {{-- Tambahan: Kartu Informasi untuk PIC --}}
    
</div>
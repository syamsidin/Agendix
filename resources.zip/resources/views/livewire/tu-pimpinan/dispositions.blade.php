<div>
    @if(session()->has('message'))<div class="alert alert-success">{{session('message')}}</div>@endif

    {{-- Daftar Agenda Utama --}}
    @forelse($agendas as $agenda)
        <div class="card mb-3" wire:key="agenda-{{ $agenda->id }}">
            <div class="card-header d-flex justify-content-between align-items-center">
                <div>
                    <h5 class="mb-0">{{ $agenda->title }}</h5>
                    <small class="text-muted">Penyelenggara: {{ $agenda->user->name ?? 'N/A' }}</small>
                </div>
            </div>
            <div class="card-body">
                @forelse($agenda->details as $detail)
                    <div class="d-flex justify-content-between align-items-center mb-2 {{ !$loop->last ? 'pb-2 border-bottom' : '' }}" wire:key="detail-{{ $detail->id }}">
                        <div>
                            <i class="fas fa-calendar-alt fa-fw"></i> {{ \Carbon\Carbon::parse($detail->start_date)->isoFormat('D MMM Y') }}
                            <span class="mx-2">|</span>
                            <i class="fas fa-map-marker-alt fa-fw"></i> {{ $detail->room->name ?? 'Lokasi Eksternal' }}
                        </div>
                        <div class="text-right">
                            @foreach($detail->dispositions as $dispo)
                                <span class="badge badge-success mr-1" wire:key="dispo-{{ $dispo->id }}">
                                    {{ $dispo->struktural->name }}
                                </span>
                            @endforeach
                            <button wire:click="openDispoForm({{ $detail->id }})" class="btn btn-sm btn-outline-primary">
                                <i class="fas fa-edit"></i> Kelola Disposisi
                            </button>
                        </div>
                    </div>
                @empty
                    <p class="text-muted">Agenda ini tidak memiliki detail jadwal.</p>
                @endforelse
            </div>
        </div>
    @empty
        <p class="text-muted">Belum ada data agenda untuk didisposisikan.</p>
    @endforelse

    {{-- MODAL FORM DISPOSISI --}}
    @if($isModalOpen)
    {{-- PERUBAHAN DI SINI: tambahkan style="z-index: 1060;" pada div utama modal --}}
    <div class="modal fade show" style="display: block; z-index: 1060;" tabindex="-1">
        <div class="modal-dialog modal-lg modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">{{ $dispositionId ? 'Edit Disposisi' : 'Tambah Disposisi Baru' }}</h5>
                    <button type="button" wire:click="closeModal" class="close" aria-label="Close"><span>×</span></button>
                </div>
                <div class="modal-body">
                    {{-- Form Input --}}
                    <div class="form-group">
                        <label>Jam Mulai</label>
                        <input type="time" wire:model="start_time" class="form-control @error('start_time') is-invalid @enderror">
                        @error('start_time') <span class="invalid-feedback">{{ $message }}</span> @enderror
                    </div>
                    <div class="form-group">
                        <label>Disposisi Kepada</label>
                        <select wire:model="struktural_id" class="form-control @error('struktural_id') is-invalid @enderror">
                            <option value="">-- Pilih Pejabat --</option>
                            @foreach($strukturals as $pejabat)
                                <option value="{{ $pejabat->id }}">{{ $pejabat->name }} ({{ $pejabat->position }})</option>
                            @endforeach
                        </select>
                        @error('struktural_id') <span class="invalid-feedback">{{ $message }}</span> @enderror
                    </div>
                    <div class="form-group">
                        <label>Tujuan</label>
                        <select wire:model="purpose" class="form-control @error('purpose') is-invalid @enderror">
                            <option value="">-- Pilih Tujuan --</option>
                            <option value="Membuka Acara">Membuka Acara</option>
                            <option value="Menutup Acara">Menutup Acara</option>
                            <option value="Mewakili Membuka Acara">Mewakili Membuka Acara</option>
                            <option value="Mewakili Menutup Acara">Mewakili Menutup Acara</option>
                            <option value="Menjadi Pemateri">Menjadi Pemateri</option>
                        </select>
                        @error('purpose') <span class="invalid-feedback">{{ $message }}</span> @enderror
                    </div>
                    <div class="text-right">
                        <button wire:click="saveDisposition" class="btn btn-primary">Simpan</button>
                        @if($dispositionId)
                            <button type="button" wire:click="resetForm" class="btn btn-secondary">Batal Edit</button>
                        @endif
                    </div>

                    <hr class="my-4">

                    {{-- Riwayat Disposisi --}}
                    <h6>Riwayat Disposisi untuk Jadwal Ini</h6>
                    <div class="table-responsive">
                        <table class="table table-sm table-bordered">
                            <thead class="thead-light">
                                <tr>
                                    <th>Jam</th>
                                    <th>Kepada</th>
                                    <th>Tujuan</th>
                                    <th style="width: 80px;">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($dispositionsForDetail as $dispo)
                                    <tr class="{{ $dispositionId == $dispo->id ? 'table-info' : '' }}">
                                        <td>{{ \Carbon\Carbon::parse($dispo->start_time)->format('H:i') }}</td>
                                        <td>{{ $dispo->struktural->name ?? 'N/A' }}</td>
                                        <td>{{ $dispo->purpose }}</td>
                                        <td>
                                            <button wire:click="editDisposition({{ $dispo->id }})" class="btn btn-xs btn-info" title="Edit"><i class="fas fa-edit"></i></button>
                                            <button wire:click="deleteDisposition({{ $dispo->id }})" onclick="return confirm('Hapus disposisi ini?')" class="btn btn-xs btn-danger" title="Hapus"><i class="fas fa-trash"></i></button>
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="4" class="text-center text-muted">Belum ada disposisi untuk jadwal ini.</td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" wire:click="closeModal" class="btn btn-secondary">Tutup</button>
                </div>
            </div>
        </div>
    </div>
    {{-- Backdrop memiliki z-index lebih rendah, jadi biarkan saja --}}
    <div class="modal-backdrop fade show"></div>
@endif
</div>
<div class="card card-primary">
    <div class="card-header">
        <h3 class="card-title">Formulir Pengajuan Agenda - Langkah {{ $step }}</h3>
    </div>
    <form wire:submit.prevent="submit">
        {{-- =================================== --}}
        {{--          STEP 1: PILIH TIPE         --}}
        {{-- =================================== --}}
        @if($step == 1)
            <div class="card-body text-center p-5">
                <h2>Pilih Jenis Agenda</h2>
                <p class="lead text-muted">Pilih jenis kegiatan yang akan Anda ajukan.</p>
                <button type="button" wire:click="setType('internal')" class="btn btn-primary btn-lg mx-2">
                    <i class="fas fa-building mr-2"></i> Internal BPSDM
                </button>
                <button type="button" wire:click="setType('external')" class="btn btn-success btn-lg mx-2">
                    <i class="fas fa-globe-asia mr-2"></i> Eksternal
                </button>
            </div>
        @endif

        {{-- =================================== --}}
        {{--          STEP 2: ISI FORM           --}}
        {{-- =================================== --}}
        @if($step == 2)
            <div class="card-body">
                <button type="button" wire:click="back" class="btn btn-secondary mb-4"><i class="fas fa-arrow-left"></i> Kembali ke Pilihan Jenis</button>
                
                {{-- Informasi Agenda Induk (Sama untuk keduanya) --}}
                <div class="row">
                    <div class="col-12">
                         <div class="form-group">
                            <label>Nama Kegiatan Utama</label>
                            <input type="text" wire:model.lazy="title" class="form-control @error('title') is-invalid @enderror" placeholder="cth: Pelatihan Dasar Kepemimpinan Angkatan V">
                            @error('title') <span class="error invalid-feedback">{{ $message }}</span> @enderror
                        </div>
                        <div class="form-group">
                            <label>Deskripsi Umum Kegiatan</label>
                            <textarea wire:model.lazy="description" class="form-control @error('description') is-invalid @enderror" rows="3" placeholder="Berikan keterangan disposis dan detail acara"></textarea>
                            @error('description') <span class="error invalid-feedback">{{ $message }}</span> @enderror
                        </div>
                        <div class="form-group">
                        <label>Nama Konseptor</label>
                        <input type="text" wire:model.lazy="konseptor_name" class="form-control @error('konseptor_name') is-invalid @enderror" placeholder="cth: Iman Noermana">
                        @error('konseptor_name') <span class="error invalid-feedback">{{ $message }}</span> @enderror
                    </div>
                    </div>
                </div>
                <hr>

                {{-- =============================================== --}}
                {{--        FORM KHUSUS UNTUK AGENDA INTERNAL        --}}
                {{-- =============================================== --}}
                @if ($type == 'internal')
                    <h5 class="mb-3">Detail Jadwal dan Ruangan (Bisa lebih dari satu)</h5>
                    @foreach($agendaDetails as $index => $detail)
                        <div class="card card-outline card-secondary mb-3" wire:key="detail-{{ $index }}">
                            <div class="card-header">
                                <h3 class="card-title">Jadwal #{{ $index + 1 }}</h3>
                                @if($index > 0)
                                    <div class="card-tools">
                                        <button type="button" wire:click="removeSchedule({{ $index }})" class="btn btn-tool text-danger"><i class="fas fa-trash"></i> Hapus Jadwal Ini</button>
                                    </div>
                                @endif
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-7">
                                        <div class="row">
                                            <div class="col-6 form-group">
                                                <label>Tgl Mulai</label>
                                                <input type="date" wire:model.live="agendaDetails.{{$index}}.start_date" class="form-control @error('agendaDetails.'.$index.'.start_date') is-invalid @enderror">
                                            </div>
                                            <div class="col-6 form-group">
                                                <label>Tgl Selesai</label>
                                                <input type="date" wire:model.live="agendaDetails.{{$index}}.end_date" class="form-control @error('agendaDetails.'.$index.'.end_date') is-invalid @enderror">
                                            </div>
                                            <div class="col-6 form-group">
                                                <label>Waktu Mulai</label>
                                                <input type="time" wire:model.live="agendaDetails.{{$index}}.start_time" class="form-control @error('agendaDetails.'.$index.'.start_time') is-invalid @enderror">
                                            </div>
                                            <div class="col-6 form-group">
                                                <label>Waktu Selesai</label>
                                                <input type="time" wire:model.live="agendaDetails.{{$index}}.end_time" class="form-control @error('agendaDetails.'.$index.'.end_time') is-invalid @enderror">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-5">
                                        <div class="form-group">
                                            <label>Ruangan</label>
                                            <select wire:model="agendaDetails.{{$index}}.room_id" class="form-control @error('agendaDetails.'.$index.'.room_id') is-invalid @enderror">
                                                <option value="">-- Pilih Ruangan --</option>
                                                @if(isset($detail['availableRooms']))
                                                    @foreach($detail['availableRooms'] as $room)
                                                        <option value="{{ $room->id }}">{{ $room->name }} (Kapasitas: {{ $room->capacity }})</option>
                                                    @endforeach
                                                @endif
                                            </select>
                                            @error('agendaDetails.'.$index.'.room_id') <span class="error invalid-feedback d-block">{{ $message }}</span> @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    @endforeach
                    <button type="button" wire:click="addSchedule" class="btn btn-success"><i class="fas fa-plus"></i> Tambah Jadwal Lain</button>
                @endif

                {{-- =============================================== --}}
                {{--        FORM KHUSUS UNTUK AGENDA EKSTERNAL       --}}
                {{-- =============================================== --}}
                @if ($type == 'external')
                    <h5 class="mb-3">Detail Jadwal dan Lokasi (Hanya Satu)</h5>
                    <div class="card card-outline card-secondary mb-3">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="row">
                                        <div class="col-6 form-group">
                                            <label>Tgl Mulai</label>
                                            <input type="date" wire:model.live="agendaDetails.0.start_date" class="form-control @error('agendaDetails.0.start_date') is-invalid @enderror">
                                        </div>
                                        <div class="col-6 form-group">
                                            <label>Tgl Selesai</label>
                                            <input type="date" wire:model.live="agendaDetails.0.end_date" class="form-control @error('agendaDetails.0.end_date') is-invalid @enderror">
                                        </div>
                                        <div class="col-6 form-group">
                                            <label>Waktu Mulai</label>
                                            <input type="time" wire:model.live="agendaDetails.0.start_time" class="form-control @error('agendaDetails.0.start_time') is-invalid @enderror">
                                        </div>
                                        <div class="col-6 form-group">
                                            <label>Waktu Selesai</label>
                                            <input type="time" wire:model.live="agendaDetails.0.end_time" class="form-control @error('agendaDetails.0.end_time') is-invalid @enderror">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                     <div class="form-group">
                                        <label>Lokasi Manual</label>
                                        <input type="text" wire:model.lazy="agendaDetails.0.manual_location" class="form-control @error('agendaDetails.0.manual_location') is-invalid @enderror" placeholder="cth: Hotel Bidakara, Jakarta">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                @endif

            </div>
            <div class="card-footer text-right">
                <button type="button" wire:click="submit" class="btn btn-primary">
                    <span wire:loading.remove wire:target="submit">Ajukan Agenda</span>
                    <span wire:loading wire:target="submit"><i class="fas fa-spinner fa-spin"></i> Mengajukan...</span>
                </button>
            </div>
        @endif
    </form>
</div>
<div>
    {{-- Notifikasi --}}
    @if (session()->has('message'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            {{ session('message') }}
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">×</span>
            </button>
        </div>
    @endif
    @if (session()->has('error'))
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            {{ session('error') }}
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">×</span>
            </button>
        </div>
    @endif

    <div class="table-responsive">
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>No.</th>
                    <th>Nama Kegiatan</th>
                    <th>Detail Jadwal & Lokasi</th>
                    <th>Status</th>
                    <th style="width: 120px;">Aksi</th>
                </tr>
            </thead>
            <tbody>
                @forelse($agendas as $index => $agenda)
                    <tr>
                        <td>{{ $agendas->firstItem() + $index }}</td>
                        <td>
                            <strong>{{ $agenda->title }}</strong>
                            <p class="text-muted mb-0">{{ Str::limit($agenda->description, 50) }}</p>
                            @if($agenda->type == 'internal')
                                <span class="badge badge-info">Internal</span>
                            @else
                                <span class="badge badge-success">Eksternal</span>
                            @endif
                        </td>
                        <td>
                            {{-- LAKUKAN PERULANGAN UNTUK SETIAP DETAIL JADWAL --}}
                            @if($agenda->details->isNotEmpty())
                                @foreach($agenda->details as $detail)
                                    <div class="mb-2 {{ !$loop->last ? 'pb-2 border-bottom' : '' }}">
                                        <div><i class="fas fa-calendar-alt fa-fw text-primary"></i> {{ \Carbon\Carbon::parse($detail->start_date)->isoFormat('D MMM Y') }} s/d {{ \Carbon\Carbon::parse($detail->end_date)->isoFormat('D MMM Y') }}</div>
                                        <div><i class="fas fa-clock fa-fw text-primary"></i> {{ \Carbon\Carbon::parse($detail->start_time)->format('H:i') }} - {{ \Carbon\Carbon::parse($detail->end_time)->format('H:i') }}</div>
                                        <div><i class="fas fa-map-marker-alt fa-fw text-primary"></i> 
                                            @if($agenda->type == 'internal')
                                                {{ $detail->room->name ?? 'N/A' }}
                                            @else
                                                {{ $detail->manual_location }}
                                            @endif
                                        </div>
                                    </div>
                                @endforeach
                            @else
                                <span class="text-muted">Tidak ada detail jadwal.</span>
                            @endif
                        </td>
                        <td>
                            @if($agenda->status == 'pending')
                                <span class="badge badge-warning">Menunggu Persetujuan</span>
                            @elseif($agenda->status == 'approved')
                                <span class="badge badge-success">Disetujui</span>
                            @elseif($agenda->status == 'rejected')
                            <span class="badge badge-danger" 
                                  data-toggle="tooltip" 
                                  data-placement="top" 
                                  title="Alasan: {{ $agenda->rejection_reason ?? 'Tidak ada alasan diberikan.' }}">
                                Ditolak
                            </span>
                            @else
                                <span class="badge badge-secondary">{{ ucfirst($agenda->status) }}</span>
                            @endif
                        </td>
                        <td class="text-center">
                            {{-- Tombol Edit dan Hapus akan selalu muncul --}}
                            <button wire:click="edit({{ $agenda->id }})" class="btn btn-sm btn-info" title="Edit Agenda">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button wire:click="delete({{ $agenda->id }})" 
                                    onclick="return confirm('PERINGATAN: Menghapus agenda ini akan menghapus SEMUA jadwal terkait. Anda yakin?')" 
                                    class="btn btn-sm btn-danger" 
                                    title="Hapus Agenda">
                                <i class="fas fa-trash"></i>
                            </button>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="5" class="text-center">Anda belum pernah mengajukan agenda.</td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>

    <div class="mt-3">
        {{ $agendas->links() }}
    </div>

    {{-- ============================================== --}}
    {{--          MODAL EDIT (STRUKTUR BARU)          --}}
    {{-- ============================================== --}}
    @if($isModalOpen)
    <div class="modal fade show" style="display: block;" tabindex="-1">
        <div class="modal-dialog modal-xl modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Edit Agenda</h5>
                    <button type="button" wire:click="closeModal" class="close"><span>×</span></button>
                </div>
                <div class="modal-body">
                    {{-- Informasi Agenda Induk --}}
                    <div class="row">
                        <div class="col-12">
                             <div class="form-group">
                                <label>Nama Kegiatan Utama</label>
                                <input type="text" wire:model.lazy="title" class="form-control @error('title') is-invalid @enderror">
                                @error('title') <span class="error invalid-feedback">{{ $message }}</span> @enderror
                            </div>
                            <div class="form-group">
                                <label>Deskripsi Umum Kegiatan</label>
                                <textarea wire:model.lazy="description" class="form-control @error('description') is-invalid @enderror" rows="3"></textarea>
                                @error('description') <span class="error invalid-feedback">{{ $message }}</span> @enderror
                            </div>
                        </div>
                    </div>
                    <hr>
                    <h5 class="mb-3">Edit Detail Jadwal</h5>
                    {{-- Perulangan untuk mengedit setiap detail jadwal --}}
                    @foreach($agendaDetails as $index => $detail)
                        <div class="card card-outline card-secondary mb-3" wire:key="detail-edit-{{ $index }}">
                            <div class="card-header">
                                <h3 class="card-title">Jadwal #{{ $index + 1 }}</h3>
                                @if($index > 0)
                                    <div class="card-tools"><button type="button" wire:click="removeSchedule({{ $index }})" class="btn btn-tool text-danger"><i class="fas fa-trash"></i></button></div>
                                @endif
                            </div>
                            <div class="card-body">
                                <div class="row">
                                <div class="col-md-6">
                                    <div class="row">
                                        <div class="col-6 form-group"><label>Tgl Mulai</label><input type="date" wire:model.live="agendaDetails.{{$index}}.start_date" class="form-control @error('agendaDetails.'.$index.'.start_date') is-invalid @enderror"></div>
                                        <div class="col-6 form-group"><label>Tgl Selesai</label><input type="date" wire:model.live="agendaDetails.{{$index}}.end_date" class="form-control @error('agendaDetails.'.$index.'.end_date') is-invalid @enderror"></div>
                                        <div class="col-6 form-group"><label>Waktu Mulai</label><input type="time" wire:model.live="agendaDetails.{{$index}}.start_time" class="form-control @error('agendaDetails.'.$index.'.start_time') is-invalid @enderror"></div>
                                        <div class="col-6 form-group"><label>Waktu Selesai</label><input type="time" wire:model.live="agendaDetails.{{$index}}.end_time" class="form-control @error('agendaDetails.'.$index.'.end_time') is-invalid @enderror"></div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    @if($type == 'internal')
                                        <div class="form-group">
                                            <label>Ruangan</label>
                                            <select wire:model="agendaDetails.{{$index}}.room_id" class="form-control @error('agendaDetails.'.$index.'.room_id') is-invalid @enderror">
                                                <option value="">-- Pilih Ruangan --</option>
                                                @if(isset($detail['availableRooms']))
                                                    @foreach($detail['availableRooms'] as $room)
                                                        <option value="{{ $room->id }}">{{ $room->name }}</option>
                                                    @endforeach
                                                @endif
                                            </select>
                                            @error('agendaDetails.'.$index.'.room_id')<span class="error invalid-feedback d-block">{{ $message }}</span>@enderror
                                        </div>
                                    @else
                                        <div class="form-group">
                                            <label>Lokasi Manual</label>
                                            <input type="text" wire:model.lazy="agendaDetails.{{$index}}.manual_location" class="form-control @error('agendaDetails.'.$index.'.manual_location') is-invalid @enderror">
                                        </div>
                                    @endif
                                </div>
                            </div>
                        </div>
                        </div>
                    @endforeach
                    <button type="button" wire:click="addSchedule" class="btn btn-success btn-sm"><i class="fas fa-plus"></i> Tambah Jadwal</button>
                </div>
                <div class="modal-footer">
                    <button type="button" wire:click="closeModal" class="btn btn-secondary">Batal</button>
                    <button type="button" wire:click="update" class="btn btn-primary">Update Agenda</button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal-backdrop fade show"></div>
    @endif
</div>
@push('scripts')
<script>
    // Fungsi untuk menginisialisasi semua tooltip
    function initTooltips() {
        // Cari semua elemen yang punya atribut data-toggle="tooltip"
        $('[data-toggle="tooltip"]').tooltip({
            // Opsi untuk membuat tooltip tetap ada bahkan saat DOM berubah
            trigger: 'hover'
        });
    }

    // Panggil saat komponen pertama kali dimuat
    document.addEventListener('livewire:initialized', () => {
        initTooltips();
    });

    // Panggil kembali setiap kali Livewire melakukan update
    Livewire.on('render', () => {
        initTooltips();
    });
</script>
@endpush
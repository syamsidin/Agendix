<div class="row">
    @forelse($rooms as $room)
        <div class="col-lg-4 col-md-6 mb-4">
            {{-- SEKARANG wire:click BERADA DI DALAM KOMPONEN LIVEWIRE --}}
           <div class="card h-100 room-card" wire:click="$dispatch('showRoomDetail', { roomId: {{ $room->id }} })">
                <img src="{{ $room->images->first() ? asset('storage/' . $room->images->first()->path) : 'https://via.placeholder.com/400x250.png/E9ECEF/6C757D?text=Image+Not+Available' }}" class="card-img-top" alt="{{ $room->name }}" style="height: 220px; object-fit: cover;">
                <div class="card-body">
                    <h5 class="card-title fw-bold">{{ $room->name }}</h5>
                    <p class="card-text text-muted"><i class="fas fa-map-marker-alt fa-sm me-2"></i>{{ $room->location }}</p>
                    <p class="card-text text-muted mt-2">
                                    <i class="fas fa-users fa-sm me-2"></i>Kapasitas: <strong>{{ $room->capacity }} orang</strong>
                    </p>
                </div>
            </div>
        </div>
    @empty
        <div class="col-12 text-center">
            <p class="text-muted">Informasi ruangan akan segera tersedia.</p>
        </div>
    @endforelse
</div>
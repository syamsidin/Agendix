<x-public-layout>
    <x-slot name="title">
        Detail Ruangan: {{ $room->name }}
    </x-slot>

    <div class="container py-5">
        {{-- Judul dan tombol kembali --}}
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1 class="fw-bold">{{ $room->name }}</h1>
            <a href="{{ route('public.rooms.gallery') }}" class="btn btn-outline-primary"><i class="fas fa-arrow-left me-2"></i>Kembali ke Galeri</a>
        </div>

        {{-- Carousel Galeri Foto --}}
        @if($room->images->isNotEmpty())
            <div id="roomCarousel" class="carousel slide mb-4 shadow-lg" data-bs-ride="carousel" style="border-radius: 1rem; overflow: hidden;">
                <div class="carousel-inner">
                    @foreach($room->images as $image)
                        <div class="carousel-item {{ $loop->first ? 'active' : '' }}">
                            <img src="{{ asset('storage/' . $image->path) }}" class="d-block w-100" alt="Foto {{ $room->name }}" style="max-height: 60vh; object-fit: cover;">
                        </div>
                    @endforeach
                </div>
                @if($room->images->count() > 1)
                    <button class="carousel-control-prev" type="button" data-bs-target="#roomCarousel" data-bs-slide="prev"><span class="carousel-control-prev-icon"></span></button>
                    <button class="carousel-control-next" type="button" data-bs-target="#roomCarousel" data-bs-slide="next"><span class="carousel-control-next-icon"></span></button>
                @endif
            </div>
        @endif

        {{-- Detail Teks --}}
        <div class="card">
            <div class="card-body">
                <h3>Detail Informasi</h3>
                <hr>
                <div class="row">
                    <div class="col-md-6">
                        <p><strong><i class="fas fa-map-marker-alt fa-fw me-2"></i>Lokasi:</strong> {{ $room->location }}</p>
                    </div>
                    <div class="col-md-6">
                        <p><strong><i class="fas fa-users fa-fw me-2"></i>Kapasitas:</strong> {{ $room->capacity }} orang</p>
                    </div>
                </div>
                <p><strong><i class="fas fa-couch fa-fw me-2"></i>Fasilitas:</strong></p>
                <p style="white-space: pre-wrap;">{{ $room->facilities }}</p>
            </div>
        </div>
    </div>
</x-public-layout>
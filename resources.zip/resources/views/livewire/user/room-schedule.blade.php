<div>
    <div class="card">
        <div class="card-header">
            <div class="d-flex justify-content-between align-items-center">
                <h3 class="card-title mb-0">
                    Jadwal untuk: <strong>{{ $date_for_view->isoFormat('dddd, D MMMM YYYY') }}</strong>
                </h3>
                <div class="card-tools">
                    <div class="btn-group">
                        <button wire:click="previousDay" class="btn btn-default btn-sm" title="Hari Sebelumnya"><i class="fas fa-chevron-left"></i></button>
                        <button wire:click="goToToday" class="btn btn-default btn-sm" title="Hari Ini">Hari Ini</button>
                        <button wire:click="nextDay" class="btn btn-default btn-sm" title="Hari Berikutnya"><i class="fas fa-chevron-right"></i></button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    @if($schedulesByRoom->isNotEmpty())
        @foreach($schedulesByRoom as $roomName => $schedules)
            <div class="card mt-3">
                <div class="card-header bg-lightblue">
                    <h3 class="card-title font-weight-bold"><i class="fas fa-door-open mr-2"></i> {{ $roomName }}</h3>
                </div>
                <div class="card-body p-0">
                    <ul class="list-group list-group-flush">
                        @foreach($schedules as $schedule)
                            <li class="list-group-item">
                                <div class="d-flex w-100 justify-content-between">
                                    <h6 class="mb-1">{{ $schedule->agenda->title }}</h6>
                                    <small class="text-muted">{{ \Carbon\Carbon::parse($schedule->start_time)->format('H:i') }} - {{ \Carbon\Carbon::parse($schedule->end_time)->format('H:i') }}</small>
                                </div>
                                <p class="mb-1 text-muted">
                                    Diajukan oleh: <strong>{{ $schedule->agenda->user->name }}</strong>
                                </p>
                                <small>
                                    <i class="fas fa-calendar-alt"></i> 
                                    Digunakan dari {{ \Carbon\Carbon::parse($schedule->start_date)->isoFormat('D MMM') }} s/d {{ \Carbon\Carbon::parse($schedule->end_date)->isoFormat('D MMM Y') }}
                                </small>
                            </li>
                        @endforeach
                    </ul>
                </div>
            </div>
        @endforeach
    @else
        <div class="alert alert-success text-center mt-3">
            <i class="fas fa-check-circle fa-2x mb-2"></i>
            <h4 class="alert-heading">Semua Ruangan Tersedia!</h4>
            <p>Tidak ada jadwal penggunaan ruangan pada tanggal yang dipilih.</p>
        </div>
    @endif
</div>
<div>
    {{-- Notifikasi Sukses --}}
    @if (session()->has('message'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            {{ session('message') }}
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">×</span>
            </button>
        </div>
    @endif

    <div class="table-responsive">
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>No.</th>
                    <th>Nama Kegiatan & Tipe</th>
                     <th>Pengaju & Konseptor</th>
                    <th>Detail Jadwal & Lokasi</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                @forelse($agendas as $index => $agenda)
                    <tr>
                        <td>{{ $agendas->firstItem() + $index }}</td>
                        <td>
                            <strong>{{ $agenda->title }}</strong>
                            <br>
                            @if($agenda->type == 'internal')
                                <span class="badge badge-info">Internal</span>
                            @else
                                <span class="badge badge-success">Eksternal</span>
                            @endif
                        </td>
                        <td>
                            <strong>{{ $agenda->user->name ?? 'N/A' }}</strong><br>
                            @if($agenda->konseptor_name)
                                <small class="text-muted">Konseptor: {{ $agenda->konseptor_name }}</small>
                            @endif
                        </td>
                        
                        {{-- ======================================================= --}}
                        {{--  BAGIAN YANG DIPERBAIKI UNTUK INTERNAL & EKSTERNAL     --}}
                        {{-- ======================================================= --}}
                        <td>
                            @if($agenda->details->isNotEmpty())
                                @foreach($agenda->details as $detail)
                                    <div class="mb-2 {{ !$loop->last ? 'pb-2 border-bottom' : '' }}">
                                        <div>
                                            <i class="fas fa-calendar-alt fa-fw text-muted"></i> 
                                            {{ \Carbon\Carbon::parse($detail->start_date)->isoFormat('D MMM Y') }}
                                        </div>
                                        <div>
                                            <i class="fas fa-clock fa-fw text-muted"></i> 
                                            {{ \Carbon\Carbon::parse($detail->start_time)->format('H:i') }} - {{ \Carbon\Carbon::parse($detail->end_time)->format('H:i') }}
                                        </div>
                                        <div>
                                            <i class="fas fa-map-marker-alt fa-fw text-muted"></i> 
                                            {{-- Tambahkan kondisi untuk menampilkan lokasi --}}
                                            <strong>
                                                @if($agenda->type == 'internal')
                                                    {{ $detail->room->name ?? 'N/A' }}
                                                @else
                                                    {{ $detail->manual_location ?? 'N/A' }}
                                                @endif
                                            </strong>
                                        </div>
                                    </div>
                                @endforeach
                            @else
                                <span class="text-muted">Belum ada detail jadwal.</span>
                            @endif
                        </td>
                        {{-- ======================================================= --}}

                        <td>
                            @if($agenda->status == 'pending')
                                <span class="badge badge-warning">Pending</span>
                            @elseif($agenda->status == 'approved')
                                <span class="badge badge-success">Approved</span>
                            @elseif($agenda->status == 'rejected')
                                <span class="badge badge-danger">Rejected</span>
                                <small class="d-block text-muted" title="{{ $agenda->rejection_reason }}">Lihat Alasan</small>
                            @else
                                <span class="badge badge-secondary">{{ ucfirst($agenda->status) }}</span>
                            @endif
                        </td>
                        <td>
                            {{-- Hanya tampilkan aksi untuk agenda Internal --}}
                            @if($agenda->type == 'internal' && $agenda->status == 'pending')
                                <button wire:click="approve({{ $agenda->id }})" wire:loading.attr="disabled" class="btn btn-sm btn-success mb-1" title="Setujui">
                                    <i class="fas fa-check"></i>
                                </button>
                                <button wire:click="openRejectModal({{ $agenda->id }})" wire:loading.attr="disabled" class="btn btn-sm btn-danger mb-1" title="Tolak">
                                    <i class="fas fa-times"></i>
                                </button>
                            @else
                                {{-- Agenda Eksternal otomatis disetujui, tidak perlu aksi --}}
                                -
                            @endif
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="6" class="text-center">Tidak ada data pengajuan agenda.</td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>

    <div class="mt-3">
        {{ $agendas->links() }}
    </div>


    {{-- Modal untuk Alasan Penolakan (TIDAK BERUBAH) --}}
    @if($isRejectModalOpen)
        <div class="modal fade show" style="display: block;" tabindex="-1" role="dialog">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Alasan Penolakan Agenda</h5>
                        <button type="button" wire:click="closeRejectModal" class="close" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <p><strong>Kegiatan:</strong> {{ $agendaToReject->title ?? '' }}</p>
                        <div class="form-group">
                            <label for="rejection_reason">Mohon isi alasan penolakan:</label>
                            <textarea wire:model.defer="rejection_reason" id="rejection_reason" class="form-control @error('rejection_reason') is-invalid @enderror" rows="4"></textarea>
                            @error('rejection_reason')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" wire:click="closeRejectModal" class="btn btn-secondary">Batal</button>
                        <button type="button" wire:click="reject" wire:loading.attr="disabled" class="btn btn-danger">
                            <span wire:loading.remove wire:target="reject">Tolak Agenda</span>
                            <span wire:loading wire:target="reject"><i class="fas fa-spinner fa-spin"></i> Menolak...</span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal-backdrop fade show"></div>
    @endif
</div>
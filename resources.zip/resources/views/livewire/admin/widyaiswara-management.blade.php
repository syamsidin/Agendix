<div>
    {{-- Notifikasi --}}
    @if (session()->has('message'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            {{ session('message') }}
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">×</span>
            </button>
        </div>
    @endif
    @if (session()->has('error'))
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            {{ session('error') }}
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">×</span>
            </button>
        </div>
    @endif

    {{-- Header dan Tabel Widyaiswara --}}
    <div class="card">
        <div class="card-header d-flex justify-content-between">
            <h3 class="card-title">Data Widyaiswara</h3>
            <div class="d-flex" style="width: 50%;">
                <input type="text" wire:model.live.debounce.300ms="search" class="form-control mr-2" placeholder="Cari nama atau NIP...">
                <button wire:click="create()" class="btn btn-primary text-nowrap"><i class="fas fa-plus"></i> Tambah Data</button>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>No.</th>
                            <th>Nama</th>
                            <th>NIP</th>
                            <th>Jabatan</th>
                            <th>Pangkat/Gol.</th>
                            <th>WhatsApp</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($widyaiswaras as $index => $widyaiswara)
                        <tr>
                            <td>{{ $widyaiswaras->firstItem() + $index }}</td>
                            <td>{{ $widyaiswara->name }}</td>
                            <td>{{ $widyaiswara->nip }}</td>
                            <td>{{ $widyaiswara->position }}</td>
                            <td>{{ $widyaiswara->rank }}</td>
                            <td>{{ $widyaiswara->whatsapp }}</td>
                            <td>
                                <button wire:click="edit({{ $widyaiswara->id }})" class="btn btn-sm btn-info" title="Edit"><i class="fas fa-edit"></i></button>
                                <button wire:click="delete({{ $widyaiswara->id }})" onclick="return confirm('Anda yakin ingin menghapus data ini?')" class="btn btn-sm btn-danger" title="Hapus"><i class="fas fa-trash"></i></button>
                            </td>
                        </tr>
                        @empty
                        <tr>
                            <td colspan="7" class="text-center">Tidak ada data Widyaiswara.</td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
            <div class="mt-3">
                {{ $widyaiswaras->links() }}
            </div>
        </div>
    </div>

    {{-- Modal Form (Struktur AdminLTE) --}}
    @if($isModalOpen)
        <div class="modal fade show" style="display: block;" tabindex="-1">
            <div class="modal-dialog modal-lg modal-dialog-scrollable">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">{{ $widyaiswaraId ? 'Edit' : 'Tambah' }} Data Widyaiswara</h5>
                        <button type="button" wire:click="closeModal" class="close"><span>×</span></button>
                    </div>
                    <form wire:submit.prevent="store">
                        <div class="modal-body">
                            {{-- ... Isi form untuk Widyaiswara (nama, nip, dll.) ... --}}
                            <div class="form-group">
                                <label>Nama Lengkap</label>
                                <input type="text" class="form-control @error('name') is-invalid @enderror" wire:model="name">
                                @error('name') <span class="invalid-feedback">{{ $message }}</span> @enderror
                            </div>
                            <div class="form-group">
                                <label>NIP</label>
                                <input type="text" class="form-control @error('nip') is-invalid @enderror" wire:model="nip">
                                @error('nip') <span class="invalid-feedback">{{ $message }}</span> @enderror
                            </div>
                            <div class="row">
                                <div class="col-md-6"><div class="form-group"><label>Jabatan</label><input type="text" class="form-control @error('position') is-invalid @enderror" wire:model="position">@error('position')<span class="invalid-feedback">{{ $message }}</span>@enderror</div></div>
                                <div class="col-md-6"><div class="form-group"><label>Pangkat/Golongan</label><input type="text" class="form-control @error('rank') is-invalid @enderror" wire:model="rank">@error('rank')<span class="invalid-feedback">{{ $message }}</span>@enderror</div></div>
                            </div>
                            <div class="form-group"><label>No. WhatsApp</label><input type="text" class="form-control @error('whatsapp') is-invalid @enderror" wire:model="whatsapp">@error('whatsapp')<span class="invalid-feedback">{{ $message }}</span>@enderror</div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" wire:click="closeModal" class="btn btn-secondary">Tutup</button>
                            <button type="submit" class="btn btn-primary">{{ $widyaiswaraId ? 'Update' : 'Simpan' }}</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="modal-backdrop fade show"></div>
    @endif
</div>
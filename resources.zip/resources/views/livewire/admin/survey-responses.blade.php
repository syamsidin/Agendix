<div class="card">
    <div class="card-header">
        <h3 class="card-title">Daftar Masukan dari Pengguna</h3>
    </div>
    <div class="card-body">
        @forelse($surveys as $survey)
            <div class="post">
                <div class="user-block">
                    <span class="username">
                        <a href="#">{{ $survey->user->name ?? 'N/A' }}</a>
                         <small class="text-muted float-right">{{ $survey->created_at->format('d M Y H:i') }}</small>
                    </span>
                    <span class="description">Dari Bidang: {{ $survey->user->department_name ?? 'N/A' }}</span>
                </div>
                <h6>1. Apa yang membuat tidak nyaman?</h6>
                <p>{{ $survey->question_1_answer }}</p>
                <h6>2. Masukan untuk pengembangan?</h6>
                <p>{{ $survey->question_2_answer }}</p>
            </div>
        @empty
             <p class="text-center text-muted">Belum ada respons survey.</p>
        @endforelse
    </div>
    <div class="card-footer">
        {{ $surveys->links() }}
    </div>
</div>
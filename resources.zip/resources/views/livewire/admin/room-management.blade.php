<div>
    @if (session()->has('message'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            {{ session('message') }}
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">×</span>
            </button>
        </div>
    @endif

     <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <button wire:click="create()" class="btn btn-primary"><i class="fas fa-plus mr-1"></i> Tambah Ruangan Baru</button>
        </div>
        <div style="width: 300px;">
            <input type="text" wire:model.live.debounce.300ms="search" class="form-control" placeholder="Cari nama ruangan...">
        </div>
    </div>
 <div class="row">
        @forelse($rooms as $room)
            <div class="col-md-4 col-lg-4 mb-4">
                <div class="card h-100">
                    {{-- Gambar Ruangan --}}
                    <img src="{{ $room->images->first() ? asset('storage/' . $room->images->first()->path) : 'https://via.placeholder.com/400x250.png/...' }}" class="card-img-top" alt="{{ $room->name }}" style="height: 200px; object-fit: cover;">
                    
                    <div class="card-body d-flex flex-column">
                        {{-- Nama dan Lokasi --}}
                        <h5 class="card-title font-weight-bold">{{ $room->name }}</h5>
                        <p class="card-text text-muted"><i class="fas fa-map-marker-alt fa-fw"></i> {{ $room->location }}</p>

                        {{-- Detail Fasilitas dan Kapasitas --}}
                        <ul class="list-unstyled mt-3 mb-4">
                            <li><i class="fas fa-users fa-fw text-info"></i> Kapasitas: <strong>{{ $room->capacity }} orang</strong></li>
                            <li class="mt-2"><i class="fas fa-couch fa-fw text-info"></i> Fasilitas: <small>{{ Str::limit($room->facilities, 50) }}</small></li>
                        </ul>
                        
                        {{-- Tombol Aksi (di bagian bawah card) --}}
                        <div class="mt-auto text-right">
                            <button wire:click="edit({{ $room->id }})" class="btn btn-sm btn-info" title="Edit"><i class="fas fa-edit"></i></button>
                            <button wire:click="delete({{ $room->id }})" onclick="return confirm('Anda yakin ingin menghapus ruangan ini? Ini juga akan menghapus agenda yang terkait dengannya.')" class="btn btn-sm btn-danger" title="Hapus"><i class="fas fa-trash"></i></button>
                        </div>
                    </div>
                </div>
            </div>
        @empty
            <div class="col-12">
                <div class="alert alert-warning text-center">
                    Tidak ada data ruangan yang ditemukan.
                </div>
            </div>
        @endforelse
    </div>
    
    {{ $rooms->links() }}

    {{-- Modal Form --}}
    @if($isModalOpen)
    <div class="modal fade show" style="display: block;" tabindex="-1">
         <div class="modal-dialog modal-dialog-scrollable">
            <form wire:submit.prevent="store">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">{{ $roomId ? 'Edit' : 'Tambah' }} Ruangan</h5>
                        <button type="button" wire:click="closeModal" class="close"><span>×</span></button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label>Nama Ruangan</label>
                            <input type="text" class="form-control" wire:model="name">
                            @error('name') <span class="text-danger">{{ $message }}</span>@enderror
                        </div>
                        <div class="form-group">
                            <label>Fasilitas</label>
                            <textarea class="form-control" wire:model="facilities" rows="3"></textarea>
                            @error('facilities') <span class="text-danger">{{ $message }}</span>@enderror
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Kapasitas (orang)</label>
                                    <input type="number" class="form-control" wire:model="capacity">
                                    @error('capacity') <span class="text-danger">{{ $message }}</span>@enderror
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Lokasi</label>
                                    <input type="text" class="form-control" wire:model="location">
                                    @error('location') <span class="text-danger">{{ $message }}</span>@enderror
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                        <label>Upload Gambar Ruangan (Bisa lebih dari satu)</label>
                        <input type="file" class="form-control-file" wire:model="images" multiple>
                        @error('images.*') <span class="text-danger d-block">{{ $message }}</span> @enderror
                    </div>

                        {{-- GALERI GAMBAR YANG SUDAH ADA (SAAT EDIT) --}}
                        @if($roomId && $existingImages->isNotEmpty())
                        <hr>
                        <h6>Galeri Gambar Saat Ini</h6>
                        @if(session()->has('image_message'))<div class="alert alert-info p-2">{{session('image_message')}}</div>@endif
                        <div class="row">
                            @foreach($existingImages as $img)
                            <div class="col-md-4 mb-2 text-center">
                                <img src="{{ asset('storage/' . $img->path) }}" class="img-thumbnail">
                                <button type="button" wire:click="deleteImage({{ $img->id }})" class="btn btn-danger btn-xs mt-1">Hapus</button>
                            </div>
                            @endforeach
                        </div>
                        @endif
                         <div class="modal-footer">
                        <button type="button" wire:click="closeModal" class="btn btn-secondary">Tutup</button>
                        <button type="submit" class="btn btn-primary">{{ $roomId ? 'Update' : 'Simpan' }}</button>
                    </div>
                    </div>
                    </div>
                   
                </div>
            </form>
        </div>
    </div>
    <div class="modal-backdrop fade show"></div>
    @endif
</div>
<div>
    @if (session()->has('message'))
        <div class="alert alert-success">{{ session('message') }}</div>
    @endif

    <div class="card">
        <div class="card-header d-flex justify-content-between">
            <h3 class="card-title">Daftar Pejabat Struktural</h3>
            <div class="d-flex">
                 <input type="text" wire:model.live.debounce.300ms="search" class="form-control mr-2" placeholder="Cari nama atau NIP...">
                 <button wire:click="create()" class="btn btn-primary text-nowrap"><i class="fas fa-plus"></i> Tambah Data</button>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>No.</th>
                            <th>Nama Lengkap</th>
                            <th>NIP</th>
                            <th>Jabatan</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($strukturals as $index => $pejabat)
                        <tr>
                            <td>{{ $strukturals->firstItem() + $index }}</td>
                            <td>{{ $pejabat->name }}</td>
                            <td>{{ $pejabat->nip ?? '-' }}</td>
                            <td>{{ $pejabat->position }}</td>
                            <td>
                                <button wire:click="edit({{ $pejabat->id }})" class="btn btn-sm btn-info" title="Edit"><i class="fas fa-edit"></i></button>
                                <button wire:click="delete({{ $pejabat->id }})" onclick="return confirm('Anda yakin?')" class="btn btn-sm btn-danger" title="Hapus"><i class="fas fa-trash"></i></button>
                            </td>
                        </tr>
                        @empty
                        <tr>
                            <td colspan="5" class="text-center">Belum ada data pejabat struktural.</td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
             <div class="mt-3">
                {{ $strukturals->links() }}
            </div>
        </div>
    </div>
    
    @if($isModalOpen)
<div class="modal fade show" style="display: block;" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">{{ $strukturalId ? 'Edit' : 'Tambah' }} Data Pejabat</h5>
                <button type="button" wire:click="closeModal" class="close"><span>×</span></button>
            </div>
            {{-- FORM TAG SEKARANG MEMBUNGKUS MODAL BODY & FOOTER --}}
            <form wire:submit.prevent="store">
                <div class="modal-body">
                    <div class="form-group">
                        <label for="name">Nama Lengkap (dengan gelar)</label>
                        <input type="text" id="name" class="form-control @error('name') is-invalid @enderror" wire:model="name" placeholder="cth: Dr. H. Asep Saeful, M.M.">
                        @error('name') <span class="invalid-feedback">{{ $message }}</span>@enderror
                    </div>
                    <div class="form-group">
                        <label for="nip">NIP (Opsional)</label>
                        <input type="text" id="nip" class="form-control @error('nip') is-invalid @enderror" wire:model="nip" placeholder="Isi NIP tanpa spasi jika ada">
                        @error('nip') <span class="invalid-feedback">{{ $message }}</span>@enderror
                    </div>
                    <div class="form-group">
                        <label for="position">Jabatan</label>
                        <input type="text" id="position" class="form-control @error('position') is-invalid @enderror" wire:model="position" placeholder="cth: Kepala Badan Kepegawaian Daerah">
                        @error('position') <span class="invalid-feedback">{{ $message }}</span>@enderror
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" wire:click="closeModal" class="btn btn-secondary">Tutup</button>
                    <button type="submit" class="btn btn-primary">
                        <span wire:loading.remove wire:target="store">{{ $strukturalId ? 'Update' : 'Simpan' }}</span>
                        <span wire:loading wire:target="store"><i class="fas fa-spinner fa-spin"></i></span>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<div class="modal-backdrop fade show"></div>
@endif
</div>
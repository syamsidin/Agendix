<div>
    <div class="card">
        <div class="card-header">
            <button wire:click="create()" class="btn btn-primary">Tambah Pengguna</button>
        </div>
        <div class="card-body">
            @if (session()->has('message'))
                <div class="alert alert-success">{{ session('message') }}</div>
            @endif
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Nama</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Bidang</th>
                        <th>Warna</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($users as $user)
                    <tr>
                        <td>{{ $user->name }}</td>
                        <td>{{ $user->email }}</td>
                        <td>{{ strtoupper($user->role) }}</td>
                        <td>{{ $user->department_name }}</td>
                        <td><span style="display:inline-block; width:20px; height:20px; background-color:{{ $user->color }};"></span></td>
                        <td>
                            <button wire:click="edit({{ $user->id }})" class="btn btn-sm btn-info">Edit</button>
                            <button wire:click="delete({{ $user->id }})" onclick="return confirm('Anda yakin ingin menghapus?')" class="btn btn-sm btn-danger">Hapus</button>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
            {{ $users->links() }}
        </div>
    </div>

    @if($isModalOpen)
    <div class="modal fade show" style="display: block;" tabindex="-1">
        <div class="modal-dialog modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">{{ $userId ? 'Edit' : 'Tambah' }} Pengguna</h5>
                    <button type="button" wire:click="closeModal" class="close"><span>×</span></button>
                </div>
               <form wire:submit.prevent="store">
                    <div class="modal-body">
                        <div class="form-group">
                            <label>Nama Lengkap</label>
                            <input type="text" class="form-control" wire:model="name">
                            @error('name') <span class="text-danger">{{ $message }}</span>@enderror
                        </div>
                        <div class="form-group">
                            <label>Email</label>
                            <input type="email" class="form-control" wire:model="email">
                            @error('email') <span class="text-danger">{{ $message }}</span>@enderror
                        </div>
                         <div class="form-group">
                            <label>Password (kosongkan jika tidak ingin mengubah)</label>
                            <input type="password" class="form-control" wire:model="password">
                            @error('password') <span class="text-danger">{{ $message }}</span>@enderror
                        </div>
                        <div class="form-group">
                            <label>Role</label>
                            <select class="form-control" wire:model="role">
                                <option value="user">User</option>
                                <option value="admin">Admin</option>
                                <option value="pic_wi">PIC WI</option>
                                <option value="pimpinan">Pimpinan</option>
                                <option value="tu_pimpinan">TU Pimpinan</option>
                                <option value="pengelola_aset">Pengelola Aset</option>
                            </select>
                             @error('role') <span class="text-danger">{{ $message }}</span>@enderror
                        </div>
                        <div class="form-group">
                            <label>Nama Bidang</label>
                            <input type="text" class="form-control" wire:model="department_name">
                        </div>
                         <div class="form-group">
                            <label>Instansi</label>
                            <input type="text" class="form-control" wire:model="agency">
                        </div>
                        <div class="form-group">
                            <label>Warna Kalender</label>
                            <input type="color" class="form-control" wire:model="color">
                            @error('color') <span class="text-danger">{{ $message }}</span>@enderror
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" wire:click="closeModal" class="btn btn-secondary">Tutup</button>
                        <button type="submit" class="btn btn-primary">{{ $userId ? 'Update' : 'Simpan' }}</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="modal-backdrop fade show"></div>
    @endif
</div>
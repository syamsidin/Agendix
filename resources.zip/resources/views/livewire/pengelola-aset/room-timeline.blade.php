<div>
     <style>
        .timeline-viewport {
            width: 100%;
            overflow-x: auto;
            border: 1px solid #dee2e6;
        }
        .timeline-container {
            position: relative;
            /* Beri lebar total yang sangat besar untuk 24 jam */
            width: 2400px; /* 24 jam * 100px per jam */
            background-color: #fff;
        }
        .timeline-header {
            display: flex;
            background-color: #f8f9fa;
            position: sticky; top: 0; z-index: 20;
            border-bottom: 1px solid #dee2e6;
        }
        .room-header-label {
            position: sticky; left: 0; z-index: 21;
            background-color: #f8f9fa;
            flex-shrink: 0;
            width: 180px;
            padding: 10px;
            font-weight: bold;
            border-right: 1px solid #dee2e6;
        }
        .time-header-grid { display: flex; flex-grow: 1; }
        .time-header-label {
            flex-basis: 100px; /* Setiap jam lebarnya 100px */
            flex-shrink: 0;
            padding: 10px;
            text-align: left;
            font-size: 0.8rem;
            color: #6c757d;
            border-right: 1px dotted #ced4da;
        }

        .timeline-body { position: relative; }
        .room-row { display: flex; border-top: 1px solid #e9ecef; min-height: 60px; }
        .room-label {
            position: sticky; left: 0; z-index: 15;
            background-color: #fff;
            flex-shrink: 0;
            width: 180px;
            padding: 10px;
            font-weight: 500;
            border-right: 1px solid #dee2e6;
        }
        .room-track { flex-grow: 1; position: relative; display: flex; }
        .time-grid-line {
            flex-basis: 100px; /* Lebar grid line sama dengan label header */
            flex-shrink: 0;
            border-right: 1px dotted #ced4da;
        }
        .agenda-bar {
            position: absolute;
            top: 5px;
            height: calc(100% - 10px);
            background-color: var(--color-bg, #007bff);
            color: white;
            padding: 5px 10px;
            border-radius: 5px;
            font-size: 0.8rem;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            cursor: pointer;
            border: 1px solid var(--color-border, #0056b3);
            display: flex;
            align-items: center;
            z-index: 10;
        }
    </style>

    {{-- Navigasi Tanggal --}}
    <div class="card mb-3">
        <div class="card-body d-flex justify-content-between align-items-center">
             <h4 class="mb-0">Jadwal untuk: <strong>{{ \Carbon\Carbon::parse($selectedDate)->isoFormat('dddd, D MMMM YYYY') }}</strong></h4>
             <div class="btn-group">
                <button wire:click="previousDay" class="btn btn-default"><i class="fas fa-chevron-left"></i></button>
                <button wire:click="goToToday" class="btn btn-default">Hari Ini</button>
                <button wire:click="nextDay" class="btn btn-default"><i class="fas fa-chevron-right"></i></button>
            </div>
        </div>
    </div>

    {{-- Timeline Horizontal --}}
    <div class="timeline-viewport">
        <div class="timeline-container">
            <!-- Header Waktu -->
            <div class="timeline-header">
                <div class="room-header-label">Ruangan</div>
                <div class="time-header-grid">
                    @foreach($timeLabels as $time)
                        <div class="time-header-label">{{ $time }}</div>
                    @endforeach
                </div>
            </div>

            <!-- Body Timeline -->
            <div class="timeline-body">
                @foreach($rooms as $room)
                    <div class="room-row">
                        <div class="room-label">{{ $room->name }}</div>
                        <div class="room-track">
                            @foreach($timeLabels as $time)
                                <div class="time-grid-line"></div>
                            @endforeach
                            @if(isset($timelineData[$room->id]))
                                @foreach($timelineData[$room->id] as $event)
                                    <div class="agenda-bar" 
                                         wire:click="showDetail({{ $event['id'] }})"
                                         title="{{ $event['title'] }} ({{ $event['start_time_str'] }} - {{ $event['end_time_str'] }})"
                                         style="left: {{ $event['left'] }}%; width: {{ $event['width'] }}%; background-color: {{ $event['color'] }}99; border-color: {{ $event['color'] }}; color: black;">
                                        <span>{{ $event['title'] }}</span>
                                    </div>
                                @endforeach
                            @endif
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </div>
    
    {{-- Modal Detail --}}
    @if($isModalOpen && $selectedDetail)
        <div class="modal fade show" style="display: block;">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">{{ $selectedDetail->agenda->title }}</h5>
                        <button wire:click="closeModal" type="button" class="close"><span>×</span></button>
                    </div>
                    <div class="modal-body">
                         <p><strong>Penyelenggara:</strong> {{ $selectedDetail->agenda->user->name }}</p>
                         <p><strong>Ruangan:</strong> {{ $selectedDetail->room->name }}</p>
                         <p><strong>Waktu:</strong> {{ \Carbon\Carbon::parse($selectedDetail->start_time)->format('H:i') }} - {{ \Carbon\Carbon::parse($selectedDetail->end_time)->format('H:i') }}</p>
                    </div>
                </div>
            </div>
        </div>
         <div class="modal-backdrop fade show"></div>
    @endif

</div>
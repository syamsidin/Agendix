<div>
    {{-- Notifikasi --}}
    @if (session()->has('message'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            {{ session('message') }}
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">×</span>
            </button>
        </div>
    @endif

    {{-- ======================================================= --}}
    {{--    BAGIAN 1: DAFTAR AGENDA INDUK SIAP DITUGASKAN        --}}
    {{-- ======================================================= --}}
    <div class="card card-outline card-primary">
        <button wire:click="openManualForm()" class="btn btn-success btn-sm">
                <i class="fas fa-plus-circle"></i> Tambah Penugasan Manual
            </button>
        <div class="card-header">

            <h3 class="card-title"><i class="fas fa-tasks mr-2"></i>Daftar Kegiatan Siap Ditugaskan</h3>

        </div>
        <div class="card-body p-0">
             <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Nama Kegiatan</th>
                            <th>Jumlah Sesi/Jadwal</th>
                            <th style="width: 250px;">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($pendingAgendas as $agenda)
                        <tr>
                            <td>{{ $agenda->title }}</td>
                            <td><span class="badge badge-info">{{ $agenda->details->count() }} Sesi/Jadwal</span></td>
                            <td>
                                <button wire:click="showAgendaDetails({{ $agenda->id }})" class="btn btn-primary btn-sm">
                                    <i class="fas fa-list-ul"></i> Lihat Detail & Tugaskan WI
                                </button>
                            </td>
                        </tr>
                        @empty
                        <tr>
                            <td colspan="3" class="text-center text-muted py-4">Tidak ada kegiatan yang perlu penugasan.</td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    {{-- ======================================================= --}}
    {{--          BAGIAN 2: RIWAYAT SEMUA PENUGASAN              --}}
    {{-- ======================================================= --}}
    <div class="card mt-4">
        <div class="card-header">
            <h3 class="card-title"><i class="fas fa-history mr-2"></i>Riwayat Semua Penugasan</h3>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Widyaiswara</th>
                            <th>Kegiatan & Jadwal</th>
                            <th>Materi</th>
                            <th class="text-center">Bukti Dukung</th>
                            <th style="width: 50px;">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($assignmentHistory as $assignment)
                        <tr>
                            <td>{{ $assignment->widyaiswara->name ?? 'N/A' }}</td>
                            <td>
                                <strong>{{ $assignment->agendaDetail->agenda->title ?? 'N/A' }}</strong>
                                <br>
                                <small class="text-muted">
                                    {{ \Carbon\Carbon::parse(optional($assignment->agendaDetail)->start_date)->isoFormat('D MMM Y') }},
                                    {{ \Carbon\Carbon::parse($assignment->start_time)->format('H:i') }} - {{ \Carbon\Carbon::parse($assignment->end_time)->format('H:i') }}
                                </small>
                            </td>
                            <td>{{ $assignment->material }} ({{ $assignment->jp }} JP)</td>
                            <td class="text-center">
                            @if ($assignment->attachment_path)
                                <a href="{{ asset('storage/' . $assignment->attachment_path) }}" target="_blank" class="btn btn-sm btn-outline-primary" title="Lihat/Download Bukti Dukung">
                                    <i class="fas fa-download"></i>
                                </a>
                            @else
                                <span class="text-muted">-</span>
                            @endif
                        </td>
                            <td><button wire:click="deleteAssignment({{ $assignment->id }})" 
                                    onclick="return confirm('Anda yakin ingin menghapus penugasan ini?')" 
                                    class="btn btn-xs btn-danger" 
                                    title="Hapus Penugasan">
                                <i class="fas fa-trash"></i>
                            </button></td>

                        </tr>

                        @empty
                        <tr>
                            <td colspan="3" class="text-center text-muted py-4">Belum ada riwayat penugasan.</td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
        @if($assignmentHistory->hasPages())
        <div class="card-footer clearfix">
            {{ $assignmentHistory->links() }}
        </div>
        @endif
    </div>

    {{-- ======================================================= --}}
    {{--        MODAL 1: MENAMPILKAN DETAIL JADWAL & PENUGASAN     --}}
    {{-- ======================================================= --}}
    @if($isDetailModalOpen && $agendaToAssign)
<div class="modal fade show" style="display: block; background-color: rgba(0,0,0,0.5);" tabindex="-1">
    <div class="modal-dialog modal-xl modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Detail Jadwal untuk: {{ $agendaToAssign->title }}</h5>
                <button type="button" wire:click="closeDetailModal" class="close" aria-label="Close"><span>×</span></button>
            </div>
            <div class="modal-body">

                {{-- INFORMASI PENYELENGGARA --}}
                <div class="callout callout-info mb-3">
                    <p class="mb-0">
                        <strong>Penyelenggara:</strong> {{ $agendaToAssign->user->name ?? 'N/A' }} 
                        ({{ $agendaToAssign->user->department_name ?? 'Bidang tidak diketahui' }})
                    </p>
                </div>

                @forelse($agendaToAssign->details as $detail)
                    <div class="card mb-3">
                        <div class="card-header bg-light d-flex justify-content-between align-items-center">
                            <h3 class="card-title mb-0" style="font-size: 1rem; font-weight: 500;">
                                <i class="fas fa-calendar-alt"></i> {{ \Carbon\Carbon::parse($detail->start_date)->isoFormat('dddd, D MMM Y') }}
                                | <i class="fas fa-clock"></i> {{ \Carbon\Carbon::parse($detail->start_time)->format('H:i') }}
                                | <i class="fas fa-map-marker-alt"></i> {{ $detail->room->name ?? 'N/A' }}
                            </h3>
                            <button wire:click="openAssignmentForm({{ $detail->id }})" class="btn btn-success btn-sm"><i class="fas fa-plus"></i> Tambah Pengajar</button>
                        </div>
                        <div class="card-body p-0">
                            <table class="table table-sm mb-0">
                                @if($detail->assignments->isNotEmpty())
                                <thead><tr><th>Widyaiswara</th><th>Materi</th><th>Waktu</th><th>JP</th><th>Aksi</th></tr></thead>
                                @endif
                                <tbody>
                                    @forelse($detail->assignments as $asg)
                                        <tr>
                                            <td>{{ $asg->widyaiswara->name }}</td>
                                            <td>{{ $asg->material }}</td>
                                            <td>{{ \Carbon\Carbon::parse($asg->start_time)->format('H:i') }} - {{ \Carbon\Carbon::parse($asg->end_time)->format('H:i') }}</td>
                                            <td>{{ $asg->jp }} JP</td>
                                            <td>
                                                <button wire:click="openAssignmentForm({{ $detail->id }}, {{ $asg->id }})" class="btn btn-xs btn-info" title="Edit"><i class="fas fa-edit"></i></button>
                                                <button wire:click="deleteAssignment({{ $asg->id }})" onclick="return confirm('Hapus penugasan ini?')" class="btn btn-xs btn-danger" title="Hapus"><i class="fas fa-trash"></i></button>
                                            </td>
                                        </tr>
                                    @empty
                                        <tr><td colspan="5" class="text-center text-muted p-3">Belum ada pengajar ditugaskan untuk sesi ini.</td></tr>
                                    @endforelse
                                </tbody>
                            </table>
                        </div>
                    </div>
                @empty
                    <p class="text-center text-muted">Agenda ini tidak memiliki detail jadwal.</p>
                @endforelse
            </div>
            <div class="modal-footer">
                <button type="button" wire:click="closeDetailModal" class="btn btn-secondary">Tutup</button>
            </div>
        </div>
    </div>
</div>
@endif

    {{-- ======================================================= --}}
    {{--          MODAL 2: FORM PENUGASAN WIDYAISWARA            --}}
    {{-- ======================================================= --}}
     {{-- ======================================================= --}}
    {{--          MODAL 2: FORM PENUGASAN (DIPERBAIKI)           --}}
    {{-- ======================================================= --}}
    @if($isAssignmentFormOpen)
    <div class="modal fade show" style="display: block; background-color: rgba(0,0,0,0.7);" tabindex="-1">
        <div class="modal-dialog modal-lg modal-dialog-scrollable">
            <div class="modal-content">
                <form wire:submit.prevent="saveAssignment">
                    <div class="modal-header">
                        <h5 class="modal-title">{{ $assignmentId ? 'Edit' : 'Tambah' }} Pengajar</h5>
                        <button type="button" wire:click="closeAssignmentForm" class="close"><span>×</span></button>
                    </div>
                    <div class="modal-body">
                        
                        {{-- BLOK KONDISIONAL UNTUK INFO KEGIATAN --}}
                        @if($isManualMode)
                            {{-- Input Manual --}}
                            <div class="form-group">
                                <label>Nama Kegiatan</label>
                                <input type="text" wire:model.defer="manual_activity_name" class="form-control @error('manual_activity_name') is-invalid @enderror" placeholder="cth: Rapat Koordinasi Teknis">
                                @error('manual_activity_name') <span class="invalid-feedback">{{ $message }}</span>@enderror
                            </div>
                            <div class="row">
                                <div class="col-md-6 form-group">
                                    <label>Tempat / Lokasi</label>
                                    <input type="text" wire:model.defer="manual_place" class="form-control @error('manual_place') is-invalid @enderror" placeholder="cth: Ruang Rapat Lt. 2">
                                    @error('manual_place') <span class="invalid-feedback">{{ $message }}</span>@enderror
                                </div>
                                <div class="col-md-6 form-group">
                                    <label>Tanggal</label>
                                    <input type="date" wire:model.defer="manual_date" class="form-control @error('manual_date') is-invalid @enderror">
                                    @error('manual_date') <span class="invalid-feedback">{{ $message }}</span>@enderror
                                </div>
                            </div>
                        @else
                            {{-- Info Otomatis dari Detail Agenda --}}
                            @if($detailToAssign)
                                @php $detailModel = \App\Models\AgendaDetail::with('agenda','room')->find($detailToAssign); @endphp
                                @if($detailModel)
                                <div class="callout callout-info">
                                    <h5><i class="fas fa-info-circle"></i> Informasi Jadwal</h5>
                                    <p class="mb-0"><strong>Kegiatan:</strong> {{ $detailModel->agenda->title }}</p>
                                    <p class="mb-0"><strong>Tempat:</strong> {{ $detailModel->room->name ?? 'N/A' }}</p>
                                    <p class="mb-0"><strong>Tanggal:</strong> {{ \Carbon\Carbon::parse($detailModel->start_date)->isoFormat('D MMMM YYYY') }}</p>
                                </div>
                                @endif
                            @endif
                        @endif
                        <hr>
                        
                        {{-- Form Penugasan (sama untuk keduanya) --}}
                        <h6 class="font-weight-bold">Detail Penugasan Widyaiswara</h6>
                        <div class="form-group">
                            <label>Pilih Widyaiswara</label>
                            <select wire:model="widyaiswara_id" class="form-control @error('widyaiswara_id') is-invalid @enderror">
                                <option value="">-- Pilih WI --</option>
                                @foreach($widyaiswaras as $wi)
                                    <option value="{{ $wi->id }}">{{ $wi->name }}</option>
                                @endforeach
                            </select>
                            @error('widyaiswara_id') <span class="invalid-feedback">{{ $message }}</span>@enderror
                        </div>
                        <div class="form-group">
                            <label>Materi</label>
                            <input type="text" wire:model="material" class="form-control @error('material') is-invalid @enderror">
                            @error('material') <span class="invalid-feedback">{{ $message }}</span>@enderror
                        </div>
                         <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>Waktu Mulai</label>
                                    <input type="time" wire:model="start_time" class="form-control @error('start_time') is-invalid @enderror">
                                    @error('start_time') <span class="invalid-feedback">{{ $message }}</span>@enderror
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>Waktu Selesai</label>
                                    <input type="time" wire:model="end_time" class="form-control @error('end_time') is-invalid @enderror">
                                    @error('end_time') <span class="invalid-feedback">{{ $message }}</span>@enderror
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>Jam Pelajaran (JP)</label>
                                    <input type="number" wire:model="jp" class="form-control @error('jp') is-invalid @enderror">
                                    @error('jp') <span class="invalid-feedback">{{ $message }}</span>@enderror
                                </div>
                            </div>
                            <div class="form-group">
                            <label>Upload Data Dukung (Opsional)</label>
                            <small class="form-text text-muted d-block mb-2">Tipe file: jpg, png, doc, docx, pdf. Maksimal 5MB.</small>
                            
                            {{-- Tampilkan file yang sudah ada (saat edit) --}}
                            @if ($existingAttachment)
                                <div class="mb-2">
                                    File saat ini: 
                                    <a href="{{ asset('storage/' . $existingAttachment) }}" target="_blank">
                                        <i class="fas fa-paperclip"></i> {{ basename($existingAttachment) }}
                                    </a>
                                    <button type="button" wire:click="removeAttachment" class="btn btn-xs btn-outline-danger ml-2" title="Hapus Lampiran">
                                        <i class="fas fa-times"></i>
                                    </button>
                                </div>
                                 @if (session()->has('attachment_info'))
                                    <div class="alert alert-info p-2 small">{{ session('attachment_info') }}</div>
                                @endif
                            @endif
                            
                            {{-- Input untuk upload file baru --}}
                            <input type="file" wire:model="attachment" class="form-control-file @error('attachment') is-invalid @enderror">
                            
                            {{-- Indikator loading saat upload --}}
                            <div wire:loading wire:target="attachment" class="text-muted mt-1">
                                <i class="fas fa-spinner fa-spin"></i> Mengupload...
                            </div>
                            
                            @error('attachment') <span class="invalid-feedback d-block">{{ $message }}</span> @enderror
                            
                            {{-- Pratinjau gambar jika yang diupload adalah gambar --}}
                            @if ($attachment && Str::startsWith($attachment->getMimeType(), 'image/'))
                                <div class="mt-2">
                                    <img src="{{ $attachment->temporaryUrl() }}" class="img-thumbnail" style="max-width: 200px;">
                                </div>
                            @endif
                        </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" wire:click="closeAssignmentForm" class="btn btn-secondary">Batal</button>
                        <button type="submit" class="btn btn-primary">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    @endif
</div>
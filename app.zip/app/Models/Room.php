<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany; // <-- Tambahkan ini jika belum ada

class Room extends Model
{
    use HasFactory;
    
    protected $fillable = ['name', 'facilities', 'capacity', 'location'];

    /**
     * Definisikan relasi bahwa satu Ruangan bisa memiliki banyak Agenda.
     * 
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */

     public function images()
    {
        return $this->hasMany(RoomImage::class);
    }
    
    public function agendas(): HasMany
    {
        // 'agendas' adalah nama tabel, 'room_id' adalah foreign key di tabel agendas
        return $this->hasMany(Agenda::class);
    }


}
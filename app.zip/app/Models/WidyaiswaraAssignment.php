<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class WidyaiswaraAssignment extends Model
{
    use HasFactory;

    // PASTIKAN NAMA KOLOM DI SINI SUDAH 'agenda_detail_id'
    protected $fillable = ['agenda_detail_id', 'widyaiswara_id', 'material', 'start_time', 'end_time', 'jp', 'attachment_path'];

    public function widyaiswara()
    {
        return $this->belongsTo(Widyaiswara::class);
    }

    public function agendaDetail()
    {
         return $this->belongsTo(AgendaDetail::class);
    }
}
<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Agenda extends Model
{
    use HasFactory;
    protected $fillable = [
        'user_id', 'room_id', 'title', 'description', 'konseptor_name', 'start_date', 'end_date',
        'start_time', 'end_time', 'manual_location', 'type', 'status', 'rejection_reason',
    ];

    protected $casts = [
        'start_date' => 'date',
        'end_date' => 'date',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

public function rooms()
    {
        return $this->belongsToMany(Room::class, 'agenda_room');
    }

    public function assignments()
    {
        return $this->hasMany(WidyaiswaraAssignment::class);
    }
    public function details() {
        return $this->hasMany(AgendaDetail::class); }
}
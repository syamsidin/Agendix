<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;


class Disposition extends Model
{
    use HasFactory;
    protected $fillable = [
    'agenda_detail_id', 'struktural_id', 'purpose', 
    'start_time', 'user_id' // <-- PASTIKAN INI ADA
];
    public function agendaDetail() { return $this->belongsTo(AgendaDetail::class); }
    public function struktural() { return $this->belongsTo(Struktural::class); }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AgendaDetail extends Model
{
   use HasFactory;

    protected $fillable = [
        'agenda_id', 'room_id', 'manual_location',
        'start_date', 'end_date', 'start_time', 'end_time'
    ];
    
    protected $casts = [
        'start_date' => 'date',
        'end_date' => 'date',
    ];

    public function agenda()
    {
        return $this->belongsTo(Agenda::class);
    }

    public function room()
    {
        return $this->belongsTo(Room::class);
    }

    /**
     * Get the assignment associated with the agenda detail.
     */
    // TAMBAHKAN METHOD INI
    public function assignments()
    {
        return $this->hasMany(WidyaiswaraAssignment::class);
    }

    public function dispositions()
    {
        return $this->hasMany(Disposition::class);
    }
}
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Survey extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'reference_id',
        'reference_type',
        'question_1_answer',
        'question_2_answer'
    ];

    /**
     * Get the user that owns the survey.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    // TAMBAHKAN METHOD INI
    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
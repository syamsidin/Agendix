<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Widyaiswara extends Model
{
    use HasFactory;
    protected $fillable = ['name', 'nip', 'position', 'rank', 'whatsapp'];
    
    public function assignments()
	{
	    return $this->hasMany(WidyaiswaraAssignment::class);
	}
}


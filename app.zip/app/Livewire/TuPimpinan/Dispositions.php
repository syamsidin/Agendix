<?php
namespace App\Livewire\TuPimpinan;

use Livewire\Component;
use App\Models\Agenda;
use App\Models\Struktural;
use App\Models\Disposition;

class Dispositions extends Component
{
    // Properti utama untuk daftar agenda
    public $agendas;
    
    // Properti untuk Modal
    public $isModalOpen = false;
    public $agenda_detail_id;
    public $dispositionsForDetail = [];
    public $dispositionId; // Untuk membedakan mode edit atau create
    
    // Properti untuk Form
    public $struktural_id;
    public $purpose;
    public $start_time;
    public $strukturals = []; // Untuk mengisi dropdown pejabat

    public $purposeList = [
        'Membuka Acara', 'Menutup Acara', 'Mewakili Membuka Acara',
        'Mewakili Menutup Acara', 'Menjadi Pemateri'
    ];

    public function mount()
    {
        // Muat data agenda saat komponen pertama kali dimuat
        $this->loadAgendas();
    }
    
    public function loadAgendas()
    {
        // Query untuk mengambil semua agenda yang relevan
        $this->agendas = Agenda::with('user', 'details.room', 'details.dispositions.struktural')
            ->whereIn('status', ['approved', 'pending'])
            ->latest()->get();
    }
    
     public function resetForm()
    {
        $this->dispositionId = null;
        $this->struktural_id = '';
        $this->purpose = '';
        $this->start_time = '';
        $this->resetErrorBag();
    }

    public function openDispoForm($detailId)
    {
        $this->resetForm();
        $this->agenda_detail_id = $detailId;
        // Asumsi Anda punya model Struktural, jika tidak, ganti dengan data statis
        $this->strukturals = Struktural::orderBy('name')->get(); 
        $this->loadDispositionsForDetail($detailId);
        $this->isModalOpen = true;
    }
    
    public function loadDispositionsForDetail($detailId)
    {
        $this->dispositionsForDetail = Disposition::with('struktural')
            ->where('agenda_detail_id', $detailId)
            ->orderBy('start_time')
            ->get();
    }

    public function closeModal()
    {
        $this->isModalOpen = false;
        $this->resetForm();
        $this->agenda_detail_id = null;
        $this->loadAgendas(); // Refresh daftar agenda utama
    }

    public function saveDisposition()
    {
        $this->validate([
            'struktural_id' => 'required|exists:strukturals,id',
            'purpose' => 'required|string',
            'start_time' => 'required',
        ]);
        
        Disposition::updateOrCreate(
            ['id' => $this->dispositionId],
            [
                'agenda_detail_id' => $this->agenda_detail_id,
                'struktural_id' => $this->struktural_id,
                'purpose' => $this->purpose,
                'start_time' => $this->start_time,
                'user_id' => auth()->id()
            ]
        );
        
        session()->flash('message', 'Disposisi berhasil disimpan.');
        //$this->resetForm();
        $this->loadDispositionsForDetail($this->agenda_detail_id);
    }

    public function editDisposition($id)
    {
        $dispo = Disposition::findOrFail($id);
        $this->dispositionId = $dispo->id;
        $this->struktural_id = $dispo->struktural_id;
        $this->purpose = $dispo->purpose;
        $this->start_time = $dispo->start_time;
    }

    public function deleteDisposition($id)
    {
        Disposition::find($id)->delete();
        session()->flash('message', 'Disposisi berhasil dihapus.');
        $this->loadDispositionsForDetail($this->agenda_detail_id);
    }

    // Method render HARUS ada untuk mengirimkan data ke view
    public function render()
    {
        return view('livewire.tu-pimpinan.dispositions');
    }
}
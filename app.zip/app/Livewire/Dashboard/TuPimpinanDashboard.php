<?php

namespace App\Livewire\Dashboard;

use Livewire\Component;

class TuPimpinanDashboard extends Component
{
    public function render()
    {
        return view('livewire.dashboard.tu-pimpinan-dashboard');
    }
}
<?php

namespace App\Livewire\Dashboard;

use Livewire\Component;

class UserDashboard extends Component
{
    public function render()
    {
        return view('livewire.dashboard.user-dashboard');
    }
}

<?php

namespace App\Livewire\Dashboard;

use Livewire\Component;
use App\Models\Widyaiswara;
use App\Models\WidyaiswaraAssignment;

class PimpinanDashboard extends Component
{
    public $chartData;
    
    // Properti untuk modal
    public $isModalOpen = false;
    public $modalTitle = '';
    public $widyaiswaraList = [];

    public function mount()
    {
        $this->prepareChartData();
    }

    public function prepareChartData()
    {
        // Ambil ID semua WI yang punya penugasan (aktif)
        $activeWiIds = WidyaiswaraAssignment::distinct('widyaiswara_id')->pluck('widyaiswara_id');
        
        // Ambil semua data WI
        $allWis = Widyaiswara::all();

        $activeWiCount = $activeWiIds->count();
        $totalWiCount = $allWis->count();
        $inactiveWiCount = $totalWiCount - $activeWiCount;

        $this->chartData = [
            'active' => $activeWiCount,
            'inactive' => $inactiveWiCount,
        ];
    }
    
    // Method ini akan dipanggil dari JavaScript
    public function showWidyaiswaraList($status)
    {
        $activeWiIds = WidyaiswaraAssignment::distinct('widyaiswara_id')->pluck('widyaiswara_id');

        if ($status === 'active') {
            $this->modalTitle = 'Daftar Widyaiswara Aktif';
            $this->widyaiswaraList = Widyaiswara::whereIn('id', $activeWiIds)->orderBy('name')->get();
        } elseif ($status === 'inactive') {
            $this->modalTitle = 'Daftar Widyaiswara Tidak Aktif';
            $this->widyaiswaraList = Widyaiswara::whereNotIn('id', $activeWiIds)->orderBy('name')->get();
        } else {
            return; // Jangan lakukan apa-apa jika status tidak valid
        }
        
        $this->isModalOpen = true;
    }

    public function closeModal()
    {
        $this->isModalOpen = false;
        $this->widyaiswaraList = [];
        $this->modalTitle = '';
    }

    public function render()
    {
        return view('livewire.dashboard.pimpinan-dashboard');
    }
}
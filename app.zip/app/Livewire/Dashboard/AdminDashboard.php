<?php

namespace App\Livewire\Dashboard;

use Livewire\Component;

class AdminDashboard extends Component
{
    public function render()
    {
        // View ini akan dibuat otomatis oleh perintah `make:livewire`
        return view('livewire.dashboard.admin-dashboard');
    }
}
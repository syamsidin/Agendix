<?php
namespace App\Livewire\PengelolaAset;

use Livewire\Component;
use App\Models\Room;
use App\Models\AgendaDetail;
use Carbon\Carbon;
use Carbon\CarbonPeriod;

class RoomTimeline extends Component
{
    public $selectedDate;
    public $rooms;
    public $timelineData = [];
    public $timeLabels = [];

    // Untuk Modal
    public $selectedDetail;
    public $isModalOpen = false;

    public function mount()
    {
        $this->selectedDate = Carbon::today()->toDateString();
        $this->prepareTimeline();
    }

    public function prepareTimeline()
    {
        // Ambil semua ruangan
        $this->rooms = Room::orderBy('name')->get();

        // Ambil semua detail agenda pada tanggal yang dipilih
        $agendaDetails = AgendaDetail::with('agenda.user', 'room')
            ->whereNotNull('room_id')
            ->whereHas('agenda', function ($query) {
                $query->where('status', 'approved');
                })
            ->whereDate('start_date', '<=', $this->selectedDate)
            ->whereDate('end_date', '>=', $this->selectedDate)
            ->get();
            
         // ===================================
        //        LOGIKA KALKULASI BARU
        // ===================================
        $this->timelineData = [];
        
        $totalMinutesInDay = 24 * 60; // Total menit dalam sehari = 1440

         $this->timeLabels = [];
        for ($hour = 0; $hour < 24; $hour++) {
            $this->timeLabels[] = sprintf('%02d:00', $hour);
        }
        

        foreach ($agendaDetails as $detail) {
            $startTime = Carbon::parse($detail->start_time);
            $endTime = Carbon::parse($detail->end_time);

            if ($endTime->format('H:i') == '00:00') {
                $endTime->addDay()->subSecond();
            }

           // Kalkulasi posisi kiri (left) dalam persentase
            $startOffsetMinutes = ($startTime->hour * 60) + $startTime->minute;
            $leftPercentage = ($startOffsetMinutes / $totalMinutesInDay) * 100;

            
            // Kalkulasi durasi dan lebar (width) dalam persentase
            $durationInMinutes = $startTime->diffInMinutes($endTime);
            $widthPercentage = ($durationInMinutes / $totalMinutesInDay) * 100;

            if (($leftPercentage + $widthPercentage) > 100) {
                $widthPercentage = 100 - $leftPercentage;
            }

            // Masukkan data yang sudah dikalkulasi ke dalam array
            $this->timelineData[$detail->room_id][] = [
                'id' => $detail->id,
                'title' => $detail->agenda->title,
                'user' => $detail->agenda->user->name,
                'color' => $detail->agenda->user->color,
                'start_time_str' => $startTime->format('H:i'),
                'end_time_str' => $endTime->format('H:i'),
                'left' => $leftPercentage,
                'width' => $widthPercentage
            ];
        }
    }

    public function showDetail($detailId)
    {
        $this->selectedDetail = AgendaDetail::with('agenda.user', 'room')->find($detailId);
        $this->isModalOpen = true;
    }

    public function closeModal() { $this->isModalOpen = false; }
    public function previousDay() { $this->selectedDate = Carbon::parse($this->selectedDate)->subDay()->toDateString(); $this->prepareTimeline(); }
    public function nextDay() { $this->selectedDate = Carbon::parse($this->selectedDate)->addDay()->toDateString(); $this->prepareTimeline(); }
    public function goToToday() { $this->selectedDate = Carbon::today()->toDateString(); $this->prepareTimeline(); }

    public function render()
    {
        return view('livewire.pengelola-aset.room-timeline');
    }
}
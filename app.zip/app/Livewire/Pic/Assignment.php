<?php
namespace App\Livewire\Pic;

use Livewire\Component;
use App\Models\Agenda;
use App\Models\AgendaDetail;
use App\Models\Widyaiswara;
use App\Models\WidyaiswaraAssignment;
use Livewire\WithPagination;
use Livewire\WithFileUploads; // <-- 1. GUNAKAN TRAIT INI
use Illuminate\Support\Facades\Storage;

class Assignment extends Component
{
    use WithPagination;
    use WithPagination, WithFileUploads;

    // Modal 1
    public $isDetailModalOpen = false;
    public $agendaToAssign;

    public $attachment;
    public $existingAttachment;

    // Modal 2 (Form)
    public $isAssignmentFormOpen = false;
    public $detailToAssign;
    public $widyaiswaras = [];
    public $assignmentId;

    // Form fields
    public $widyaiswara_id, $material, $start_time, $end_time, $jp;

    // Properti untuk mode manual
    public $isManualMode = false;
    public $manual_activity_name, $manual_place, $manual_date;

    public function render()
    {
        $pendingAgendas = Agenda::with('details')
            ->where('type', 'internal')->where('status', 'approved')
            ->orderBy('created_at', 'asc')->get();
        
        $assignmentHistory = WidyaiswaraAssignment::with('widyaiswara', 'agendaDetail.agenda', 'agendaDetail.room')
            ->latest()->simplePaginate(5);

        return view('livewire.pic.assignment', [
            'pendingAgendas' => $pendingAgendas,
            'assignmentHistory' => $assignmentHistory,
        ]);
    }
    
    // --- Alur Kerja Penugasan dari Agenda ---
    public function showAgendaDetails($agendaId)
    {
        $this->agendaToAssign = Agenda::with('details.room', 'details.assignments.widyaiswara')->find($agendaId);
        $this->isDetailModalOpen = true;
    }

    public function openAssignmentForm($detailId, $assignmentId = null)
    {
        $this->resetFormFields();
        $this->isManualMode = false;
        $this->detailToAssign = $detailId;
        $this->widyaiswaras = Widyaiswara::orderBy('name')->get();
        
        if ($assignmentId) {
            $assignment = WidyaiswaraAssignment::find($assignmentId);
            $this->assignmentId = $assignment->id;
            $this->widyaiswara_id = $assignment->widyaiswara_id;
            $this->material = $assignment->material;
            $this->start_time = $assignment->start_time;
            $this->end_time = $assignment->end_time;
            $this->jp = $assignment->jp;
            $this->existingAttachment = $assignment->attachment_path;
        }
        
        $this->isAssignmentFormOpen = true;
    }

    public function removeAttachment()
    {
        if ($this->existingAttachment) {
            Storage::disk('public')->delete($this->existingAttachment);
            WidyaiswaraAssignment::find($this->assignmentId)->update(['attachment_path' => null]);
            $this->existingAttachment = null;
            session()->flash('attachment_info', 'Lampiran berhasil dihapus.');
        }
    }
    
    // --- METHOD YANG HILANG SEBELUMNYA ---
    public function openManualForm()
    {
        $this->resetFormFields();
        $this->isManualMode = true; // Aktifkan mode manual
        $this->widyaiswaras = Widyaiswara::orderBy('name')->get();
        $this->isAssignmentFormOpen = true;
    }

    // --- Logika Penyimpanan Universal ---
    public function saveAssignment()
    {
        $rules = [
            'widyaiswara_id' => 'required|exists:widyaiswaras,id',
            'material' => 'required|string',
            'start_time' => 'required',
            'end_time' => 'required|after:start_time',
            'jp' => 'required|integer|min:1',
            'attachment' => 'nullable|file|mimes:jpg,jpeg,png,doc,docx,pdf|max:5120', // max 5MB
        ];
        
        if ($this->isManualMode) {
            $rules['manual_activity_name'] = 'required|string';
            $rules['manual_place'] = 'required|string';
            $rules['manual_date'] = 'required|date';
        }
        $this->validate($rules);
        
        $detailId = $this->detailToAssign;
         $attachmentPath = $this->existingAttachment;

        if ($this->isManualMode) {
            $dummyAgenda = Agenda::create([
                'user_id' => auth()->id(), 'title' => $this->manual_activity_name,
                'description' => 'Penugasan manual oleh PIC.', 'type' => 'external', 'status' => 'approved',
            ]);
            $dummyDetail = $dummyAgenda->details()->create([
                'start_date' => $this->manual_date, 'end_date' => $this->manual_date,
                'start_time' => $this->start_time, 'end_time' => $this->end_time,
                'manual_location' => $this->manual_place,
            ]);
            $detailId = $dummyDetail->id;
        }
        if ($this->attachment) {
            // Hapus file lama jika ada yang baru diupload
            if ($this->existingAttachment) {
                Storage::disk('public')->delete($this->existingAttachment);
            }
            // Simpan file baru dan dapatkan path-nya
            $attachmentPath = $this->attachment->store('attachments', 'public');
        }

        $assignment = WidyaiswaraAssignment::updateOrCreate(['id' => $this->assignmentId], [
            'agenda_detail_id' => $detailId, 
            'widyaiswara_id' => $this->widyaiswara_id, 
            'material' => $this->material,
            'start_time' => $this->start_time,
            'end_time' => $this->end_time,
            'jp' => $this->jp,
            'attachment_path' => $attachmentPath,
        ]);

        session()->flash('message', 'Penugasan berhasil disimpan.');
        session()->flash('show_survey', [
        'id' => $assignment->id,
        'type' => 'assignment' // Tipe referensi
        ]);
        $this->closeAssignmentForm();
        if ($this->agendaToAssign) {
            $this->agendaToAssign->refresh();
        }
    }
    
    public function deleteAssignment($assignmentId) {
        $assignment = WidyaiswaraAssignment::find($assignmentId);
        if ($assignment) {

             if ($assignment->attachment_path) {
                Storage::disk('public')->delete($assignment->attachment_path);
            }
            $assignment->delete();
            session()->flash('message', 'Penugasan berhasil dihapus.');
            if ($this->agendaToAssign) {
                $this->agendaToAssign->refresh();
            }
        }
    }

    public function closeDetailModal() { $this->isDetailModalOpen = false; $this->agendaToAssign = null; }
    public function closeAssignmentForm() { $this->isAssignmentFormOpen = false; $this->resetFormFields(); }
    
    private function resetFormFields() {
        $this->assignmentId = null; $this->widyaiswara_id = ''; $this->material = '';
        $this->start_time = ''; $this->end_time = ''; $this->jp = '';
        $this->isManualMode = false; $this->manual_activity_name = '';
        $this->manual_place = ''; $this->manual_date = ''; $this->resetErrorBag();
        $this->detailToAssign = null;
         $this->attachment = null;
        $this->existingAttachment = null;
    }
}
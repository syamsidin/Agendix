<?php

namespace App\Livewire\User;

use Livewire\Component;
use App\Models\AgendaDetail;
use Carbon\Carbon;

class RoomSchedule extends Component
{
    public $selectedDate;

    public function mount()
    {
        // Default ke tanggal hari ini
        $this->selectedDate = Carbon::today()->toDateString();
    }

    public function render()
    {
        // Ambil semua detail agenda internal yang disetujui pada tanggal yang dipilih
        $schedules = AgendaDetail::with('agenda.user', 'room')
            ->whereNotNull('room_id') // Hanya yang menggunakan ruangan
            ->whereHas('agenda', function ($query) {
                $query->where('status', 'approved');
            })
            ->whereDate('start_date', '<=', $this->selectedDate)
            ->whereDate('end_date', '>=', $this->selectedDate)
            ->orderBy('room_id')
            ->orderBy('start_time')
            ->get()
            ->groupBy('room.name'); // Kelompokkan berdasarkan nama ruangan

        return view('livewire.user.room-schedule', [
            'schedulesByRoom' => $schedules,
            'date_for_view' => Carbon::parse($this->selectedDate),
        ]);
    }

    // Fungsi navigasi tanggal
    public function previousDay() { $this->selectedDate = Carbon::parse($this->selectedDate)->subDay()->toDateString(); }
    public function nextDay() { $this->selectedDate = Carbon::parse($this->selectedDate)->addDay()->toDateString(); }
    public function goToToday() { $this->selectedDate = Carbon::today()->toDateString(); }
}
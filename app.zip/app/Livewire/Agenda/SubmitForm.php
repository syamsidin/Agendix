<?php
namespace App\Livewire\Agenda;

use Livewire\Component;
use App\Models\Room;
use App\Models\Agenda;
use App\Models\AgendaDetail;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Notification;
use App\Models\User;
use App\Notifications\AgendaSubmitted;

class SubmitForm extends Component
{
    public $step = 1;
    public $type;
    public $title, $description, $konseptor_name;

    public $agendaDetails = [];

    public function mount()
    {
        $this->addSchedule();
    }

    public function setType($type)
    {
        $this->type = $type;
        $this->step = 2;
        $this->resetValidation();
        $this->agendaDetails = [];
        $this->addSchedule();
    }

    public function addSchedule()
    {
        if ($this->type === 'internal' || empty($this->agendaDetails)) {
            $this->agendaDetails[] = [
                'start_date' => '', 'end_date' => '', 'start_time' => '', 'end_time' => '',
                'room_id' => '', 'manual_location' => '', 'availableRooms' => []
            ];
        }
    }

    public function findAvailableRooms($index)
{
    // Hanya cari jika tipe internal
    if ($this->type !== 'internal') return;

    $detail = $this->agendaDetails[$index];

    if ($detail['start_date'] && $detail['end_date'] && $detail['start_time'] && $detail['end_time']) {
        
        // Ambil semua ID ruangan yang sudah terpakai pada jadwal yang berkonflik
        $bookedRoomIds = AgendaDetail::whereNotNull('room_id')
            ->where(function ($query) use ($detail) {
                // Cek konflik tanggal
                $query->where(function ($q) use ($detail) {
                    $q->where('start_date', '<=', $detail['end_date'])
                      ->where('end_date', '>=', $detail['start_date']);
                });
            })
            ->where(function ($query) use ($detail) {
                // Cek konflik waktu
                $query->where(function ($q) use ($detail) {
                    $q->where('start_time', '<', $detail['end_time'])
                      ->where('end_time', '>', $detail['start_time']);
                });
            })
            // ===============================================
            //        PERUBAHAN KUNCI DI SINI
            // ===============================================
            // Pastikan hanya dari agenda yang sudah disetujui ATAU masih pending
            ->whereHas('agenda', function ($q) {
                $q->whereIn('status', ['approved', 'pending']);
            })
            ->pluck('room_id')
            ->filter();

        // Ambil semua ruangan KECUALI yang sudah terpakai
        $availableRooms = Room::whereNotIn('id', $bookedRoomIds)->orderBy('name')->get();

        // Update properti availableRooms untuk baris yang sesuai
        $this->agendaDetails[$index]['availableRooms'] = $availableRooms;
    }
}

    public function updatedAgendaDetails($value, $key)
    {
        $parts = explode('.', $key);
        $index = $parts[0];
        $field = $parts[1];
        if ($this->type === 'internal' && in_array($field, ['start_date', 'end_date', 'start_time', 'end_time'])) {
            $this->findAvailableRooms($index);
        }
    }

    public function submit()
    {
        $this->validate([
            'title' => 'required|string|max:255',
            'description' => 'required|string',
            'konseptor_name' => 'required_if:type,internal|nullable|string|max:255',
            'agendaDetails' => 'required|array|min:1',
            'agendaDetails.*.start_date' => 'required|date',
            'agendaDetails.*.end_date' => 'required|date|after_or_equal:agendaDetails.*.start_date',
            'agendaDetails.*.start_time' => 'required',
            'agendaDetails.*.end_time' => 'required|after:agendaDetails.*.start_time',
            'agendaDetails.*.room_id' => 'required_if:type,internal',
            'agendaDetails.*.manual_location' => 'required_if:type,external',
        ], [
            'agendaDetails.*.start_date.required' => 'Tanggal mulai harus diisi.',
            'agendaDetails.*.room_id.required_if' => 'Ruangan harus dipilih untuk agenda internal.',
            'agendaDetails.*.manual_location.required_if' => 'Lokasi harus diisi untuk agenda eksternal.',
        ]);

        // INI ADALAH BAGIAN KUNCI YANG PERLU DIPERIKSA
        $agenda = Agenda::create([
            'user_id' => Auth::id(), // Pastikan ini ada
            'title' => $this->title, // Pastikan ini ada
            'description' => $this->description, // Pastikan ini ada
            'konseptor_name' => $this->type == 'internal' ? $this->konseptor_name : null,
            'type' => $this->type, // Pastikan ini ada
            'status' => $this->type == 'external' ? 'approved' : 'pending',
        ]);

        foreach ($this->agendaDetails as $detail) {
            $agenda->details()->create([
                'start_date' => $detail['start_date'],
                'end_date' => $detail['end_date'],
                'start_time' => $detail['start_time'],
                'end_time' => $detail['end_time'],
                'room_id' => $this->type == 'internal' ? $detail['room_id'] : null,
                'manual_location' => $this->type == 'external' ? $detail['manual_location'] : null,
            ]);
        }
        
        if ($agenda->type == 'internal') {
             $recipients = User::whereIn('role', ['admin', 'pengelola_aset'])->get();
            Notification::send($recipients, new AgendaSubmitted($agenda));
        }
        
        session()->flash('message', 'Agenda berhasil diajukan!');
        session()->flash('show_survey', [
        'id' => $agenda->id,
        'type' => 'agenda' // Tipe referensi
    ]);
        return redirect()->to('/dashboard');
    }

    public function back()
    {
        $this->step = 1;
        $this->reset(['type', 'title', 'description', 'konseptor_name']);
        $this->agendaDetails = [];
        $this->addSchedule();
    }

    public function render()
    {
        return view('livewire.agenda.submit-form');
    }
}
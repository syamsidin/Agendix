<?php
namespace App\Livewire\Agenda;

use Livewire\Component;
use App\Models\Agenda;
use App\Models\AgendaDetail;
use App\Models\Room;
use Illuminate\Support\Facades\Auth;
use Livewire\WithPagination;

class History extends Component
{
    use WithPagination;

    // Properti untuk Modal Edit
    public $isModalOpen = false;
    public $agendaToEdit;
    public $agendaId;

    // PROPERTI YANG HILANG SEBELUMNYA
    public $title, $description, $type;
    public $agendaDetails = []; // Ini yang akan menampung jadwal

    public function render()
    {
        $agendas = Agenda::with('details.room')
            ->where('user_id', Auth::id())
            ->latest()
            ->paginate(10);

        return view('livewire.agenda.history', [
            'agendas' => $agendas
        ]);
    }

    public function openModal() { $this->isModalOpen = true; }
    public function closeModal() { $this->isModalOpen = false; $this->resetInputFields(); }

    private function resetInputFields() {
        $this->reset(['title', 'description', 'type', 'agendaId', 'agendaToEdit']);
        $this->agendaDetails = [];
        $this->resetErrorBag();
    }
    
    // ======================================================= //
    // METHOD-METHOD BARU YANG PERLU ANDA SALIN DARI SubmitForm.php
    // ======================================================= //
    
    public function addSchedule() {
        if ($this->type === 'internal' || $this->type === 'external') {
             $this->agendaDetails[] = [
                'id' => null, // ID untuk detail baru
                'start_date' => '', 'end_date' => '', 'start_time' => '', 'end_time' => '',
                'room_id' => '', 'manual_location' => '', 'availableRooms' => []
            ];
        }
    }

    public function removeSchedule($index) {
        $detailId = $this->agendaDetails[$index]['id'] ?? null;
        if($detailId) {
            AgendaDetail::find($detailId)->delete();
        }
        unset($this->agendaDetails[$index]);
        $this->agendaDetails = array_values($this->agendaDetails);
    }
    
    public function findAvailableRooms($index) {
        if ($this->type !== 'internal') return;
        $detail = $this->agendaDetails[$index];
        if ($detail['start_date'] && $detail['end_date'] && $detail['start_time'] && $detail['end_time']) {
            $bookedRoomIds = AgendaDetail::whereNotNull('room_id')
                ->where('id', '!=', ($detail['id'] ?? 0))
                ->where(function ($query) use ($detail) {
                    $query->where(function ($q) use ($detail) {
                        $q->where('start_date', '<=', $detail['end_date'])->where('end_date', '>=', $detail['start_date']);
                    });
                })->where(function ($query) use ($detail) {
                    $query->where(function ($q) use ($detail) {
                        $q->where('start_time', '<', $detail['end_time'])->where('end_time', '>', $detail['start_time']);
                    });
                })->whereHas('agenda', function ($q) {
                    $q->where('status', 'approved');
                })->pluck('room_id')->filter();
            $availableRooms = Room::whereNotIn('id', $bookedRoomIds)->orderBy('name')->get();
            $this->agendaDetails[$index]['availableRooms'] = $availableRooms;
        }
    }

    public function updatedAgendaDetails($value, $key) {
        $parts = explode('.', $key);
        $index = $parts[0];
        $field = $parts[1];
        if ($this->type === 'internal' && in_array($field, ['start_date', 'end_date', 'start_time', 'end_time'])) {
            $this->findAvailableRooms($index);
        }
    }
    
    // ======================================================= //

    public function edit($id)
    {
        $this->resetInputFields();
        $agenda = Agenda::with('details.room')->where('id', $id)->where('user_id', Auth::id())->firstOrFail();
        
        $this->agendaToEdit = $agenda;
        $this->agendaId = $agenda->id;
        $this->title = $agenda->title;
        $this->description = $agenda->description;
        $this->type = $agenda->type;

        foreach ($agenda->details as $detail) {
            $this->agendaDetails[] = [
                'id' => $detail->id,
                'start_date' => $detail->start_date->format('Y-m-d'),
                'end_date' => $detail->end_date->format('Y-m-d'),
                'start_time' => $detail->start_time,
                'end_time' => $detail->end_time,
                'room_id' => $detail->room_id,
                'manual_location' => $detail->manual_location,
                'availableRooms' => []
            ];
            // Langsung cari ruangan yang tersedia untuk setiap jadwal yang ada
            if($this->type === 'internal') {
                $this->findAvailableRooms(count($this->agendaDetails) - 1);
            }
        }
        
        if (empty($this->agendaDetails)) {
            $this->addSchedule();
        }

        $this->openModal();
    }

    public function update()
    {
        $this->validate([
            'title' => 'required|string|max:255',
            'description' => 'required|string',
            'agendaDetails' => 'required|array|min:1',
            'agendaDetails.*.start_date' => 'required|date',
            'agendaDetails.*.end_date' => 'required|date|after_or_equal:agendaDetails.*.start_date',
            'agendaDetails.*.start_time' => 'required',
            'agendaDetails.*.end_time' => 'required|after:agendaDetails.*.start_time',
            'agendaDetails.*.room_id' => 'required_if:type,internal',
            'agendaDetails.*.manual_location' => 'required_if:type,external',
        ]);

        if ($this->agendaToEdit) {
            $this->agendaToEdit->update([
                'title' => $this->title,
                'description' => $this->description,
            ]);

            $existingDetailIds = [];
            foreach ($this->agendaDetails as $detailData) {
                $detail = $this->agendaToEdit->details()->updateOrCreate(
                    ['id' => $detailData['id'] ?? null],
                    [
                        'start_date' => $detailData['start_date'],
                        'end_date' => $detailData['end_date'],
                        'start_time' => $detailData['start_time'],
                        'end_time' => $detailData['end_time'],
                        'room_id' => $this->type == 'internal' ? $detailData['room_id'] : null,
                        'manual_location' => $this->type == 'external' ? $detailData['manual_location'] : null,
                    ]
                );
                $existingDetailIds[] = $detail->id;
            }
            $this->agendaToEdit->details()->whereNotIn('id', $existingDetailIds)->delete();
            session()->flash('message', 'Agenda berhasil diperbarui.');
            $this->closeModal();
        }
    }

    public function delete($id)
    {
        $agenda = Agenda::where('id', $id)->where('user_id', Auth::id())->firstOrFail();
        $agenda->delete();
        session()->flash('message', 'Agenda berhasil dihapus.');
    }
}
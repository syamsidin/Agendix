<?php
namespace App\Livewire\Admin;

use Livewire\Component;
use Livewire\WithPagination;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

class UserManagement extends Component
{
    use WithPagination;

    public $name, $email, $password, $role, $department_name, $agency, $color;
    public $userId;
    public $isModalOpen = false;

    public function render()
    {
        return view('livewire.admin.user-management', [
            'users' => User::latest()->simplePaginate(10)
        ]);
    }

    public function create()
    {
        $this->resetInputFields();
        $this->openModal();
    }

    public function openModal()
    {
        $this->isModalOpen = true;
    }

    public function closeModal()
    {
        $this->isModalOpen = false;
    }

    private function resetInputFields(){
        $this->name = '';
        $this->email = '';
        $this->password = '';
        $this->role = 'user';
        $this->department_name = '';
        $this->agency = '';
        $this->color = '#33A2FF';
        $this->userId = null;
    }

    public function store()
    {
        $this->validate([
            'name' => 'required',
            'email' => 'required|email|unique:users,email,' . $this->userId,
            'password' => $this->userId ? 'nullable' : 'required',
            'role' => 'required|in:admin,user,pic_wi,pimpinan,pengelola_aset,tu_pimpinan',
            'color' => 'required'
        ]);

        $userData = [
            'name' => $this->name,
            'email' => $this->email,
            'role' => $this->role,
            'department_name' => $this->department_name,
            'agency' => $this->agency,
            'color' => $this->color,
        ];

        if ($this->password) {
            $userData['password'] = Hash::make($this->password);
        }

        User::updateOrCreate(['id' => $this->userId], $userData);

        session()->flash('message', $this->userId ? 'Pengguna berhasil diperbarui.' : 'Pengguna berhasil dibuat.');

        $this->closeModal();
        $this->resetInputFields();
    }

    public function edit($id)
    {
        $user = User::findOrFail($id);
        $this->userId = $id;
        $this->name = $user->name;
        $this->email = $user->email;
        $this->role = $user->role;
        $this->department_name = $user->department_name;
        $this->agency = $user->agency;
        $this->color = $user->color;
        
        $this->openModal();
    }
    
    public function delete($id)
    {
        User::find($id)->delete();
        session()->flash('message', 'Pengguna berhasil dihapus.');
    }
}
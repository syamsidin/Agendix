<?php

namespace App\Livewire\Admin;

use Livewire\Component;
use App\Models\Widyaiswara;
use Livewire\WithPagination;

class WidyaiswaraManagement extends Component
{
    use WithPagination;

    // Properti untuk form
    public $name, $nip, $position, $rank, $whatsapp;
    public $widyaiswaraId;
    public $isModalOpen = false;

    // Untuk pencarian
    public $search = '';

    public function render()
    {
        $widyaiswaras = Widyaiswara::where('name', 'like', '%'.$this->search.'%')
                                 ->orWhere('nip', 'like', '%'.$this->search.'%')
                                 ->orderBy('name', 'asc')
                                 ->simplePaginate(10); 

        return view('livewire.admin.widyaiswara-management', ['widyaiswaras' => $widyaiswaras]);
    }

    public function create()
    {
        $this->resetInputFields();
        $this->openModal();
    }

    public function openModal()
    {
        $this->isModalOpen = true;
    }

    public function closeModal()
    {
        $this->isModalOpen = false;
    }

    private function resetInputFields()
    {
        $this->name = '';
        $this->nip = '';
        $this->position = '';
        $this->rank = '';
        $this->whatsapp = '';
        $this->widyaiswaraId = null;
        $this->resetErrorBag();
    }

    public function store()
    {
        $this->validate([
            'name' => 'required|string|max:255',
            'nip' => 'required|numeric|unique:widyaiswaras,nip,' . $this->widyaiswaraId,
            'position' => 'required|string',
            'rank' => 'required|string',
            'whatsapp' => 'required|numeric',
        ]);

        Widyaiswara::updateOrCreate(['id' => $this->widyaiswaraId], [
            'name' => $this->name,
            'nip' => $this->nip,
            'position' => $this->position,
            'rank' => $this->rank,
            'whatsapp' => $this->whatsapp,
        ]);

        session()->flash('message', $this->widyaiswaraId ? 'Data Widyaiswara berhasil diperbarui.' : 'Data Widyaiswara berhasil ditambahkan.');

        $this->closeModal();
        $this->resetInputFields();
    }

    public function edit($id)
    {
        $widyaiswara = Widyaiswara::findOrFail($id);
        $this->widyaiswaraId = $id;
        $this->name = $widyaiswara->name;
        $this->nip = $widyaiswara->nip;
        $this->position = $widyaiswara->position;
        $this->rank = $widyaiswara->rank;
        $this->whatsapp = $widyaiswara->whatsapp;
        $this->openModal();
    }

    public function delete($id)
    {
        Widyaiswara::find($id)->delete();
        session()->flash('message', 'Data Widyaiswara berhasil dihapus.');
    }
}
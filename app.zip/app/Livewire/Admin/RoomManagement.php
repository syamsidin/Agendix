<?php
namespace App\Livewire\Admin;

use Livewire\Component;
use App\Models\Room;
use App\Models\RoomImage;
use Livewire\WithPagination;
use Livewire\WithFileUploads;
use Illuminate\Support\Facades\Storage;

class RoomManagement extends Component
{
    use WithPagination, WithFileUploads;

    public $name, $facilities, $capacity, $location;
    public $roomId;
    public $isModalOpen = false;
    public $search = '';

    // =======================================================
    //          DEKLARASI PROPERTI YANG HILANG
    // =======================================================
    public $images = [];
    public $existingImages = []; // <-- INI YANG MENYEBABKAN ERROR
    public $roomToEdit;


    public function render()
    {
        // Ambil data dengan relasi images untuk thumbnail
        $rooms = Room::with('images')
            ->where('name', 'like', '%'.$this->search.'%')
            ->orderBy('created_at', 'desc')
            ->paginate(5);
                     
        return view('livewire.admin.room-management', ['rooms' => $rooms]);
    }

    public function create()
    {
        $this->resetInputFields();
        $this->isModalOpen = true;
    }

    public function openModal() { $this->isModalOpen = true; }
    public function closeModal() { $this->isModalOpen = false; }
    
    private function resetInputFields() {
        $this->reset(['name', 'facilities', 'capacity', 'location', 'roomId', 'images', 'existingImages', 'roomToEdit']);
        $this->resetErrorBag();
    }

    public function store()
    {
        $this->validate([
            'name' => 'required|string|max:255',
            'facilities' => 'required|string',
            'capacity' => 'required|integer|min:1',
            'location' => 'required|string',
            'images.*' => 'nullable|image|max:2048',
        ]);

        $room = Room::updateOrCreate(['id' => $this->roomId], [
            'name' => $this->name, 'facilities' => $this->facilities,
            'capacity' => $this->capacity, 'location' => $this->location,
        ]);

        if (!empty($this->images)) {
            foreach ($this->images as $image) {
                $path = $image->store('rooms', 'public');
                $room->images()->create(['path' => $path]);
            }
        }

        session()->flash('message', 'Data ruangan berhasil disimpan.');
        $this->closeModal();
    }

    public function edit($id)
    {
        $room = Room::with('images')->findOrFail($id);
        $this->roomId = $id;
        $this->roomToEdit = $room;
        $this->name = $room->name;
        $this->facilities = $room->facilities;
        $this->capacity = $room->capacity;
        $this->location = $room->location;
        $this->existingImages = $room->images; // Pastikan ini mengisi properti
        $this->openModal();
    }

    public function deleteImage($imageId)
    {
        $image = RoomImage::find($imageId);
        if ($image) {
            Storage::disk('public')->delete($image->path);
            $image->delete();
            $this->roomToEdit->refresh(); // Refresh objek utama
            $this->existingImages = $this->roomToEdit->images; // Isi ulang galeri
            session()->flash('image_message', 'Gambar berhasil dihapus.');
        }
    }

    public function delete($id)
    {
        $room = Room::with('images')->find($id);
        if ($room) {
            foreach ($room->images as $image) {
                Storage::disk('public')->delete($image->path);
            }
            $room->delete();
            session()->flash('message', 'Ruangan berhasil dihapus.');
        }
    }
}
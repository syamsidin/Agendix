<?php
namespace App\Livewire\Admin;

use Livewire\Component;
use App\Models\Struktural;
use Livewire\WithPagination;

class StrukturalManagement extends Component
{
    use WithPagination;

    public $name, $nip, $position;
    public $strukturalId;
    public $isModalOpen = false;
    public $search = '';

    public function render()
    {
        $strukturals = Struktural::where('name', 'like', '%'.$this->search.'%')
                                ->orWhere('nip', 'like', '%'.$this->search.'%')
                                ->latest()->paginate(10);
        return view('livewire.admin.struktural-management', [
            'strukturals' => $strukturals
        ]);
    }

    public function create()
    {
        $this->resetInputFields();
        $this->openModal();
    }

    public function openModal() { $this->isModalOpen = true; }
    public function closeModal() { $this->isModalOpen = false; }

    private function resetInputFields(){
        $this->name = '';
        $this->nip = '';
        $this->position = '';
        $this->strukturalId = null;
        $this->resetErrorBag();
    }

    public function store()
    {
        $this->validate([
            'name' => 'required|string|max:255',
            'nip' => 'nullable|numeric|digits_between:1,18|unique:strukturals,nip,' . $this->strukturalId,
            'position' => 'required|string|max:255',
        ]);

        Struktural::updateOrCreate(['id' => $this->strukturalId], [
            'name' => $this->name,
            'nip' => $this->nip,
            'position' => $this->position,
        ]);

        session()->flash('message', $this->strukturalId ? 'Data Pejabat berhasil diperbarui.' : 'Data Pejabat berhasil ditambahkan.');
        $this->closeModal();
        $this->resetInputFields();
    }

    public function edit($id)
    {
        $struktural = Struktural::findOrFail($id);
        $this->strukturalId = $id;
        $this->name = $struktural->name;
        $this->nip = $struktural->nip;
        $this->position = $struktural->position;
        $this->openModal();
    }
    
    public function delete($id)
    {
        Struktural::find($id)->delete();
        session()->flash('message', 'Data Pejabat berhasil dihapus.');
    }
}
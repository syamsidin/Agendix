<?php

namespace App\Livewire\Admin;

use Livewire\Component;
use App\Models\Agenda;
use Livewire\WithPagination;
use App\Notifications\AgendaApproved;
use App\Notifications\AgendaRejected;

class AgendaManagement extends Component
{
    use WithPagination;

    // Properti untuk modal penolakan
    public $agendaToReject;
    public $rejection_reason = '';
    public $isRejectModalOpen = false;

    // Untuk menampilkan notifikasi
    protected $listeners = ['agendaUpdated' => '$refresh'];

    public function render()
    {
        // Ambil hanya agenda internal yang masih 'pending'
         $agendas = Agenda::with('user', 'details.room') // Muat relasi user, details, dan room di dalam details
            // ->where('type', 'internal')
            ->orderBy('created_at', 'desc')
            ->simplePaginate(10);
            
        return view('livewire.admin.agenda-management', [
            'agendas' => $agendas
        ]);
    }

    /**
     * Setujui agenda.
     */
    public function approve($id)
    {
        $agenda = Agenda::find($id);
        if ($agenda) {
            $agenda->status = 'approved';
            $agenda->rejection_reason = null; // Hapus alasan penolakan jika ada
            $agenda->save();
            $agenda->user->notify(new AgendaApproved($agenda));

            // Kirim notifikasi sukses ke frontend
            session()->flash('message', 'Agenda "' . $agenda->title . '" berhasil disetujui.');

            // Refresh komponen
            $this->dispatch('agendaUpdated');
        }
    }

    /**
     * Buka modal untuk mengisi alasan penolakan.
     */
    public function openRejectModal($id)
    {
        $this->agendaToReject = Agenda::find($id);
        $this->isRejectModalOpen = true;
    }

    /**
     * Tolak agenda setelah mengisi alasan.
     */
    public function reject()
    {
        $this->validate(['rejection_reason' => 'required|string|min:10']);

        if ($this->agendaToReject) {
            $this->agendaToReject->status = 'rejected';
            $this->agendaToReject->rejection_reason = $this->rejection_reason;
            $this->agendaToReject->save();
            $this->agendaToReject->user->notify(new AgendaRejected($this->agendaToReject));

            session()->flash('message', 'Agenda "' . $this->agendaToReject->title . '" berhasil ditolak.');

            $this->closeRejectModal();
            $this->dispatch('agendaUpdated');

        }
    }

    /**
     * Tutup modal dan reset properti.
     */
    public function closeRejectModal()
    {
        $this->isRejectModalOpen = false;
        $this->rejection_reason = '';
        $this->agendaToReject = null;
    }
}
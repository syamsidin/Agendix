<?php
namespace App\Livewire\Admin;

use Livewire\Component;
use App\Models\Survey;
use Livewire\WithPagination;

class SurveyResponses extends Component
{
    use WithPagination;

    public function render()
    {
        return view('livewire.admin.survey-responses', [
            'surveys' => Survey::with('user')->latest()->paginate(10)
        ]);
    }
}
<?php

namespace App\Livewire\Pimpinan;

use Livewire\Component;
use App\Models\WidyaiswaraAssignment;
use Carbon\Carbon;

class Schedule extends Component
{
    public $selectedDate;

    public function mount()
    {
        $this->selectedDate = Carbon::today()->toDateString();
    }

    public function render()
    {
        $assignments = WidyaiswaraAssignment::with(['widyaiswara', 'agendaDetail.room', 'agendaDetail.agenda'])
            // Gunakan whereHas untuk memfilter berdasarkan relasi
            ->whereHas('agendaDetail', function ($query) {
                // Filter berdasarkan tanggal yang dipilih di tabel agenda_details
                $query->whereDate('start_date', '<=', $this->selectedDate)
                      ->whereDate('end_date', '>=', $this->selectedDate);
            })
            ->orderBy('start_time', 'asc') // Urutkan berdasarkan waktu mulai penugasan
            ->get();

        return view('livewire.pimpinan.schedule', [
            'assignments' => $assignments
        ]);
    }

    public function previousDay()
    {
        $this->selectedDate = Carbon::parse($this->selectedDate)->subDay()->toDateString();
    }

    public function nextDay()
    {
        $this->selectedDate = Carbon::parse($this->selectedDate)->addDay()->toDateString();
    }
    
    public function goToToday()
    {
        $this->selectedDate = Carbon::today()->toDateString();
    }
}
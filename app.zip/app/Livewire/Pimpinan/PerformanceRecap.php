<?php

namespace App\Livewire\Pimpinan;

use Livewire\Component;
use App\Models\Widyaiswara;
use Carbon\Carbon;
use Livewire\WithPagination; // <-- Tambahkan ini

class PerformanceRecap extends Component
{
    use WithPagination; // <-- Gunakan trait ini

    public $startDate;
    public $endDate;
    public $search = ''; // <-- Properti baru untuk pencarian

    public function mount()
    {
        $this->startDate = Carbon::now()->startOfMonth()->toDateString();
        $this->endDate = Carbon::now()->endOfMonth()->toDateString();
    }

    // Method ini akan me-reset paginasi ke halaman 1 setiap kali $search berubah
    public function updatingSearch()
    {
        $this->resetPage();
    }

    public function render()
    {
        $widyaiswaras = Widyaiswara::query() // Mulai dengan query() agar bisa dirangkai
            // Tambahkan kondisi pencarian
            ->where(function ($query) {
                $query->where('name', 'like', '%'.$this->search.'%')
                      ->orWhere('nip', 'like', '%'.$this->search.'%');
            })
            ->withCount(['assignments' => function ($query) {
                $query->whereHas('agendaDetail', function ($subQuery) {
                    $subQuery->whereBetween('start_date', [$this->startDate, $this->endDate]);
                });
            }])
            ->withSum(['assignments as total_jp' => function ($query) {
                $query->whereHas('agendaDetail', function ($subQuery) {
                    $subQuery->whereBetween('start_date', [$this->startDate, $this->endDate]);
                });
            }], 'jp')
            ->orderBy('total_jp', 'desc')
            ->simplePaginate(10); // <-- Ganti get() menjadi paginate()

        return view('livewire.pimpinan.performance-recap', [
            'widyaiswaras' => $widyaiswaras
        ]);
    }
}
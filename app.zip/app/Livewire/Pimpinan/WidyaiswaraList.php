<?php

namespace App\Livewire\Pimpinan;

use Livewire\Component;
use App\Models\Widyaiswara;
use Livewire\WithPagination;

class WidyaiswaraList extends Component
{
    use WithPagination;

    public $search = '';

    public function updatingSearch()
    {
        // Reset paginasi setiap kali melakukan pencarian
        $this->resetPage();
    }

    public function render()
    {
        $widyaiswaras = Widyaiswara::where('name', 'like', '%'.$this->search.'%')
                                 ->orWhere('nip', 'like', '%'.$this->search.'%')
                                 ->orderBy('name', 'asc')
                                 ->simplePaginate(5); // Gunakan paginate biasa untuk nomor

        return view('livewire.pimpinan.widyaiswara-list', [
            'widyaiswaras' => $widyaiswaras
        ]);
    }
}
<?php

namespace App\Livewire\Shared;

use Livewire\Component;
use Illuminate\Support\Facades\Auth;

class Notifications extends Component
{
    public $unreadNotifications;
    public $unreadCount = 0;

    // Polling untuk refresh otomatis setiap 30 detik
    protected $listeners = ['agendaUpdated' => 'loadNotifications'];

    public function mount()
    {
        $this->loadNotifications();
    }

    public function loadNotifications()
    {
        if (Auth::check()) {
            $this->unreadNotifications = Auth::user()->unreadNotifications;
            $this->unreadCount = $this->unreadNotifications->count();
        }
    }

    public function markAsRead($notificationId)
    {
        $notification = Auth::user()->notifications()->find($notificationId);
        if ($notification) {
            $notification->markAsRead();
        }
        $this->loadNotifications(); // Refresh list
    }
    
    public function markAllAsRead()
    {
        Auth::user()->unreadNotifications->markAsRead();
        $this->loadNotifications(); // Refresh list
    }

    public function render()
    {
        return view('livewire.shared.notifications');
    }
}
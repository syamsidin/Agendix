<?php

namespace App\Livewire\Shared;

use Livewire\Component;
use App\Models\Agenda;

class RecentActivities extends Component
{
    public $recentAgendas = [];

    // Listener untuk me-refresh saat ada agenda baru/diupdate
    protected $listeners = ['agendaUpdated' => 'loadRecentAgendas'];

    public function mount()
    {
        $this->loadRecentAgendas();
    }

    public function loadRecentAgendas()
    {
        // Ambil 5 agenda terakhir yang dibuat, tanpa filter status
        $this->recentAgendas = Agenda::with('user', 'details.room')
        	->where('status', 'pending')
            // KONDISI 2 (BARU): Hanya yang tipenya internal
            ->where('type', 'internal')
            ->latest() // Mengurutkan berdasarkan created_at (terbaru dulu)
            ->take(5)  // Ambil 5 record teratas
            ->get();

    }

    public function render()
    {
        return view('livewire.shared.recent-activities');
    }
}
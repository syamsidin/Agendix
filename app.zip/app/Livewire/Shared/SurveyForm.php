<?php

namespace App\Livewire\Shared;

use Livewire\Component;
use App\Models\Survey;
use Illuminate\Support\Facades\Auth;

class SurveyForm extends Component
{
    public $isModalOpen = false;
    public $reference_id;
    public $reference_type;

    public $answer1 = '';
    public $answer2 = '';
    
    protected $listeners = ['showSurvey'];

    // Method ini akan dipanggil dari JavaScript
    public function showSurvey($referenceId, $referenceType)
    {
        $this->reference_id = $referenceId;
        $this->reference_type = $referenceType;
        $this->isModalOpen = true;
    }

    public function submitSurvey()
    {
        $this->validate([
            'answer1' => 'required|string|min:5',
            'answer2' => 'required|string|min:5',
        ], [
            'required' => 'Jawaban tidak boleh kosong.',
            'min' => 'Jawaban minimal 5 karakter.',
        ]);

        Survey::create([
            'user_id' => Auth::id(),
            'reference_id' => $this->reference_id,
            'reference_type' => $this->reference_type,
            'question_1_answer' => $this->answer1,
            'question_2_answer' => $this->answer2,
        ]);

        $this->closeModal();
        session()->flash('survey_success', 'Terima kasih atas masukan Anda!');
    }

    public function closeModal()
    {
        $this->isModalOpen = false;
        $this->reset(['answer1', 'answer2', 'reference_id', 'reference_type']);
    }

    public function render()
    {
        return view('livewire.shared.survey-form');
    }
}
<?php

namespace App\Livewire\Shared;

use Livewire\Component;
use App\Models\Agenda;
use App\Models\User;
use App\Models\AgendaDetail;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use Livewire\WithPagination;

class Calendar extends Component
{
    use WithPagination;

    // --- Properti Publik ---
    public $events = [];
    public $selectedAgenda;
    public $dayActivities = [];
    public $selectedDateForModal;
    
    // Properti untuk Filter
    public $startDateFilter;
    public $endDateFilter;
    public $departmentFilter = '';
    public $departments = [];

    // Listener untuk refresh dari komponen lain
    protected $listeners = ['agendaUpdated' => 'loadEventsForCalendar'];

    public function mount()
    {
        $this->loadEventsForCalendar();
        $this->departments = User::whereNotNull('department_name')
                                ->where('department_name', '!=', '')
                                ->where('role', 'user')
                                ->distinct()
                                ->orderBy('department_name', 'asc')
                                ->pluck('department_name');
    }

    // Dipanggil setiap kali filter diubah
    public function updated($propertyName)
    {
        if (in_array($propertyName, ['startDateFilter', 'endDateFilter', 'departmentFilter'])) {
            $this->resetPage('agendaPage'); // Reset paginasi untuk list
            $this->loadEventsForCalendar(); // Muat ulang event untuk kalender
        }
    }
    
    /**
     * Method ini hanya untuk membangun query dasar yang akan digunakan bersama.
     */
    private function buildFilteredQuery()
    {
        $query = Agenda::query() // Mulai dengan query builder
            ->where('status', 'approved')
            ->where(function ($q) {
                $q->where('description', '!=', 'Penugasan manual oleh PIC.')
                  ->orWhereNull('description');
            });
        
        if ($this->departmentFilter) {
            $query->whereHas('user', function ($userQuery) {
                $userQuery->where('department_name', $this->departmentFilter);
            });
        }
        if ($this->startDateFilter && $this->endDateFilter) {
            $query->whereHas('details', function ($detailsQuery) {
                $detailsQuery->where(function ($q) {
                    $q->where('start_date', '<=', $this->endDateFilter)
                      ->where('end_date', '>=', $this->startDateFilter);
                });
            });
        }
        return $query;
    }

    /**
     * Method ini KHUSUS untuk memuat data event untuk FullCalendar.
     * Tidak ada paginasi di sini.
     */
    public function loadEventsForCalendar()
    {
        // Gunakan query builder, tambahkan relasi, dan panggil get()
        $agendasForCalendar = $this->buildFilteredQuery()
                                  ->with('user', 'details.room')
                                  ->get();

        $events = [];
        foreach ($agendasForCalendar as $agenda) {
            foreach ($agenda->details as $detail) {
                $events[] = [
                    'id' => $agenda->id,
                    'title' => $agenda->title,
                    'start' => $detail->start_date->format('Y-m-d') . 'T' . $detail->start_time,
                    'end' => $detail->end_date->addDay()->format('Y-m-d'),
                    'backgroundColor' => $agenda->user->color ?? '#3788d8',
                    'borderColor' => $agenda->user->color ?? '#3788d8',
                    'extendedProps' => [ /* ... */ ]
                ];
            }
        }
        $this->events = $events;
        
        // Kirim event ke JS untuk update tampilan kalender
        $this->dispatch('events-updated', $this->events);
    }
    
    public function resetFilters()
    {
        $this->reset(['startDateFilter', 'endDateFilter', 'departmentFilter']);
        $this->resetPage('agendaPage');
        $this->loadEventsForCalendar();
    }

    /**
     * Method render akan menangani data yang perlu paginasi.
     */
    public function render()
    {
        $filteredAgendas = null;
        $isFiltering = $this->departmentFilter || ($this->startDateFilter && $this->endDateFilter);

        if ($isFiltering) {
            // Jalankan query yang sama, tetapi dengan paginasi
            $filteredAgendas = $this->buildFilteredQuery()
                                    ->with('user', 'details.room') // Muat relasi untuk ditampilkan
                                    ->latest() // Urutkan berdasarkan yang terbaru
                                    ->paginate(50, ['*'], 'agendaPage');
        }

        return view('livewire.shared.calendar', [
            'filteredAgendas' => $filteredAgendas
        ]);
    }
    
    // --- Method untuk interaksi modal ---
    
    public function showAgendaDetails($id)
    {
        $this->selectedAgenda = Agenda::with('user', 'details.room', 'details.dispositions.struktural')->find($id);
        $this->dispatch('open-agenda-modal');
    }

    public function showActivitiesForDate($date)
    {
        $clickedDate = Carbon::parse($date)->toDateString();
        $this->selectedDateForModal = $clickedDate;

        $this->dayActivities = AgendaDetail::with('agenda.user', 'room')
            ->whereDate('start_date', '<=', $clickedDate)
            ->whereDate('end_date', '>=', $clickedDate)
            ->whereHas('agenda', function ($query) {
                $query->where('status', 'approved')
                      ->where(function ($subQuery) {
                          $subQuery->where('description', '!=', 'Penugasan manual oleh PIC.')
                                   ->orWhereNull('description');
                      });
            })
            ->orderBy('start_time')
            ->get();
        
        $this->dispatch('open-day-activities-modal');
    }
    
    public function closeModal()
    {
        $this->dispatch('hide-modals');
    }
}
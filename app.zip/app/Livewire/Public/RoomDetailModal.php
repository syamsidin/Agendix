<?php
namespace App\Livewire\Public;

use Livewire\Component;
use App\Models\Room;

class RoomDetailModal extends Component
{
    public $isModalOpen = false;
    public $room;

    protected $listeners = ['showRoomDetail'];

    public function showRoomDetail($data)
    {
        $roomId = $data['roomId'];
        $this->room = Room::with('images')->find($roomId);
        $this->isModalOpen = true;
    }

    public function closeModal()
    {
        $this->isModalOpen = false;
    }

    public function render()
    {
        return view('livewire.public.room-detail-modal');
    }
}
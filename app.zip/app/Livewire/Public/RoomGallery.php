<?php
namespace App\Livewire\Public;

use Livewire\Component;
use App\Models\Room;

class RoomGallery extends Component
{
    public $rooms;

    public function mount()
    {
        // Pindahkan query dari controller ke sini
        $this->rooms = Room::with('images')->orderBy('name', 'asc')->get();
    }

    public function render()
    {
        return view('livewire.public.room-gallery');
    }
}
<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Room; // <-- Pastikan ini ada

class PublicController extends Controller
{
    /**
     * Menampilkan halaman landing page (welcome).
     */
    public function welcome()
    {
        // Ambil semua data ruangan dari database
        $rooms = Room::orderBy('name', 'asc')->get();

        // Kirim data rooms ke view 'welcome'
        return view('welcome', [
            'rooms' => $rooms
        ]);
    }

     /**
     * Menampilkan halaman galeri semua ruangan.
     */
    public function roomGallery()
    {
        $rooms = Room::with('images')->orderBy('name', 'asc')->get();
        return view('public.rooms', ['rooms' => $rooms]);
    }

    /**
     * Menampilkan halaman detail satu ruangan.
     */
    public function roomDetail($id)
    {
        $room = Room::with('images')->findOrFail($id);
        return view('public.room-detail', ['room' => $room]);
    }

    /**
     * Menampilkan halaman kalender publik.
     */
    public function calendar()
    {
        return view('public.calendar');
    }
}
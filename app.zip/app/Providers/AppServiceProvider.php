<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Pagination\Paginator;
use Illuminate\Routing\Router;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(Router $router): void // <-- TAMBAHKAN parameter Router $router
    {
        // TAMBAHKAN baris ini untuk mendaftarkan middleware secara paksa
        $router->aliasMiddleware('role', \App\Http\Middleware\RoleMiddleware::class);
        Paginator::useBootstrapFour();
    }
}

<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;
use App\Models\Agenda;

class AgendaRejected extends Notification
{
    use Queueable;

    protected $agenda;

    public function __construct(Agenda $agenda)
    {
        $this->agenda = $agenda;
    }

    public function via(object $notifiable): array
    {
        return ['database'];
    }

    public function toDatabase(object $notifiable): array
    {
        return [
            'agenda_id' => $this->agenda->id,
            'title' => $this->agenda->title,
            'message' => "Mohon maaf, pengajuan agenda Anda '{$this->agenda->title}' ditolak.",
            'reason' => $this->agenda->rejection_reason,
            'url' => route('agenda.history'),
        ];
    }
}
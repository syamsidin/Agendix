<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;
use App\Models\Agenda;

class AgendaSubmitted extends Notification
{
    use Queueable;

    protected $agenda;

    public function __construct(Agenda $agenda)
    {
        $this->agenda = $agenda;
    }

    public function via(object $notifiable): array
    {
        return ['database']; // Kita simpan ke database
    }

    // Data yang akan disimpan di kolom 'data' pada tabel notifikasi
    public function toDatabase(object $notifiable): array
    {
        return [
            'agenda_id' => $this->agenda->id,
            'title' => $this->agenda->title,
            'user_name' => $this->agenda->user->name,
            'message' => "Pengajuan agenda baru '{$this->agenda->title}' oleh {$this->agenda->user->name}.",
            'url' => route('admin.agenda.management'),
        ];
    }
}
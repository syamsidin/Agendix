<?php

use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PublicController;

// Halaman Awal & Otentikasi
// Gunakan controller untuk halaman utama
Route::get('/', [PublicController::class, 'welcome'])->name('welcome');
Route::get('/kalender-kegiatan', [PublicController::class, 'calendar'])->name('public.calendar');

Route::get('/ruangan', [PublicController::class, 'roomGallery'])->name('public.rooms.gallery');

// Route untuk melihat detail satu ruangan
Route::get('/ruangan/{id}', [PublicController::class, 'roomDetail'])->name('public.rooms.detail');

// Route untuk halaman landing
Route::get('/', [PublicController::class, 'welcome'])->name('welcome');

// Dashboard Utama (setelah login)
Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

// Profile
Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

// Role: User & Admin
Route::middleware(['auth', 'role:user,tu_pimpinan'])->group(function () {
    // Livewire akan menangani ini, kita hanya butuh route untuk view
    Route::get('/agenda/submit', function() {
    return view('pages.agenda.submit'); // <-- Laravel mencari file ini
})->name('agenda.submit');

    Route::get('/agenda/history', function() {
        return view('pages.agenda.history');
    })->name('agenda.history');

    Route::get('/jadwal-ruangan', function() {
        return view('pages.user.room-schedule');
    })->name('user.room-schedule');
});

Route::middleware(['auth', 'role:tu_pimpinan'])->prefix('tu-pimpinan')->name('tu.')->group(function () {
    Route::get('/disposisi', function() { return view('pages.tu_pimpinan.dispositions'); })->name('dispositions');
});

// Role: Admin
Route::middleware(['auth', 'role:admin'])->prefix('admin')->name('admin.')->group(function () {
    Route::get('/users', function() { return view('pages.admin.users'); })->name('users');
    Route::get('/rooms', function() { return view('pages.admin.rooms'); })->name('rooms');
    Route::get('/widyaiswara', function() { return view('pages.admin.widyaiswara'); })->name('widyaiswara');
    Route::get('/agenda-management', function() { return view('pages.admin.agenda-management'); })->name('agenda.management');
    Route::get('/surveys', function() { return view('pages.admin.surveys'); })->name('surveys');
     Route::get('/struktural', function() { return view('pages.admin.struktural'); })->name('struktural');

});

// Role: Pengelola Aset
Route::middleware(['auth', 'role:admin,pengelola_aset'])->prefix('admin')->name('admin.')->group(function () {
    Route::get('/rooms', function() { return view('pages.admin.rooms'); })->name('rooms');
    Route::get('/agenda-management', function() { return view('pages.admin.agenda-management'); })->name('agenda.management');

    Route::get('/room-timeline', function() {
        return view('pages.pengelola_aset.room-timeline');
    })->name('room-timeline');
});

// Role: PIC WI
Route::middleware(['auth', 'role:pic_wi'])->prefix('pic')->name('pic.')->group(function () {
    Route::get('/assignment', function() { return view('pages.pic.assignment'); })->name('assignment');
});

// Role: Pimpinan
Route::middleware(['auth', 'role:pimpinan'])->prefix('pimpinan')->name('pimpinan.')->group(function () {
     Route::get('/schedule', function() { return view('pages.pimpinan.schedule'); })->name('schedule');
     Route::get('/data-widyaiswara', function() {
        return view('pages.pimpinan.widyaiswara-list');
     })->name('widyaiswara.list');
      Route::get('/rekap-kinerja', function() {
        return view('pages.pimpinan.performance-recap');
     })->name('performance.recap');
});


require __DIR__.'/auth.php';
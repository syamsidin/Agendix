<?php
namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    public function run(): void
    {
       User::firstOrCreate(
            ['email' => 'admin@bpsdm.test'],
            [
                'name' => 'Admin BPSDM',
                'password' => Hash::make('password'),
                'role' => 'admin',
                'department_name' => 'IT',
                'agency' => 'BPSDM',
                'color' => '#FF5733'
            ]);


       User::firstOrCreate(
            ['email' => 'user@bpsdm.test'],
            [
                'name' => 'User Biasa',
                'password' => Hash::make('password'),
                'role' => 'user',
                'department_name' => 'Keuangan',
                'agency' => 'BPSDM',
                'color' => '#33A2FF' 
            ]);

        User::firstOrCreate(
            ['email' => 'pic@bpsdm.test'],
            [
                'name' => 'PIC Widyaiswara',
                'password' => Hash::make('password'),
                'role' => 'pic_wi',
                'department_name' => 'Akademik',
                'agency' => 'BPSDM',
                'color' => '#33FF57' // Hijau
            ]);


        User::firstOrCreate(
            ['email' => 'pimpinan@bpsdm.test'],
            [
                'name' => 'Pimpinan',
                'password' => Hash::make('password'),
                'role' => 'pimpinan',
                'department_name' => 'Manajemen',
                'agency' => 'BPSDM',
                'color' => '#F1C40F' // Kuning
            ]);


         User::firstOrCreate(
            ['email' => 'aset@bpsdm.test'],
            [
                'name' => 'Pengelola Aset',
                'password' => Hash::make('password'),
                'role' => 'pengelola_aset',
                'department_name' => 'Umum & Aset',
                'agency' => 'BPSDM',
                'color' => '#8E44AD' // Ungu
            ]);

         User::firstOrCreate(
            ['email' => 'tu_pimpinan@bpsdm.test'],
            [
                'name' => 'TU Pimpinan',
                'password' => Hash::make('password'),
                'role' => 'tu_pimpinan',
                'department_name' => 'Sekretariat Pimpinan',
                'agency' => 'BPSDM',
                'color' => '#F39C12'
            ]);
    }
}
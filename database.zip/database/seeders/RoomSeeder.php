<?php
namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Room;

class RoomSeeder extends Seeder
{
    public function run(): void
    {
        Room::create([
            'name' => 'Aula Garuda',
            'facilities' => 'AC, Proyektor, Sound System, Papan Tulis',
            'capacity' => 100,
            'location' => 'Gedung A, Lantai 5'
        ]);
        Room::create([
            'name' => 'Ruang Rapat Cendrawasih',
            'facilities' => 'AC, Proyektor, Meja Rapat',
            'capacity' => 25,
            'location' => 'Gedung B, Lantai 2'
        ]);
    }
}
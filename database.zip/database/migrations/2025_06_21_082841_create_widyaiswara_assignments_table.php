<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('widyaiswara_assignments', function (Blueprint $table) {
            $table->id();
            $table->foreignId('widyaiswara_id')->constrained()->onDelete('cascade');
            $table->foreignId('agenda_id')->constrained()->onDelete('cascade');
            $table->string('material');
            $table->time('time');
            $table->integer('jp'); // Jam Pelajaran
            $table->timestamps();
        });
    }
    public function down(): void { Schema::dropIfExists('widyaiswara_assignments'); }
};
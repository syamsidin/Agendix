<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('dispositions', function (Blueprint $table) {
            // Ubah tipe kolom 'purpose' menjadi string dengan panjang 255
            $table->string('purpose', 255)->change();
        });
    }

    public function down(): void
    {
        Schema::table('dispositions', function (Blueprint $table) {
            // (Opsional) Kembalikan ke tipe semula jika perlu rollback
            // Contoh: $table->string('purpose', 50)->change();
        });
    }
};
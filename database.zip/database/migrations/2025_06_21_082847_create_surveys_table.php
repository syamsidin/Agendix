<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('surveys', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->onDelete('cascade');
            $table->unsignedBigInteger('reference_id'); // Bisa agenda_id atau assignment_id
            $table->string('reference_type'); // 'agenda' atau 'assignment'
            $table->string('question_1_answer');
            $table->string('question_2_answer');
            $table->timestamps();
        });
    }
    public function down(): void { Schema::dropIfExists('surveys'); }
};
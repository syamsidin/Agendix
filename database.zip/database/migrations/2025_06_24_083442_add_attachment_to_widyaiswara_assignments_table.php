<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::table('widyaiswara_assignments', function (Blueprint $table) {
            // Tambahkan kolom untuk path file setelah 'jp'
            $table->string('attachment_path')->nullable()->after('jp');
        });
    }

    public function down(): void {
        Schema::table('widyaiswara_assignments', function (Blueprint $table) {
            $table->dropColumn('attachment_path');
        });
    }
};
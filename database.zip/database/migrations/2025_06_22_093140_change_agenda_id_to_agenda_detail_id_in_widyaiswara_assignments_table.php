<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::table('widyaiswara_assignments', function (Blueprint $table) {
            // Hanya jalankan jika kolom lama ('agenda_id') ada
            if (Schema::hasColumn('widyaiswara_assignments', 'agenda_id')) {
                // Hapus foreign key lama terlebih dahulu
                $table->dropForeign(['agenda_id']);
                // Ganti nama kolomnya
                $table->renameColumn('agenda_id', 'agenda_detail_id');
                // Tambahkan foreign key baru
                $table->foreign('agenda_detail_id')->references('id')->on('agenda_details')->onDelete('cascade');
            }
        });
    }

    public function down(): void {
        Schema::table('widyaiswara_assignments', function (Blueprint $table) {
            // Hanya jalankan jika kolom baru ('agenda_detail_id') ada
            if (Schema::hasColumn('widyaiswara_assignments', 'agenda_detail_id')) {
                 $table->dropForeign(['agenda_detail_id']);
                 $table->renameColumn('agenda_detail_id', 'agenda_id');
                 $table->foreign('agenda_id')->references('id')->on('agendas')->onDelete('cascade');
            }
        });
    }
};
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration{
            /**
             * Run the migrations.
             */
           public function up(): void
        {
            DB::statement("ALTER TABLE users MODIFY COLUMN role ENUM('admin', 'user', 'pic_wi', 'pimpinan', 'pengelola_aset', 'tu_pimpinan') NOT NULL DEFAULT 'user'");
        }
        public function down(): void
        {
            DB::statement("ALTER TABLE users MODIFY COLUMN role ENUM('admin', 'user', 'pic_wi', 'pimpinan', 'pengelola_aset') NOT NULL DEFAULT 'user'");
        }
};

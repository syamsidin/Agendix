<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        // Hanya jalankan jika kolomnya ada
        if (Schema::hasColumn('agendas', 'start_date')) {
            Schema::table('agendas', function (Blueprint $table) {
                $table->dropColumn(['start_date', 'end_date', 'start_time', 'end_time', 'manual_location']);
            });
        }
    }
    public function down(): void {
        Schema::table('agendas', function (Blueprint $table) {
            $table->date('start_date')->nullable();
            $table->date('end_date')->nullable();
            $table->time('start_time')->nullable();
            $table->time('end_time')->nullable();
            $table->string('manual_location')->nullable();
        });
    }
};
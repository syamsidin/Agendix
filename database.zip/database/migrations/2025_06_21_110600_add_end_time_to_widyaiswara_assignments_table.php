<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('widyaiswara_assignments', function (Blueprint $table) {
            // Tambahkan kolom end_time setelah kolom 'time'
            $table->time('end_time')->after('time');
            
            // Ubah nama kolom 'time' menjadi 'start_time' agar lebih jelas
            $table->renameColumn('time', 'start_time');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('widyaiswara_assignments', function (Blueprint $table) {
            $table->dropColumn('end_time');
            $table->renameColumn('start_time', 'time');
        });
    }
};
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
         Schema::table('widyaiswara_assignments', function (Blueprint $table) {
        if (Schema::hasColumn('widyaiswara_assignments', 'agenda_id')) {
            $table->dropForeign(['agenda_id']);
            $table->renameColumn('agenda_id', 'agenda_detail_id');
            $table->foreign('agenda_detail_id')->references('id')->on('agenda_details')->onDelete('cascade');
        }
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('modify-assignment');    
    }
};
